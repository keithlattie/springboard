describe('Favorite', function () {
  // Load Angular
  var FavoriteService, Session, User;
  beforeEach(module('springboard'));
  beforeEach(inject(function ($injector) {
    FavoriteService = $injector.get('FavoriteService');
    Session = $injector.get('Session');
    User = $injector.get('User');
  }));

  describe('isFavorite', function() {
    var feature;
    beforeEach(function() {
      Session.user = User.fromJSON({
        favorites: [{
          favorable_type: 'product',
          favorable_id: 1
        }]
      });
    });

    it('should add to the component features', function() {
      var result = FavoriteService.isFavorite('product', 1);
      expect(result).to.be.true;
    });
  });
});
