describe('UserCacheSpec', function () {
  // Load Angular
  var $httpBackend, $timeout, Idea, User, UserCache;
  beforeEach(module('springboard'));
  beforeEach(inject(function ($injector) {
    $httpBackend = $injector.get('$httpBackend');
    $timeout = $injector.get('$timeout');
    Idea = $injector.get('Idea');
    User = $injector.get('User');
    UserCache = $injector.get('UserCache');
  }));

  beforeEach(function() {
    $httpBackend.expectGET('/session');
    $httpBackend.expectGET('/api/metric_categories');
    $httpBackend.when('GET', '/session').respond({});
    $httpBackend.when('GET', '/api/metric_categories').respond([]);
  });

  var user;
  var originator;
  var idea;
  beforeEach(function() {
    user = User.fromJSON({
      id: 1,
      first_name: 'Viewer'
    });
    originator = User.fromJSON({
      id: 2,
      first_name: 'originator'
    });
    idea = Idea.fromJSON({
      id: 1,
      title: 'Idea 1',
      originator_id: originator.id,
      created_by: user.id,
      updated_by: user.id
    });
  });

  describe('loadObject', function() {
    it('should load user attributes onto and object', function(done) {
      var userIds = _.pluck([originator,user], 'id');
      var url = '/api/bulk/users/' + userIds.join(',');
      $httpBackend.expectGET(url);
      $httpBackend.when('GET', url).respond([user, originator]);

      idea.loadUsers().then(function() {
        expect(idea.owner).to.be.undefined;
        expect(idea.originator.id).to.eql(originator.id);
        expect(idea.createdBy.id).to.eql(user.id);
        expect(idea.updatedBy.id).to.eql(user.id);
      }).then(done, done);

      $timeout.flush();
      $httpBackend.flush();
    });
  });
});
