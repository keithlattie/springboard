describe('SortableSpec', function () {
  // Load Angular
  var Sortable;
  beforeEach(module('springboard'));
  beforeEach(inject(function ($injector) {
    Sortable = $injector.get('Sortable');
  }));

  var items;
  beforeEach(function() {
    items = _.times(5, function(index) {
      return {
        id: index + 1,
        position: index + 1
      }
    });
  });

  describe('resetPositions', function() {
    beforeEach(function() {
      var item1 = _.findWhere(items, {id: 1});
      var item2 = _.findWhere(items, {id: 2});
      var item3 = _.findWhere(items, {id: 3});
      var item4 = _.findWhere(items, {id: 4});
      var item5 = _.findWhere(items, {id: 5});
      var sorted = [item3, item5, item1, item4, item2];
      Sortable.resetPositions(sorted);
    });

    it('should set positions by index', function() {
      var positions = _.pluck(items, 'position');
      expect(positions).to.eql([3,5,1,4,2]);
    });
  });

  describe('insert', function() {
    beforeEach(function() {
      Sortable.insert(items, {
        id: 6,
        position: 1
      });
    });

    it('should add to the collection', function() {
      expect(items).to.have.length(6);
    });

    it('should update the positions', function() {
      var ids = _.pluck(items, 'id');
      var positions = _.pluck(items, 'position');
      expect(ids).to.eql([1,2,3,4,5,6]);
      expect(positions).to.eql([2,3,4,5,6,1]);
    });
  });

  describe('afterMove', function() {
    describe('move down', function() {
      beforeEach(function() {
        var item = _.findWhere(items, {id: 4});
        item.position = 2;
        Sortable.afterMove(items, item, item.id);
      });

      it('should update the positions', function() {
        var positions = _.pluck(items, 'position');
        expect(positions).to.eql([1,3,4,2,5]);
      });
    });

    describe('move up', function() {
      beforeEach(function() {
        var item = _.findWhere(items, {id: 2});
        item.position = 4;
        Sortable.afterMove(items, item, item.id);
      });

      it('should update the positions', function() {
        var positions = _.pluck(items, 'position');
        expect(positions).to.eql([1,4,2,3,5]);
      });
    });
  });
});
