describe('productFilterSpec', function () {
  // Load Angular
  var Product, productFilter;
  beforeEach(module('springboard'));
  beforeEach(inject(function ($injector) {
    Product = $injector.get('Product');
    productFilter = $injector.get('productFilter');
  }));

  var products;
  beforeEach(function() {
    products = _.map([{
      id: 1,
      name: 'Reverse Logistics',
      team_members: [{
        id: 1,
        role: 'Product Owner',
        name: 'Daniel Rice'
      }]
    }, {
      id: 2,
      name: 'North Carolina',
      team_members: [{
        id: 2,
        role: 'Product Owner',
        name: 'John Smith'
      }]
    }, {
      id: 3,
      name: 'South Carolina',
      team_members: [{
        id: 3,
        role: 'Product Owner',
        name: 'Sam Duvall'
      }]
    }, {
      id: 4,
      name: 'North Dakota',
      team_members: [{
        id: 4,
        role: 'Product Owner',
        name: 'Tom O\'Dea'
      }]
    }], Product.fromJSON);
  });

  it('should return all results', function() {
    var results = productFilter(products);
    expect(results).to.eql(products);
  });

  it('should NOT filter by empty search', function() {
    var results = productFilter(products, {text: ''});
    expect(results).to.eql(products);
  });

  it('should filter by product name', function() {
    var results = productFilter(products, {text: 'north'});
    var names = _.pluck(results, 'name');
    expect(names).to.eql(['North Carolina', 'North Dakota']);
  });

  it('should filter by team member name', function() {
    var results = productFilter(products, {text: 'daniel'});
    var names = _.pluck(results, 'name');
    expect(names).to.eql(['Reverse Logistics']);
  });
});
