describe('featureFilterSpec', function () {
  // Load Angular
  var Feature, featureFilter;
  beforeEach(module('springboard'));
  beforeEach(inject(function ($injector) {
    Feature = $injector.get('Feature');
    featureFilter = $injector.get('featureFilter');
  }));

  var features;
  beforeEach(function() {
    features = _.map([{
      id: 1,
      name: 'Maryland'
    }, {
      id: 2,
      name: 'North Carolina'
    }, {
      id: 3,
      name: 'South Carolina'
    }, {
      id: 4,
      name: 'North Dakota'
    }], Feature.fromJSON);
  });

  it('should return all results', function() {
    var results = featureFilter(features);
    expect(results).to.eql(features);
  });

  it('should NOT filter by empty search', function() {
    var results = featureFilter(features, {text: ''});
    expect(results).to.eql(features);
  });

  it('should filter by search', function() {
    var results = featureFilter(features, {text: 'north'});
    var names = _.pluck(results, 'name');
    expect(names).to.eql(['North Carolina', 'North Dakota']);
  });
});
