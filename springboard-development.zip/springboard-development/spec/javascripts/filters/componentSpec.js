describe('componentFilterSpec', function () {
  // Load Angular
  var Component, componentFilter;
  beforeEach(module('springboard'));
  beforeEach(inject(function ($injector) {
    Component = $injector.get('Component');
    componentFilter = $injector.get('componentFilter');
  }));

  var components;
  beforeEach(function() {
    components = _.map([{
      id: 1,
      name: 'States',
      features: [{
        id: 1,
        name: 'Maryland'
      }, {
        id: 2,
        name: 'North Carolina'
      }, {
        id: 3,
        name: 'South Carolina'
      }, {
        id: 4,
        name: 'North Dakota'
      }]
    }, {
      id: 2,
      name: 'Countries',
      features: [{
        id: 1,
        name: 'USA'
      }, {
        id: 2,
        name: 'Canada'
      }]
    }], Component.fromJSON);
  });

  it('should return all results', function() {
    var results = componentFilter(components);
    expect(results).to.eql(components);
  });

  it('should NOT filter by empty search', function() {
    var results = componentFilter(components, {text: ''});
    expect(results).to.eql(components);
  });

  it('should filter by search (component)', function() {
    var results = componentFilter(components, {text: 'count'});
    var names = _.pluck(results, 'name');
    expect(names).to.eql(['Countries']);
  });

  it('should filter by search (feature)', function() {
    var results = componentFilter(components, {text: 'north'});
    var names = _.pluck(results, 'name');
    expect(names).to.eql(['States']);
  });
});
