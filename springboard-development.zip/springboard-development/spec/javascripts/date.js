describe('Date', function () {
  describe('fromToday', function() {
    it('should return today', function() {
      var result = moment().toDate().fromToday();
      expect(result).to.eql('today');
    });

    it('should return yesterday', function() {
      var result = moment().subtract(1, 'day').toDate().fromToday();
      expect(result).to.eql('yesterday');
    });

    it('should return tomorrow', function() {
      var result = moment().add(1, 'day').toDate().fromToday();
      expect(result).to.eql('tomorrow');
    });

    it('should return any other date', function() {
      var result = moment('20160101').toDate().fromToday();
      expect(result).to.eql('January 1, 2016');
    });
  });
});
