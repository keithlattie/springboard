describe('Product', function () {
  // Load Angular
  var Goal;
  beforeEach(module('springboard'));
  beforeEach(inject(function ($injector) {
    Goal = $injector.get('Goal');
  }));

  var percentageGoal;
  var dollarsGoal;
  beforeEach(function() {
    percentageGoal = Goal.fromJSON({
      id: 1,
      amount: 1.23,
      amount_type: 'percentage'
    });
    dollarsGoal = Goal.fromJSON({
      id: 2,
      amount: 1234.56,
      amount_type: 'dollars'
    });
  });

  describe('formatAmount', function() {
    it('should format a percentage', function() {
      var value = percentageGoal.formatAmount();
      expect(value).to.eql('1.23%');
    });

    it('should format a dollars', function() {
      var value = dollarsGoal.formatAmount();
      expect(value).to.eql('$1,234.56');
    });
  });
});
