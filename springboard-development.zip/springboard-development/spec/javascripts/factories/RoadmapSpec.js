describe('Roadmap', function () {
  // Load Angular
  var Idea, Product, Roadmap;
  beforeEach(module('springboard'));
  beforeEach(inject(function ($injector) {
    Idea = $injector.get('Idea');
    Product = $injector.get('Product');
    Roadmap = $injector.get('Roadmap');
    Spend = $injector.get('Spend');
  }));

  var product;
  var spend;
  var inboxIdea;
  var priority1Idea;
  var priority2Idea;
  var priority3Idea;
  var openIdea;
  var inProgressIdea;
  var completedIdea;
  var ideas;
  beforeEach(function() {
    product = Product.fromJSON({
      id: 1,
      name: 'Product 1'
    });

    spend = Spend.fromJSON({
      id: 1,
      year: 2016
    });

    inboxIdea = Idea.fromJSON({
      id: 1,
      title: 'Idea 1',
      priority: null,
      spend_id: null,
      status: null
    });

    priority1Idea = Idea.fromJSON({
      id: 2,
      title: 'Idea 2',
      priority: 1,
      spend_id: null,
      status: null
    });

    priority2Idea = Idea.fromJSON({
      id: 3,
      title: 'Idea 3',
      priority: 2,
      spend_id: null,
      status: null
    });

    priority3Idea = Idea.fromJSON({
      id: 4,
      title: 'Idea 4',
      priority: 3,
      spend_id: null,
      status: null
    });

    openIdea = Idea.fromJSON({
      id: 5,
      title: 'Idea 5',
      priority: null,
      spend_id: spend.id,
      status: 'open'
    });

    inProgressIdea = Idea.fromJSON({
      id: 6,
      title: 'Idea 6',
      priority: null,
      spend_id: spend.id,
      status: 'in-progress'
    });

    completedIdea = Idea.fromJSON({
      id: 7,
      title: 'Idea 7',
      priority: null,
      spend_id: spend.id,
      status: 'completed'
    });

    ideas = [inboxIdea, priority1Idea, priority2Idea, priority3Idea, openIdea, inProgressIdea, completedIdea];
  });

  describe('createLanes', function() {
    var roadmap;

    describe('without spend', function() {
      beforeEach(function() {
        roadmap = new Roadmap(product, ideas);
      });

      it('should NOT create a roadmap lane', function() {
        var roadmap = new Roadmap(product, ideas);
        var laneIds = _.pluck(roadmap.lanes, 'id');
        expect(laneIds).to.eql(['inbox']);
      });

      it('should map ideas to queues', function() {
        var queue = _.findWhere(roadmap.queues, {id: 'inbox'});
        expect(queue.ideas).to.eql([inboxIdea]);

        var queue = _.findWhere(roadmap.queues, {id: 'priority-1'});
        expect(queue.ideas).to.eql([priority1Idea]);

        var queue = _.findWhere(roadmap.queues, {id: 'priority-2'});
        expect(queue.ideas).to.eql([priority2Idea]);

        var queue = _.findWhere(roadmap.queues, {id: 'priority-3'});
        expect(queue.ideas).to.eql([priority3Idea]);

        var queue = _.findWhere(roadmap.queues, {id: 'roadmap-' + spend.id + '-open'});
        expect(queue).to.be.undefined;

        var queue = _.findWhere(roadmap.queues, {id: 'roadmap-' + spend.id + '-in-progress'});
        expect(queue).to.be.undefined;

        var queue = _.findWhere(roadmap.queues, {id: 'roadmap-' + spend.id + '-completed'});
        expect(queue).to.be.undefined;
      });
    });

    describe('with spend', function() {
      beforeEach(function() {
        product.spends = [spend];
        roadmap = new Roadmap(product, ideas);
      });

      it('should create a roadmap lane', function() {
        var laneIds = _.pluck(roadmap.lanes, 'id');
        expect(laneIds).to.eql(['inbox', 'roadmap']);
      });

      it('should map ideas to queues', function() {
        var queue = _.findWhere(roadmap.queues, {id: 'inbox'});
        expect(queue.ideas).to.eql([inboxIdea]);

        var queue = _.findWhere(roadmap.queues, {id: 'priority-1'});
        expect(queue.ideas).to.eql([priority1Idea]);

        var queue = _.findWhere(roadmap.queues, {id: 'priority-2'});
        expect(queue.ideas).to.eql([priority2Idea]);

        var queue = _.findWhere(roadmap.queues, {id: 'priority-3'});
        expect(queue.ideas).to.eql([priority3Idea]);

        var queue = _.findWhere(roadmap.queues, {id: 'roadmap-' + spend.id + '-open'});
        expect(queue.ideas).to.eql([openIdea]);

        var queue = _.findWhere(roadmap.queues, {id: 'roadmap-' + spend.id + '-in-progress'});
        expect(queue.ideas).to.eql([inProgressIdea]);

        var queue = _.findWhere(roadmap.queues, {id: 'roadmap-' + spend.id + '-completed'});
        expect(queue.ideas).to.eql([completedIdea]);
      });
    });
  });

  describe('canMoveIdea', function() {
    var roadmap;

    beforeEach(function() {
      product.spends = [spend];
      roadmap = new Roadmap(product, ideas);
    });

    describe('move to roadmap', function() {
      var queue;

      beforeEach(function() {
        queue = _.findWhere(roadmap.queues, {id: 'roadmap-' + spend.id + '-open'});
      });

      it('should not be able to move an unestimated idea', function() {
        var canMove = Roadmap.canMoveIdea(inboxIdea, queue);
        expect(canMove).to.be.false;
      });

      it('should not be able to move a placeholder idea', function() {
        inboxIdea.investment_points = -1;
        var canMove = Roadmap.canMoveIdea(inboxIdea, queue);
        expect(canMove).to.be.false;
      });

      it('should not be able to move an estimated idea', function() {
        inboxIdea.investment_points = 1;
        var canMove = Roadmap.canMoveIdea(inboxIdea, queue);
        expect(canMove).to.be.true;
      });
    });

    describe('change status', function() {
      var tests = [
        {fromStatus: null, toStatus: null, allow: true},
        {fromStatus: null, toStatus: 'open', allow: true},
        {fromStatus: null, toStatus: 'in-progress', allow: false},
        {fromStatus: null, toStatus: 'completed', allow: false},
        {fromStatus: 'open', toStatus: null, allow: true},
        {fromStatus: 'open', toStatus: 'open', allow: true},
        {fromStatus: 'open', toStatus: 'in-progress', allow: false},
        {fromStatus: 'open', toStatus: 'completed', allow: false},
        {fromStatus: 'in-progress', toStatus: null, allow: true},
        {fromStatus: 'in-progress', toStatus: 'open', allow: false},
        {fromStatus: 'in-progress', toStatus: 'in-progress', allow: true},
        {fromStatus: 'in-progress', toStatus: 'completed', allow: false},
        {fromStatus: 'completed', toStatus: null, allow: false},
        {fromStatus: 'completed', toStatus: 'open', allow: false},
        {fromStatus: 'completed', toStatus: 'in-progress', allow: false},
        {fromStatus: 'completed', toStatus: 'completed', allow: true},
      ];

      _.each(tests, function(test) {
        var description = [test.allow ? 'should' : 'should NOT', 'move between', test.fromStatus || 'null', 'and', test.toStatus || 'null'].join(' ');

        it(description, function() {
          var idea = _.findWhere(ideas, {status: test.fromStatus});
          idea.investment_points = 1;

          var toQueue = _.find(roadmap.queues, function(queue) {
            var status = queue.status ? queue.status.id : null;
            return status === test.toStatus;
          });

          var canMove = Roadmap.canMoveIdea(idea, toQueue);
          expect(canMove).to.eql(test.allow);
        });
      });
    });
  });

  describe('moveIdea', function() {
    var roadmap;

    beforeEach(function() {
      product.spends = [spend];
      roadmap = new Roadmap(product, ideas);
    });

    it('move an idea between queue (no index)', function() {
      var fromQueue = _.findWhere(roadmap.queues, {id: 'priority-1'});
      var toQueue = _.findWhere(roadmap.queues, {id: 'priority-2'});
      roadmap.moveIdea(priority1Idea, fromQueue, toQueue);

      expect(fromQueue.ideas).to.eql([]);
      expect(toQueue.ideas).to.eql([priority2Idea, priority1Idea]);
      expect(priority1Idea.position).to.eql(2);
    });

    it('move an idea between queue (with index)', function() {
      var fromQueue = _.findWhere(roadmap.queues, {id: 'priority-1'});
      var toQueue = _.findWhere(roadmap.queues, {id: 'priority-2'});
      roadmap.moveIdea(priority1Idea, fromQueue, toQueue, 0);

      expect(fromQueue.ideas).to.eql([]);
      expect(toQueue.ideas).to.eql([priority1Idea, priority2Idea]);
      expect(priority1Idea.position).to.eql(1);
    });
  });

  describe('removeIdea', function() {
    var roadmap;

    beforeEach(function() {
      product.spends = [spend];
      roadmap = new Roadmap(product, ideas);
    });

    it('remove an idea from the roadmap/queue', function() {
      var queue = _.findWhere(roadmap.queues, {id: 'inbox'});
      roadmap.removeIdea(inboxIdea);

      expect(roadmap.ideas).to.not.contain(inboxIdea);
      expect(queue.ideas).to.not.contain(inboxIdea);
    });
  });
});
