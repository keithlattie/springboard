describe('Product', function () {
  // Load Angular
  var Component, Product;
  beforeEach(module('springboard'));
  beforeEach(inject(function ($injector) {
    Component = $injector.get('Component');
    Product = $injector.get('Product');
  }));

  var product;
  beforeEach(function() {
    product = Product.fromJSON({
      id: 1,
      name: 'Product 1',
      components: [{
        id: 1,
        position: 1,
        name: 'Component 1',
        features: [{
          id: 1,
          component_id: 1,
          position: 1,
          name: 'Feature 1.1'
        }, {
          id: 2,
          component_id: 1,
          position: 2,
          name: 'Feature 1.2'
        }]
      }, {
        id: 2,
        position: 2,
        name: 'Component 2',
        features: [{
          id: 3,
          component_id: 2,
          position: 1,
          name: 'Feature 2.1'
        }]
      }]
    });
  });

  describe('fromJSON', function() {
    it('load components/features', function() {
      var component = _.first(product.components);
      expect(component.$patch).to.not.be.undefined;

      var feature = _.first(component.features);
      expect(feature.$patch).to.not.be.undefined;
    });
  });

  describe('findPinnable', function() {
    it('should find a component', function() {
      var component = product.findPinnable('Component', 1);
      expect(component.name).to.eql('Component 1')
    });

    it('should find a feature', function() {
      var feature = product.findPinnable('Feature', 2);
      expect(feature.name).to.eql('Feature 1.2')
    });
  });

  describe('mapPinnable', function() {
    it('should map a component', function() {
      var pinnable = {
        id: 1,
        pinnable_type: 'Component',
        pinnable_id: 1
      };
      var result = product.mapPinnable(pinnable);

      expect(result.id).to.eql(pinnable.id);
      expect(result.component.name).to.eql('Component 1');
      expect(result.feature).to.be.undefined;
    });

    it('should map a feature', function() {
      var pinnable = {
        id: 1,
        pinnable_type: 'Feature',
        pinnable_id: 2
      };
      var result = product.mapPinnable(pinnable);
      expect(result.id).to.eql(pinnable.id);
      expect(result.component.name).to.eql('Component 1');
      expect(result.feature.name).to.eql('Feature 1.2');
    });
  });
});
