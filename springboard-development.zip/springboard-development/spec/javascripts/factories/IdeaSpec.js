describe('Idea', function () {
  // Load Angular
  var Goal, Idea, Session, User, Versionable;
  beforeEach(module('springboard'));
  beforeEach(inject(function ($injector) {
    Goal = $injector.get('Goal');
    Idea = $injector.get('Idea');
    Session = $injector.get('Session');
    User = $injector.get('User');
    Versionable = $injector.get('Versionable');
  }));

  var viewer;
  var editor;
  var originator;
  var idea;
  beforeEach(function() {
    viewer = User.fromJSON({
      id: 1,
      first_name: 'Viewer'
    });
    editor = User.fromJSON({
      id: 2,
      first_name: 'Editor',
      editor: true
    });
    originator = User.fromJSON({
      id: 3,
      first_name: 'originator'
    });
    idea = Idea.fromJSON({
      id: 1,
      title: 'Idea 1',
      originator_id: originator.id
    });
  });

  describe('canEdit', function() {
    it('should NOT allow unauthenticated to edit', function() {
      var canEdit = idea.canEdit();
      expect(canEdit).to.be.false;
    });

    it('should allow viewer to edit', function() {
      Session.user = viewer;
      var canEdit = idea.canEdit();
      expect(canEdit).to.be.false;
    });

    it('should allow editor to edit', function() {
      Session.user = editor;
      var canEdit = idea.canEdit();
      expect(canEdit).to.be.true;
    });

    it('should allow originator to edit', function() {
      Session.user = originator;
      var canEdit = idea.canEdit();
      expect(canEdit).to.be.true;
    });
  });

  describe('hasInvestmentPoints', function() {
    it('should be false for null', function() {
      idea.investment_points = null;
      expect(idea.hasInvestmentPoints()).to.be.false;
    });

    it('should be false for placeholder', function() {
      idea.investment_points = -1;
      expect(idea.hasInvestmentPoints()).to.be.false;
    });

    it('should be true for 0', function() {
      idea.investment_points = 0;
      expect(idea.hasInvestmentPoints()).to.be.true;
    });

    it('should be true for > 0', function() {
      idea.investment_points = 1;
      expect(idea.hasInvestmentPoints()).to.be.true;
    });
  });

  describe('versions', function() {
    it('should format a create version', function() {
      var messages = Versionable.format({
        event: 'create'
      }, Idea.formatVersion);

      expect(messages).to.eql(['created this idea.']);
    });

    describe('status change', function() {
      var tests = [
        {before: null, after: 'open', message: 'added to roadmap.'},
        {before: 'open', after: null, message: 'removed from roadmap.'},
        {before: 'open', after: 'in-progress', message: 'changed the status to "in-progress".'},
        {before: 'open', after: 'completed', message: 'changed the status to "completed".'},
        {before: 'in-progress', after: null, message: 'removed from roadmap.'},
        {before: 'in-progress', after: 'open', message: 'changed the status to "open".'},
        {before: 'in-progress', after: 'completed', message: 'changed the status to "completed".'},
        {before: 'completed', after: 'open', message: 'changed the status to "open".'},
        {before: 'completed', after: 'in-progress', message: 'changed the status to "in-progress".'}
      ];

      _.each(tests, function(test) {
        var description = ['should format a status change from', before || 'null', 'to', after || 'null'].join(' ');
        it(description, function() {
          var messages = Versionable.format({
            event: 'update',
            changeset: {
              status: [test.before, test.after]
            }
          }, Idea.formatVersion);

          expect(messages).to.eql([test.message]);
        });
      });
    });
  });

  describe('hasGoalMetric', function() {
    var goal;
    beforeEach(function() {
      goal = Goal.fromJSON({
        id: 1,
        metric_id: 1
      });
      idea.goals = [goal];
    });

    it('should NOT have a metric', function() {
      expect(idea.hasGoalMetric(goal.id + 99)).to.be.false;
    });

    it('should have a metric', function() {
      expect(idea.hasGoalMetric(goal.id)).to.be.true;
    });
  });
});
