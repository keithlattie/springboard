describe('User', function () {
  // Load Angular
  var User;
  beforeEach(module('springboard'));
  beforeEach(inject(function ($injector) {
    User = $injector.get('User');
  }));

  var user;
  var user2;
  beforeEach(function() {
    user = User.fromJSON({
      id: 1,
      first_name: 'Scuba',
      last_name: 'Steve'
    });
    user2 = User.fromJSON({
      id: 1,
      first_name: 'Sideshow Bob',
      last_name: 'Terwilliger'
    });
  });

  describe('fullName', function() {
    it('it should combine first and last', function() {
      expect(user.fullName).to.eql('Scuba Steve');
      expect(user2.fullName).to.eql('Sideshow Bob Terwilliger');
    });
  });

  describe('initials', function() {
    it('it should chose first and last initial', function() {
      expect(user.initials).to.eql('SS');
      expect(user2.initials).to.eql('ST');
    });
  });
});
