require 'rails_helper'

RSpec.describe Api::FavoritesController, type: :controller do

  context "when logged in" do
    before do
      login_user
    end

    describe "GET #index" do
      let!(:favorite) { FactoryGirl.create(:favorite, user: @user) }
      it "returns http success" do
        get :index, format: :json
        expect(response).to have_http_status(:success)
      end
    end

    describe "GET #create" do
      let!(:product) { FactoryGirl.create(:product) }
      it "returns http created" do
        get :create, format: :json, favorite: { favorable_type: 'Product', favorable_id: product.id }
        expect(response).to have_http_status(:created)
      end
    end

    describe "GET #destroy" do
      let!(:favorite) { FactoryGirl.create(:favorite, user: @user) }
      let!(:product) { favorite.favorable }

      it "returns http no content" do
        get :destroy, format: :json, id: favorite.id
        expect(response).to have_http_status(:no_content)
        expect(response.body).to be_empty
      end
    end
  end

  context "when not logged in" do
    let!(:user) { create(:user) }
    describe "GET #index" do
      let!(:favorite) { FactoryGirl.create(:favorite, user: user) }
      it "returns http success" do
        get :index, format: :json
        expect(response).to have_http_status(:unauthorized)
      end
    end

    describe "GET #create" do
      let!(:product) { FactoryGirl.create(:product) }
      it "returns http unauthorized" do
        get :create, format: :json, favorite: { favorable_type: 'Product', favorable_id: product.id }
        expect(response).to have_http_status(:unauthorized)
      end
    end

    describe "GET #destroy" do
      let!(:favorite) { FactoryGirl.create(:favorite, user: user) }
      let!(:product) { favorite.favorable }

      it "returns http unauthorized" do
        get :destroy, format: :json, id: favorite.id
        expect(response).to have_http_status(:unauthorized)
      end
    end
  end
end
