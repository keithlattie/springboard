require 'rails_helper'

RSpec.describe SessionController, type: :controller do

  describe "GET /session" do
    context "when not logged in" do
      it "should NOT return a user" do
        get :show, format: :json
        expect(response).to have_http_status(:unauthorized)
        expect(response.body).to include(I18n.t('devise.failure.unauthenticated'))
      end
    end

    context "when logged in" do
      before do
        login_user
        get :show, format: :json
      end
      subject { response }

      it { is_expected.to have_http_status(:success) }

    end

    context "with an expired thd_login" do
      pending("This feature is managed by Devise Rememberable configuration (see `config/initializers/devise.rb`...not sure if we need to test this anymore?")
      # before do
      #   login_user
      #   cookies[:thd_login] = nil
      #   get :show, format: :json
      # end
      # subject { response }
      # it { is_expected.to have_http_status(:not_found) }
    end
  end
end
