require 'rails_helper'

RSpec.describe User, type: :model do
	describe "when saving and accessing Favorites" do
		describe "and Favoring a Product" do
			subject        { FactoryGirl.create(:user) }
			let!(:product) { FactoryGirl.create(:product) }
			before do
				subject.favorite_products << product
			end
			it "should be able to access the Favorite Product" do
				expect(subject.favorite_products).to include(product)
			end
		end
	end

	describe "managing THD user groups" do
		context "without an SSO Token" do
			let!(:user) { create(:user) }
			describe "when getting a THD profile" do
				it "should return nil" do
					expect(user.thd_profile).to be_nil
				end
			end

			describe "when getting THD User Groups" do
				it "should return an empty Array" do
					expect(user.thd_user_groups).to eq(Array.new)
				end
			end

			describe "when refreshing THD User Groups" do
				before { user.refresh_thd_groups }
				it "should set `home_depot_user_groups` to an empty Array" do
					expect(user.home_depot_user_groups).to eq(Array.new)
				end
			end
		end

		context "with an SSO Token" do
			let!(:admin) { create(:admin) }
			before do
				admin.sso_token = "#{admin.username}.cookie"
			end

			describe "when getting a THD profile" do
				it "should return a THD Profile" do
					expect(admin.thd_profile).to be_kind_of(HomeDepotAuthentication::UserProfile)
				end
			end

			describe "when getting THD User Groups" do
				it "should return an Array of all THD Groups" do
					expect(admin.thd_user_groups).to eq(['SpringBoard Admin', 'SpringBoard Editor', 'Random Non-Springboard Group'])
				end
			end

			describe "when refreshing THD User Groups" do
				before { admin.refresh_thd_groups }
				it "should only set `home_depot_user_groups` to Springboard specific Groups" do
          expect(admin.home_depot_user_groups).to eq(['SpringBoard Admin', 'SpringBoard Editor'])
          expect(admin.home_depot_user_groups).to_not include('Random Non-Springboard Group')
				end
			end
		end
	end
end
