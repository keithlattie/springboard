require 'rails_helper'

RSpec.describe Component, type: :model do
  let!(:portfolio) { FactoryGirl.create(:portfolio) }

  describe "sort" do
    let!(:product) { FactoryGirl.create(:product, portfolio: portfolio) }
    let!(:component) { FactoryGirl.create(:component, product: product) }
    let!(:component2) { FactoryGirl.create(:component, product: product) }
    let!(:component3) { FactoryGirl.create(:component, product: product) }
    let!(:product2) { FactoryGirl.create(:product, portfolio: portfolio) }
    let!(:component4) { FactoryGirl.create(:component, product: product2) }

    it "should move a product down" do
      component.update(position: 3)
      component2.reload
      component3.reload

      expect(component2.position).to eql(1)
      expect(component3.position).to eql(2)
      expect(component.position).to eql(3)
    end

    it "should move a product up" do
      component3.update(position: 1)
      component.reload
      component2.reload

      expect(component3.position).to eql(1)
      expect(component.position).to eql(2)
      expect(component2.position).to eql(3)
    end
  end
end
