require 'rails_helper'

RSpec.describe Spend, type: :model do
  it "can store large expense and capital values" do
    #checking to ensure we have the right MySQL field type for a $1B project.
    large_money_amount = 1_000_000_000
    spend = create(:spend, expense: large_money_amount, capital: large_money_amount)
    expect(spend).to be_persisted
    expect(spend.expense).to eq(large_money_amount)
    expect(spend.capital).to eq(large_money_amount)
  end
end
