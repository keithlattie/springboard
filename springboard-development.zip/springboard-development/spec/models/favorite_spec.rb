require 'rails_helper'

RSpec.describe Favorite, type: :model do
  subject { FactoryGirl.create(:favorite) }
  it { is_expected.to be_valid }
  it { is_expected.to be_persisted }
end
