require 'rails_helper'

describe Import::Utils do

  describe ".get_category_name" do
    it { expect(described_class.get_category_name('sales')).to eq('Sales') }
    it { expect(described_class.get_category_name('margin')).to eq('Gross Margin') }
    it { expect(described_class.get_category_name('turns')).to eq('Inventory Turns') }
    it { expect(described_class.get_category_name('cost')).to eq('Costs') }
    it { expect(described_class.get_category_name('shouldnotfail')).to be_blank }
  end

  describe ".get_metric_name" do
    it { expect(described_class.get_metric_name('sales')).to eq('Sales') }
    it { expect(described_class.get_metric_name('margin')).to eq('Gross Margin') }
    it { expect(described_class.get_metric_name('turns')).to eq('Inventory Turns') }
    it { expect(described_class.get_metric_name('cost')).to eq('Costs') }

    it { expect(described_class.get_metric_name('sales', 'voc')).to eq('Customer VOC Metrics') }
    it { expect(described_class.get_metric_name('cost', 'operations')).to eq('Operating expenses (% of sales)') }
    it { expect(described_class.get_metric_name('margin', 'cogs')).to eq('Cost of Goods Sold') }
    it { expect(described_class.get_metric_name('turns', 'onhand')).to eq('Average Inventory On Hand') }
    it { expect(described_class.get_metric_name('turns', 'typo')).to be_blank }

    it { expect(described_class.get_metric_name('cost', 'labor', 'hours')).to eq('Labor % of Sales - Sales per Labor Hour') }
    it { expect(described_class.get_metric_name('sales', 'comp', 'transaction')).to eq('Comparable Store Sales - Transaction Comp') }
    it { expect(described_class.get_metric_name('sales', 'comp', 'type')).to eq('Comparable Store Sales') }

    # Using Array pointers...which is how I expect to use this in the real code...
    let(:horizon_string) { 'sales.comp.transaction'.split('.') }
    it { expect(described_class.get_metric_name(*horizon_string)).to eq('Comparable Store Sales - Transaction Comp') }

  end

  describe ".get_directionality" do
    it { expect(described_class.get_directionality('sales')).to eq('up') }
    it { expect(described_class.get_directionality('sales', 'comp')).to eq('up') }

    it { expect(described_class.get_directionality('margin')).to eq('up') }
    it { expect(described_class.get_directionality('cost')).to eq('down') }
    it { expect(described_class.get_directionality('cost', 'operations')).to eq('down') }
    it { expect(described_class.get_directionality('cost', 'labor')).to eq('down') }

    it { expect(described_class.get_directionality('turns')).to eq('up') }
    it { expect(described_class.get_directionality('sales', 'returns')).to eq('down') }
  end
end