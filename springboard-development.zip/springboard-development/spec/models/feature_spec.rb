require 'rails_helper'

RSpec.describe Feature, type: :model do
  let!(:portfolio) { FactoryGirl.create(:portfolio) }
  let!(:product) { FactoryGirl.create(:product, portfolio: portfolio) }

  describe "sort" do
    let!(:component) { FactoryGirl.create(:component, product: product) }
    let!(:feature) { FactoryGirl.create(:feature, component: component) }
    let!(:feature2) { FactoryGirl.create(:feature, component: component) }
    let!(:feature3) { FactoryGirl.create(:feature, component: component) }
    let!(:component2) { FactoryGirl.create(:component, product: product) }
    let!(:feature4) { FactoryGirl.create(:feature, component: component2) }

    it "should move a feature down" do
      feature.update(position: 3)
      feature2.reload
      feature3.reload

      expect(feature2.position).to eql(1)
      expect(feature3.position).to eql(2)
      expect(feature.position).to eql(3)
    end

    it "should move a feature up" do
      feature3.update(position: 1)
      feature.reload
      feature2.reload

      expect(feature3.position).to eql(1)
      expect(feature.position).to eql(2)
      expect(feature2.position).to eql(3)
    end
  end
end
