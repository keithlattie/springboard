require 'rails_helper'

RSpec.describe TeamMember, type: :model do
  it "can only have one product owner at a time" do
    product_owner = create(:team_member, :product_owner)
    second_product_owner = build(:team_member, :product_owner, product_id: product_owner.product_id)
    expect(second_product_owner).to_not be_valid
  end

  it "can have more than one role though" do
    product_owner = create(:team_member, :product_owner)
    second_team_member = build(:team_member, :architect, product_id: product_owner.product_id)
    expect(second_team_member).to be_valid
  end

  it "can update the product owner name" do
    product_owner = create(:team_member, :product_owner)

    product_owner.name = 'New Name Which Has Yet To Be Validated'
    expect(product_owner).to be_valid
  end
end
