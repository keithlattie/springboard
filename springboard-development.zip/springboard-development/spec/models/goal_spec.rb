require 'rails_helper'

RSpec.describe Product, type: :model do
  let(:originator) { create(:viewer) }
  let(:creator) { create(:viewer) }

  let!(:portfolio) { create(:portfolio) }
  let!(:product) { create(:product, portfolio: portfolio) }
  let!(:idea) { create(:idea, product: product, created_by: creator.id, originator: originator) }

  let!(:metric_category) { create(:metric_category) }
  let!(:metric) { create(:metric, metric_category: metric_category)}
  let!(:goal) { create(:goal, idea: idea, metric: metric) }

	describe "amount" do
		it "should convert to hundreths" do
      goal.amount = 120.357
			expect(goal.amount_hundreths).to eql(12036)
		end

		it "should convert from hundreths" do
      goal.amount_hundreths = 735623
			expect(goal.amount).to eql(7356.23)
		end
	end
end
