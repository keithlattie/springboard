require 'rails_helper'

RSpec.describe Product, type: :model do
	describe "image_url" do
		it "should have a default url" do
			product = FactoryGirl.create(:product)
			expect(product.image_url).to eql(Product::DEFAULT_IMAGE_URL)
		end

		it "should override the url" do
			product = FactoryGirl.create(:product, image_url: '/path/to/a/url.jpg')
			expect(product.image_url).to eql('/path/to/a/url.jpg')
		end
	end

	describe "when saving and accessing Favorites" do
		describe "and Favoring a User" do
			let!(:user)       { FactoryGirl.create(:user) }
			subject(:product) { FactoryGirl.create(:product) }
			before do
				subject.favored_users << user
			end
			it "should be able to access the favored user" do
				expect(subject.favored_users).to include(user)
			end
		end
	end
end
