FactoryGirl.define do
  factory :team_member do
    product
    role { TeamMember::ROLES.sample }
    sequence(:name) { |n| "Name ##{n}" }

    trait :product_owner do
      role TeamMember::PRODUCT_OWNER
    end

    trait :architect do
      role TeamMember::ARCHITECT
    end
  end

  factory :spend do
    product
    year 2016
    kind { ['Plan', 'Spend'].sample }
    capital 123456789
    expense 12345678
  end

  factory :benefit do
    sequence(:name) { |n| "Benefit #{n}" }
    beneficial factory: :component #polymorphic interface, could be a Feature also
  end

  factory :metric do
    sequence(:name) { |n| "Metric #{n}" }
    metric_category
    directionality { %w{up down}.sample }
  end

  factory :metric_category do
    sequence(:name) { |n| "Metric Category #{n}" }
    icon "fa-test"
  end

  factory :favorite do
    user
    favorable factory: :product
  end

  factory :user, aliases: [:viewer] do
    sequence(:username) { |n| "user#{n}" }
    sequence(:email) { |n| "user#{n}@homedepot.com" }
    sequence(:first_name) { |n| "First ##{n}" }
    sequence(:last_name) { |n| "Last ##{n}" }

    after(:create) do |user|
      Rails.configuration.thd_users << {
        user_id: user.username,
        password: user.username,
        e_mail_address: user.email,
        first_name: user.first_name,
        last_name: user.last_name,
        user_groups: ['Random Non-Springboard Group'],
      }
    end
  end

  factory :editor, class: User do
    sequence(:username) { |n| "editor#{n}" }
    sequence(:email) { |n| "editor_#{n}@homedepot.com" }
    sequence(:first_name) { |n| "First ##{n}" }
    sequence(:last_name) { |n| "Last ##{n}" }

    after(:create) do |user|
      Rails.configuration.thd_users << {
        user_id: user.username,
        password: user.username,
        e_mail_address: user.email,
        first_name: user.first_name,
        last_name: user.last_name,
        user_groups: ['SpringBoard Editor', 'Random Non-Springboard Group'],
      }
    end
  end

  factory :admin, class: User do
    sequence(:username) { |n| "admin#{n}" }
    sequence(:email) { |n| "admin_#{n}@homedepot.com" }
    sequence(:first_name) { |n| "First ##{n}" }
    sequence(:last_name) { |n| "Last ##{n}" }

    after(:create) do |user|
      Rails.configuration.thd_users << {
        user_id: user.username,
        password: user.username,
        e_mail_address: user.email,
        first_name: user.first_name,
        last_name: user.last_name,
        user_groups: ['SpringBoard Admin', 'SpringBoard Editor', 'Random Non-Springboard Group'],
      }
    end
  end

  factory :portfolio do
    sequence(:name) { |n| "Portfolio ##{n}" }
  end

  factory :product do
    portfolio
    sequence(:name) { |n| "Product ##{n}" }
    sequence(:description) { |n| "Product Description ##{n}" }
  end

  factory :component do
    sequence(:name) { |n| "Component ##{n}" }
    sequence(:description) { |n| "Component Description ##{n}" }
  end

  factory :feature do
    sequence(:name) { |n| "Feature ##{n}" }
    sequence(:description) { |n| "Feature Description ##{n}" }
  end

  factory :idea do
    sequence(:title) { |n| "Idea ##{n}" }
  end

  factory :goal do
  end
end
