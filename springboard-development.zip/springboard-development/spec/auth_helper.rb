module AuthHelper
  def login(user, password = user.username)
    post user_session_path, format: :json, user: { username: user.username, password: password }
  end
end

RSpec.configure do |config|
  config.include AuthHelper, type: :request
end
