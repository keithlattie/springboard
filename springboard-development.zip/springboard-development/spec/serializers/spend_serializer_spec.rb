require 'rails_helper'

RSpec.describe SpendSerializer, type: :serializer do

  let!(:capital_value) { 12_345_678 }
  let!(:expense_value) { 234_567_890 }

  let!(:spend) { create(:spend, capital: capital_value, expense: expense_value) }

  #JSON should have this structure
  let(:expectation_data) {
    {
      "id": spend.id,
      "year": spend.year,
      "kind": spend.kind,
      "capital": capital_value,
      "expense": expense_value,
      "created_by": spend.created_by,
      "updated_by": spend.updated_by,
    }
  }

  subject(:serializer) { described_class.new(spend) }

  it "should contain the same structure" do
    expect(serializer.as_json).to eql(expectation_data)
  end
end