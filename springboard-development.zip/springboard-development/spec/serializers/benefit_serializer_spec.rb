require 'rails_helper'

RSpec.describe BenefitSerializer, type: :serializer do

  let(:metric1)  { FactoryGirl.create(:metric) }
  let(:metric2) { FactoryGirl.create(:metric) }
  let(:metric3) { FactoryGirl.create(:metric, metric_category: metric2.metric_category) }
  let(:benefit) { FactoryGirl.create(:benefit, metrics: [metric1, metric2, metric3]) }

  #Benefit JSON should look like this
  let(:expectation_data) {
    {
      "id": benefit.id,
      "name": benefit.name,
      "beneficial_id": benefit.beneficial_id,
      "beneficial_type": benefit.beneficial_type,
      "created_at": benefit.created_at,
      "updated_at": benefit.updated_at,
      "created_by": benefit.created_by,
      "updated_by": benefit.updated_by,
      "metric_ids": [metric1.id, metric2.id, metric3.id]
    }
  }

  subject(:serializer) { described_class.new(benefit) }

  it "should contain the same structure" do
    expect(serializer.as_json).to eql(expectation_data)
  end
end
