require 'rails_helper'

RSpec.describe ProductDetailsSerializer, type: :serializer do

  let(:product) { create(:product) }
  subject { described_class.new(product, thd_groups: thd_groups).as_json }

  describe "when logged in as an admin" do
    let!(:thd_groups) { [Rails.configuration.thd_groups["admin"]] }
    it { is_expected.to have_key(:spends) }
    it { is_expected.to have_key(:team_members) }
  end

  describe "when logged in as an editor" do
    let!(:thd_groups) { [Rails.configuration.thd_groups["editor"]] }
    it { is_expected.to have_key(:spends) }
    it { is_expected.to have_key(:team_members) }
  end

  describe "when logged in as a viewer or not logged in" do
    let!(:thd_groups) { [] }
    it { is_expected.to have_key(:spends) }
    it { is_expected.to have_key(:team_members) }
  end
end
