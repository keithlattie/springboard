#Specs that govern application wide behavior and are not specific to a single controller or API endpoint

require 'rails_helper'
require 'auth_helper'

RSpec.describe "Application", type: :request do

  let(:admin) { create(:admin) }

  context "on each authenticated request" do
    it "should always check THD Groups" do

      expect(HomeDepotAuthentication).to receive(:in_memory_login_service).twice.and_call_original

      login(admin) #logs in and calls Authentication code
      get api_products_path, format: :json #s

    end

    #skip for now
    xit "should detect THD User group changes" do
      # let(:thd_profile_double) {
      #   instance_double(HomeDepotAuthentication::UserProfile,
      #     e_mail_address: "admin_1@homedepot.com",
      #     first_name: "Rocket",
      #     last_name: "Whale Admin",
      #     user_groups: ["SpringBoard Admin", "SpringBoard Editor"],
      #     user_id: "rocketwhale"
      #   )
      # }

      pending "We can implement this if we need it - but the above spec asserts that we are interacting with the login service on each request at least, even if we aren't directly asserting that THD Groups have changed between requests"

      #stub get_authentication_profile method, return a specific Profile
      #get a request, check the current users groups
      #restub get_authentication_profile, return a newer profile with different groups
      #get a request, check the current users groups again
    end
  end
end