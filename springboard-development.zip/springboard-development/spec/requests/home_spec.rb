require 'rails_helper'
require 'auth_helper'

RSpec.describe "Home", type: :request do

  let(:user) { create(:user) }

  describe "GET /" do
    it "should show home page" do
      login user
      get root_path
      expect(response).to have_http_status(200)
      expect(response.body).to include("Sign Out")
    end
  end

end
