require 'rails_helper'
require 'auth_helper'

RSpec.describe "Session", type: :request do

  let(:user) { create(:user) }

  describe "GET /session" do
    it "should NOT return a user" do
      get session_path, format: :json
      expect(response).to have_http_status(:unauthorized)
      expect(response.body).to include(I18n.t('devise.failure.unauthenticated'))
    end

    context "when logged in" do
      before do
        create(:favorite, user: user)
        login user
        get session_path, format: :json
      end

      subject { JSON.parse(response.body) }

      it { expect(response).to have_http_status(:success) }
      it { expect(subject["user"]).to_not be_nil }
      it { expect(subject["user"]["favorites"].length).to eq(1) }
    end
  end
end
