require 'rails_helper'
require 'auth_helper'

RSpec.describe "Spends Controller", type: :request do

  let(:admin) { create(:admin) }
  let(:editor) { create(:editor) }
  let(:user) { create(:user) }

  describe "POST /product/:product_id/spends" do

    let!(:product) { create(:product) }
    let!(:spend_attributes_and_format) { attributes_for(:spend).merge(format: :json) }

    it "should return 401" do
      post api_product_spends_path(product), spend_attributes_and_format
      expect(response).to have_http_status(401)
    end

    it "viewers should return 403" do
      login user
      post api_product_spends_path(product), spend_attributes_and_format
      expect(response).to have_http_status(403)
    end

    it "editors should return 201" do
      login editor
      expect {
        post api_product_spends_path(product), spend_attributes_and_format
        expect(response).to have_http_status(201)
      }.to change(product.spends, :count).by(1)
    end

    it "should update the name" do
      login admin
      expect {
        post api_product_spends_path(product), spend_attributes_and_format
        expect(response).to have_http_status(201)
      }.to change(product.spends, :count).by(1)
    end
  end

  describe "PATCH /spends/:id" do
    let!(:spend) { create(:spend) }

    it "should return 401" do
      patch api_spend_path(spend), format: :json, year: spend.year + 1
      expect(response).to have_http_status(401)
    end

    it "viewers should return 403" do
      login user
      patch api_spend_path(spend), format: :json, year: spend.year + 1
      expect(response).to have_http_status(403)
    end

    it "editors should return 201" do
      login editor
      expect {
        patch api_spend_path(spend), format: :json, year: spend.year + 1
        expect(response).to have_http_status(201)
        spend.reload
        expect(spend.updated_by).to eql(editor.id)
      }.to change(spend, :year).by(1)
    end

    it "should update the name" do
      login admin
      expect {
        patch api_spend_path(spend), format: :json, year: spend.year + 1
        expect(response).to have_http_status(201)
        spend.reload
        expect(spend.updated_by).to eql(admin.id)
      }.to change(spend, :year).by(1)
    end
  end

  describe "DELETE /spends/:id" do
    let!(:spend) { create(:spend) }

    it "should return 401" do
      delete api_spend_path(spend), format: :json
      expect(response).to have_http_status(401)
    end

    it "viewers should return 403" do
      login user
      delete api_spend_path(spend), format: :json
      expect(response).to have_http_status(403)
    end

    it "editors should return 204" do
      login editor
      expect {
        delete api_spend_path(spend), format: :json
        expect(response).to have_http_status(204)
      }.to change(Spend, :count).by(-1)
    end

    it "should delete the spend" do
      login admin
      spend
      expect {
        delete api_spend_path(spend), format: :json
        expect(response).to have_http_status(204)
      }.to change(Spend, :count).by(-1)
    end
  end
end
