require 'rails_helper'
require 'auth_helper'

RSpec.describe "Products", type: :request do

  let(:admin) { create(:admin) }
  let(:editor) { create(:editor) }
  let(:user) { create(:user) }
  let!(:portfolio) { create(:portfolio) }
  let!(:product) { create(:product, portfolio: portfolio) }
  let!(:component) { create(:component, product: product) }
  let!(:feature) { create(:feature, component: component) }

  describe "GET /products" do
    it "should return all products" do
      get api_products_path, format: :json
      expect(response).to have_http_status(200)
      json = JSON.parse(response.body)
      expect(json.length).to eql(1)

      product_json = json[0]
      expect(product_json['id']).to eql(product.id)
      expect(product_json['components']).to be_nil
    end
  end

  describe "GET /products/:id" do
    it "should return the product/components/features" do
      get api_product_path(product), format: :json
      expect(response).to have_http_status(200)
      json = JSON.parse(response.body)
      expect(json['id']).to eql(product.id)
      expect(json['image_url']).to eql(Product::DEFAULT_IMAGE_URL)

      component_json = json['components'][0]
      expect(component_json['id']).to eql(component.id)

      feature_json = component_json['features'][0]
      expect(feature_json['id']).to eql(feature.id)

    end
  end

  describe "POST /products" do
    it "should return 401" do
      post api_products_path, format: :json, name: "New Name"
      expect(response).to have_http_status(401)
    end

    it "should return 403" do
      login editor
      post api_products_path, format: :json, name: "New Name"
      expect(response).to have_http_status(403)
    end

    it "should create a product" do
      login admin
      expect {
        post api_products_path, format: :json, name: "New Name"
        expect(response).to have_http_status(201)
        json = JSON.parse(response.body)
        expect(json['created_by']).to eql(admin.id)
        expect(json['updated_by']).to eql(admin.id)
      }.to change(Product, :count).by(1)
    end
  end

  describe "PATCH /products/:id" do
    it "should return 401" do
      patch api_product_path(product), format: :json, name: "New Name"
      expect(response).to have_http_status(401)
    end

    it "should return 403" do
      login user
      patch api_product_path(product), format: :json, name: "New Name"
      expect(response).to have_http_status(403)
    end

    it "should update the name" do
      login editor
      expect {
        patch api_product_path(product), format: :json, name: "New Name"
        expect(response).to have_http_status(201)
        product.reload
        expect(product.updated_by).to eql(editor.id)
      }.to change(product, :name).to("New Name")
    end
  end

  describe "DELETE /products/:id" do
    it "should return 401" do
      delete api_product_path(product), format: :json
      expect(response).to have_http_status(401)
    end

    it "should return 403" do
      login editor
      delete api_product_path(product), format: :json
      expect(response).to have_http_status(403)
    end

    it "should delete the product's components" do
      login admin
      product
      expect {
        delete api_product_path(product), format: :json
        expect(response).to have_http_status(204)
      }.to change(Component, :count).by(-1)
    end

    it "should delete the product's features" do
      login admin
      product
      expect {
        delete api_product_path(product), format: :json
        expect(response).to have_http_status(204)
      }.to change(Feature, :count).by(-1)
    end
  end
end
