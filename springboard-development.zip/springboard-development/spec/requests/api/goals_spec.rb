require 'rails_helper'
require 'auth_helper'

RSpec.describe "Goals", type: :request do

  let(:editor) { create(:editor) }
  let(:viewer) { create(:viewer) }
  let(:originator) { create(:viewer) }
  let(:creator) { create(:viewer) }

  let!(:portfolio) { create(:portfolio) }
  let!(:product) { create(:product, portfolio: portfolio) }
  let!(:idea) { create(:idea, product: product, created_by: creator.id, originator: originator) }

  let!(:metric_category) { create(:metric_category) }
  let!(:metric) { create(:metric, metric_category: metric_category)}
  let!(:goal) { create(:goal, idea: idea, metric: metric) }

  describe "POST /ideas/:idea_id/goals" do
    it "should return 401" do
      post api_idea_goals_path(idea), format: :json, metric_id: metric.id
      expect(response).to have_http_status(401)
    end

    it "should create a idea" do
      login creator
      expect {
        post api_idea_goals_path(idea), format: :json, metric_id: metric.id
        expect(response).to have_http_status(201)
        json = JSON.parse(response.body)
        expect(json['idea_id']).to eql(idea.id)
        expect(json['metric_id']).to eql(metric.id)
        expect(json['created_by']).to eql(creator.id)
      }.to change(Goal, :count).by(1)
    end
  end

  describe "DELETE /goals/:id" do
    it "should return 401" do
      delete api_goal_path(goal), format: :json
      expect(response).to have_http_status(401)
    end

    it "should return 403" do
      login viewer
      delete api_goal_path(goal), format: :json
      expect(response).to have_http_status(403)
    end

    it "should delete the idea (editor)" do
      login editor
      expect {
        delete api_goal_path(goal), format: :json
        expect(response).to have_http_status(204)
      }.to change(Goal, :count).by(-1)
    end

    it "should delete the idea (creator)" do
      login creator
      expect {
        delete api_goal_path(goal), format: :json
        expect(response).to have_http_status(204)
      }.to change(Goal, :count).by(-1)
    end
  end
end
