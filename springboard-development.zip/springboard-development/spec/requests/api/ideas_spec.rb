require 'rails_helper'
require 'auth_helper'

RSpec.describe "Ideas", type: :request do

  let(:editor) { create(:editor) }
  let(:viewer) { create(:viewer) }
  let(:originator) { create(:viewer) }
  let(:creator) { create(:viewer) }

  let!(:portfolio) { create(:portfolio) }
  let!(:product) { create(:product, portfolio: portfolio) }
  let!(:idea) { create(:idea, product: product, created_by: creator.id, originator: originator) }
  let!(:component) { create(:component, product: product) }
  let!(:feature) { create(:feature, component: component, ideas: [idea]) }

  let!(:metric_category) { create(:metric_category) }
  let!(:metric) { create(:metric, metric_category: metric_category)}
  let!(:goal) { create(:goal, idea: idea, metric: metric) }

  describe "GET /ideas" do
    let!(:product2) { create(:product, portfolio: portfolio) }
    let!(:idea2) { create(:idea, product: product2, created_by: creator.id, originator: originator) }
    let!(:component2) { create(:component, product: product2) }
    let!(:feature2) { create(:feature, component: component2, ideas: [idea2]) }

    it "should return all ideas with associations" do
      get api_ideas_path, format: :json
      expect(response).to have_http_status(200)
      json = JSON.parse(response.body)
      expect(json.length).to eq(Idea.count)

      idea_json = json.first
      expect(idea_json['goals'].length).to eq(idea.goals.count)
      expect(idea_json['pinnables'].length).to eq(idea.pinnables.count)
    end

    it "should return all ideas for a given product" do
      get api_ideas_path(product: product.id), format: :json
      expect(response).to have_http_status(200)
      json = JSON.parse(response.body)
      expect(json.length).to eq(product.ideas.count)

      idea_json = json.first
      expect(idea_json['pinnables'].length).to eq(idea.pinnables.count)
    end
  end

  describe "POST /products/:product_id/ideas" do
    it "should return 401" do
      post api_product_ideas_path(product), format: :json, title: "New Name"
      expect(response).to have_http_status(401)
    end

    it "should create a idea" do
      login creator
      expect {
        post api_product_ideas_path(product), format: :json, title: "New Name"
        expect(response).to have_http_status(201)
        json = JSON.parse(response.body)
        expect(json['product_id']).to eql(product.id)
        expect(json['created_by']).to eql(creator.id)
        expect(json['updated_by']).to eql(creator.id)
      }.to change(Idea, :count).by(1)
    end
  end

  describe "GET /ideas/:id" do
    it "should return the idea" do
      get api_idea_path(idea), format: :json
      expect(response).to have_http_status(200)
      json = JSON.parse(response.body)
      expect(json['id']).to eql(idea.id)
    end
  end

  describe "PATCH /ideas/:id" do
    it "should return 401" do
      patch api_idea_path(idea), format: :json, title: "New Title"
      expect(response).to have_http_status(401)
    end

    it "should return 403" do
      login viewer
      patch api_idea_path(idea), format: :json, title: "New Title"
      expect(response).to have_http_status(403)
    end

    it "should update the title (editor)" do
      login editor
      expect {
        patch api_idea_path(idea), format: :json, title: "New Title"
        expect(response).to have_http_status(201)
        idea.reload
        expect(idea.updated_by).to eql(editor.id)
      }.to change(idea, :title).to("New Title")
    end

    it "should update the title (creator)" do
      login creator
      expect {
        patch api_idea_path(idea), format: :json, title: "New Title"
        expect(response).to have_http_status(201)
        idea.reload
        expect(idea.updated_by).to eql(creator.id)
      }.to change(idea, :title).to("New Title")
    end
  end

  describe "DELETE /ideas/:id" do
    it "should return 401" do
      delete api_idea_path(idea), format: :json
      expect(response).to have_http_status(401)
    end

    it "should return 403" do
      login viewer
      delete api_idea_path(idea), format: :json
      expect(response).to have_http_status(403)
    end

    it "should delete the idea (editor)" do
      login editor
      expect {
        delete api_idea_path(idea), format: :json
        expect(response).to have_http_status(204)
      }.to change(Idea, :count).by(-1)
    end

    it "should delete the idea (creator)" do
      login creator
      expect {
        delete api_idea_path(idea), format: :json
        expect(response).to have_http_status(204)
      }.to change(Idea, :count).by(-1)
    end
  end

  describe "GET /ideas/:id/versions", :versioning => true do
    before(:each) do
      idea.whodunnit(editor.id) do
        idea.update_attributes :status => 'open'
      end
    end

    it "should return the idea history" do
      get api_idea_versions_path(idea), format: :json
      expect(response).to have_http_status(200)
      json = JSON.parse(response.body)
      expect(json.length).to eq(2)

      version = json[0]
      expect(version['event']).to eql('create')

      version = json[1]
      expect(version['event']).to eql('update')
      expect(version['whodunnit']).to eql(editor.id)
      expect(version['changeset']['status']).to eql([nil, 'open'])
    end
  end
end
