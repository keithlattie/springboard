require 'rails_helper'
require 'auth_helper'

RSpec.describe "Benefits", type: :request do

  let(:editor) { create(:editor) }
  let(:user) { create(:user) }
  let!(:feature) { create(:feature) }
  let!(:benefit) { create(:benefit, beneficial: feature)}

  describe "POST /features/:feature_id/benefits" do
    it "should return 401" do
      post api_feature_benefits_path(feature), format: :json, name: "New Name"
      expect(response).to have_http_status(401)
    end

    it "should return 403" do
      login user
      post api_feature_benefits_path(feature), format: :json, name: "New Name"
      expect(response).to have_http_status(403)
    end

    it "should create a new benefit" do
      login editor
      expect {
        post api_feature_benefits_path(feature), format: :json, name: "New Name"
        expect(response).to have_http_status(201)
        json = JSON.parse(response.body)
        expect(json['created_by']).to eql(editor.id)
        expect(json['updated_by']).to eql(editor.id)
      }.to change(feature.benefits, :count).by(1)
    end
  end

  describe "PATCH /benefits/:id" do
    it "should return 401" do
      patch api_benefit_path(benefit), format: :json, name: "New Name"
      expect(response).to have_http_status(401)
    end

    it "should return 403" do
      login user
      patch api_benefit_path(benefit), format: :json, name: "New Name"
      expect(response).to have_http_status(403)
    end

    it "should update the name" do
      login editor
      patch api_benefit_path(benefit), format: :json, name: "Totally New Name"
      expect(response).to have_http_status(201)

      benefit.reload

      expect(benefit.updated_by).to eql(editor.id)
      expect(benefit.name).to eql("Totally New Name")
    end
  end
end
