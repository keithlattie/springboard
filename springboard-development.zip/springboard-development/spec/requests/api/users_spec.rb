require 'rails_helper'
require 'auth_helper'

RSpec.describe "Users", type: :request do

  let(:admin) { create(:admin) }
  let(:user) { create(:user) }

  describe "GET /users" do
    let!(:users) {[
      create(:user),
      create(:user)
    ]}

    it "should return 401" do
      get api_users_path, format: :json
      expect(response).to have_http_status(401)
    end

    it "should return 403" do
      login user
      get api_users_path, format: :json
      expect(response).to have_http_status(403)
    end

    it "should return all users" do
      login admin
      get api_users_path, format: :json
      expect(response).to have_http_status(200)
      json = JSON.parse(response.body)
      expect(json.length).to eql(3)
    end
  end

  describe "GET /users/:id" do
    it "should return 401" do
      get api_user_path(user), format: :json
      expect(response).to have_http_status(401)
    end

    it "should return 403" do
      login user
      get api_user_path(user), format: :json
      expect(response).to have_http_status(403)
    end

    it "should return the user" do
      login admin
      get api_user_path(user), format: :json
      expect(response).to have_http_status(200)
      json = JSON.parse(response.body)
      expect(json['id']).to eql(user.id)
    end
  end

  describe "PATCH /users/:id" do
    it "should return 401" do
      patch api_user_path(user), format: :json, first_name: "Test"
      expect(response).to have_http_status(401)
    end

    it "should return 403" do
      login user
      patch api_user_path(user), format: :json, first_name: "Test"
      expect(response).to have_http_status(403)
    end

    it "should update the name" do
      login admin
      expect {
        patch api_user_path(user), format: :json, first_name: "Test"
        expect(response).to have_http_status(201)
        user.reload
      }.to change(user, :first_name).to("Test")
    end

    it "should NOT update the email" do
      login admin
      expect {
        patch api_user_path(user), format: :json, email: "email@homedepot.com"
        expect(response).to have_http_status(201)
        user.reload
      }.to_not change(user, :email)
    end
  end

  describe "DELETE /users/:id" do
    it "should return 401" do
      delete api_user_path(user), format: :json
      expect(response).to have_http_status(401)
    end

    it "should return 403" do
      login user
      delete api_user_path(user), format: :json
      expect(response).to have_http_status(403)
    end

    it "should delete the user" do
      login admin
      user
      expect {
        delete api_user_path(user), format: :json
        expect(response).to have_http_status(204)
      }.to change(User, :count).by(-1)
    end
  end
end
