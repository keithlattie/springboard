require 'rails_helper'
require 'auth_helper'

RSpec.describe "Portfolios", type: :request do

  let(:editor) { create(:editor) }
  let(:user) { create(:user) }
  let!(:portfolio) { create(:portfolio) }

  describe "GET /portfolios" do
    it "should return all portfolios" do
      get api_portfolios_path, format: :json
      expect(response).to have_http_status(200)
      json = JSON.parse(response.body)
      expect(json.length).to eql(1)
    end
  end

  describe "GET /portfolios/:id" do
    it "should return the portfolio" do
      get api_portfolio_path(portfolio), format: :json
      expect(response).to have_http_status(200)
      json = JSON.parse(response.body)
      expect(json['id']).to eql(portfolio.id)
    end
  end

  describe "POST /portfolios" do
    it "should return 401" do
      post api_portfolios_path, format: :json, name: "New Name"
      expect(response).to have_http_status(401)
    end

    it "should return 403" do
      login user
      post api_portfolios_path, format: :json, name: "New Name"
      expect(response).to have_http_status(403)
    end

    it "should update the name" do
      login editor
      expect {
        post api_portfolios_path, format: :json, name: "New Name"
        expect(response).to have_http_status(201)
        json = JSON.parse(response.body)
        expect(json['created_by']).to eql(editor.id)
        expect(json['updated_by']).to eql(editor.id)
      }.to change(Portfolio, :count).by(1)
    end
  end

  describe "PATCH /portfolios/:id" do
    it "should return 401" do
      patch api_portfolio_path(portfolio), format: :json, name: "New Name"
      expect(response).to have_http_status(401)
    end

    it "should return 403" do
      login user
      patch api_portfolio_path(portfolio), format: :json, name: "New Name"
      expect(response).to have_http_status(403)
    end

    it "should update the name" do
      login editor
      expect {
        patch api_portfolio_path(portfolio), format: :json, name: "New Name"
        expect(response).to have_http_status(201)
        portfolio.reload
        expect(portfolio.updated_by).to eql(editor.id)
      }.to change(portfolio, :name).to("New Name")
    end
  end

  describe "DELETE /portfolios/:id" do
    it "should return 401" do
      delete api_portfolio_path(portfolio), format: :json
      expect(response).to have_http_status(401)
    end

    it "should return 403" do
      login user
      delete api_portfolio_path(portfolio), format: :json
      expect(response).to have_http_status(403)
    end

    it "should delete the portfolio" do
      login editor
      portfolio
      expect {
        delete api_portfolio_path(portfolio), format: :json
        expect(response).to have_http_status(204)
      }.to change(Portfolio, :count).by(-1)
    end
  end
end
