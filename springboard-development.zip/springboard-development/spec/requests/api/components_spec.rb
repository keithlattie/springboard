require 'rails_helper'
require 'auth_helper'

RSpec.describe "Components", type: :request do

  let(:editor) { create(:editor) }
  let(:user) { create(:user) }
  let!(:portfolio) { create(:portfolio) }
  let!(:product) { create(:product, portfolio: portfolio) }
  let!(:component) { create(:component, product: product) }
  let!(:feature) { create(:feature, component: component) }

  describe "GET /components" do
    let!(:product2) { create(:product, portfolio: portfolio) }
    let!(:component2) { create(:component, product: product2) }

    it "should return all components" do
      get api_components_path, format: :json
      expect(response).to have_http_status(200)
      ids = JSON.parse(response.body).map{|x| x["id"]}
      expect(ids).to eql([component.id, component2.id])
    end

    it "should return all components for a product" do
      get api_components_path(product: product.id), format: :json
      expect(response).to have_http_status(200)
      ids = JSON.parse(response.body).map{|x| x["id"]}
      expect(ids).to eql([component.id])
    end
  end

  describe "GET /components/:id" do
    it "should return the component" do
      get api_component_path(component), format: :json
      expect(response).to have_http_status(200)
      json = JSON.parse(response.body)
      expect(json['id']).to eql(component.id)
    end
  end

  describe "POST /product/:product_id/components" do
    it "should return 401" do
      post api_product_components_path(product), format: :json, name: "New Name"
      expect(response).to have_http_status(401)
    end

    it "should return 403" do
      login user
      post api_product_components_path(product), format: :json, name: "New Name"
      expect(response).to have_http_status(403)
    end

    it "should update the name" do
      login editor
      expect {
        post api_product_components_path(product), format: :json, name: "New Name"
        expect(response).to have_http_status(201)
        json = JSON.parse(response.body)
        expect(json['product_id']).to eql(product.id)
        expect(json['created_by']).to eql(editor.id)
        expect(json['updated_by']).to eql(editor.id)
      }.to change(Component, :count).by(1)
    end
  end

  describe "PATCH /components/:id" do
    it "should return 401" do
      patch api_component_path(component), format: :json, name: "New Name"
      expect(response).to have_http_status(401)
    end

    it "should return 403" do
      login user
      patch api_component_path(component), format: :json, name: "New Name"
      expect(response).to have_http_status(403)
    end

    it "should update the name" do
      login editor
      expect {
        patch api_component_path(component), format: :json, name: "New Name"
        expect(response).to have_http_status(201)
        component.reload
        expect(component.updated_by).to eql(editor.id)
      }.to change(component, :name).to("New Name")
    end
  end

  describe "DELETE /components/:id" do
    it "should return 401" do
      delete api_component_path(component), format: :json
      expect(response).to have_http_status(401)
    end

    it "should return 403" do
      login user
      delete api_component_path(component), format: :json
      expect(response).to have_http_status(403)
    end

    it "should delete the component" do
      login editor
      component
      expect {
        delete api_component_path(component), format: :json
        expect(response).to have_http_status(204)
      }.to change(Component, :count).by(-1)
    end

    it "should delete the component's feature" do
      login editor
      component
      expect {
        delete api_component_path(component), format: :json
        expect(response).to have_http_status(204)
      }.to change(Feature, :count).by(-1)
    end
  end
end
