require 'rails_helper'
require 'auth_helper'

RSpec.describe "Team Members Controller", type: :request do

  let(:admin) { create(:admin) }
  let(:editor) { create(:editor) }
  let(:user) { create(:user) }

  describe "POST /product/:product_id/team_members" do

    let!(:product) { create(:product) }
    let!(:team_member_attributes_and_format) { attributes_for(:team_member).merge(format: :json) }

    it "should return 401" do
      post api_product_team_members_path(product), team_member_attributes_and_format
      expect(response).to have_http_status(401)
    end

    it "viewers should return 403" do
      login user
      post api_product_team_members_path(product), team_member_attributes_and_format
      expect(response).to have_http_status(403)
    end

    it "editors should be able to add team members" do
      login editor
      expect {
        post api_product_team_members_path(product), team_member_attributes_and_format
        expect(response).to have_http_status(201)
      }.to change(product.team_members, :count).by(1)
    end

    it "admins should be able to add team members" do
      login admin
      expect {
        post api_product_team_members_path(product), team_member_attributes_and_format
        expect(response).to have_http_status(201)
      }.to change(product.team_members, :count).by(1)
    end
  end

  describe "PATCH /team_members/:id" do
    let!(:team_member) { create(:team_member) }

    it "should return 401" do
      patch api_team_member_path(team_member), format: :json, name: 'New Name'
      expect(response).to have_http_status(401)
    end

    it "viewers should return 403" do
      login user
      patch api_team_member_path(team_member), format: :json, name: 'New Name'
      expect(response).to have_http_status(403)
    end

    it "editors should be able to update team members" do
      login editor
      expect {
        patch api_team_member_path(team_member), format: :json, name: 'New Name'
        expect(response).to have_http_status(201)
        team_member.reload
        expect(team_member.updated_by).to eql(editor.id)
      }.to change(team_member, :name).to('New Name')
    end

    it "admins should be able to update team members" do
      login admin
      expect {
        patch api_team_member_path(team_member), format: :json, name: 'New Name'
        expect(response).to have_http_status(201)
        team_member.reload
        expect(team_member.updated_by).to eql(admin.id)
      }.to change(team_member, :name).to('New Name')
    end
  end

  describe "DELETE /team_members/:id" do
    let!(:team_member) { create(:team_member) }

    it "should return 401" do
      delete api_team_member_path(team_member), format: :json
      expect(response).to have_http_status(401)
    end

    it "viewers should return 403" do
      login user
      delete api_team_member_path(team_member), format: :json
      expect(response).to have_http_status(403)
    end

    it "editors should be able to delete" do
      login editor
      expect {
        delete api_team_member_path(team_member), format: :json
        expect(response).to have_http_status(204)
      }.to change(TeamMember, :count).by(-1)
    end

    it "admins should be able to delete" do
      login admin
      expect {
        delete api_team_member_path(team_member), format: :json
        expect(response).to have_http_status(204)
      }.to change(TeamMember, :count).by(-1)
    end
  end
end
