require 'rails_helper'
require 'auth_helper'

RSpec.describe "Component Nested Benefits", type: :request do

  let(:editor) { create(:editor) }
  let(:user) { create(:user) }
  let!(:component) { create(:component) }
  let!(:benefit) { create(:benefit, beneficial: component)}

  describe "POST /components/:component_id/benefits" do
    it "should return 401" do
      post api_component_benefits_path(component), format: :json, name: "New Name", id: benefit.id
      expect(response).to have_http_status(401)
    end

    it "should return 403" do
      login user
      post api_component_benefits_path(component), format: :json, name: "New Name", id: benefit.id
      expect(response).to have_http_status(403)
    end

    it "should create a new benefit" do
      login editor
      expect {
        post api_component_benefits_path(component), format: :json, name: "New Name", id: benefit.id
        expect(response).to have_http_status(201)
        json = JSON.parse(response.body)
        expect(json['created_by']).to eql(editor.id)
        expect(json['updated_by']).to eql(editor.id)
      }.to change(component.benefits, :count).by(1)
    end
  end
end
