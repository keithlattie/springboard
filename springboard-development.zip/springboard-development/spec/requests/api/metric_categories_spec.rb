require 'rails_helper'
require 'auth_helper'

RSpec.describe "Metric Categories", type: :request do

  let(:editor) { create(:editor) }
  let(:user) { create(:user) }

  let!(:metric_category) { create(:metric_category) }
  let!(:metrics) { create_list(:metric, 2, metric_category: metric_category)}

  describe "GET /metric_categories" do

    it "should return all metric categories with nested metrics" do
      get api_metric_categories_path, format: :json
      expect(response).to have_http_status(200)
      json = JSON.parse(response.body)

      expect(json.length).to eq(MetricCategory.count)
      expect(json.first["metrics"].length).to eq(Metric.count)
    end
  end
end
