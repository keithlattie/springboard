require 'rails_helper'
require 'auth_helper'

RSpec.describe "Features", type: :request do

  let(:editor) { create(:editor) }
  let(:user) { create(:user) }
  let!(:portfolio) { create(:portfolio) }
  let!(:product) { create(:product, portfolio: portfolio) }
  let!(:component) { create(:component, product: product) }
  let!(:feature) { create(:feature, component: component) }

  describe "GET /features" do
    let!(:product2) { create(:product, portfolio: portfolio) }
    let!(:component2) { create(:component, product: product2) }
    let!(:feature2) { create(:feature, component: component2) }

    it "should return all features" do
      get api_features_path, format: :json
      expect(response).to have_http_status(200)
      ids = JSON.parse(response.body).map{|x| x["id"]}
      expect(ids).to eql([feature.id, feature2.id])
    end

    it "should return all features for a component" do
      get api_features_path(component: component.id), format: :json
      expect(response).to have_http_status(200)
      ids = JSON.parse(response.body).map{|x| x["id"]}
      expect(ids).to eql([feature.id])
    end

    it "should return all features for a product" do
      get api_features_path(product: product.id), format: :json
      expect(response).to have_http_status(200)
      ids = JSON.parse(response.body).map{|x| x["id"]}
      expect(ids).to eql([feature.id])
    end
  end

  describe "GET /features/:id" do
    it "should return the feature" do
      get api_feature_path(feature), format: :json
      expect(response).to have_http_status(200)
      json = JSON.parse(response.body)
      expect(json['id']).to eql(feature.id)
    end
  end

  describe "POST /component/:component_id/features" do
    it "should return 401" do
      post api_component_features_path(component), format: :json, name: "New Name"
      expect(response).to have_http_status(401)
    end

    it "should return 403" do
      login user
      post api_component_features_path(component), format: :json, name: "New Name"
      expect(response).to have_http_status(403)
    end

    it "should update the name" do
      login editor
      expect {
        post api_component_features_path(component), format: :json, name: "New Name"
        expect(response).to have_http_status(201)
        json = JSON.parse(response.body)
        expect(json['component_id']).to eql(component.id)
        expect(json['created_by']).to eql(editor.id)
        expect(json['updated_by']).to eql(editor.id)
      }.to change(Feature, :count).by(1)
    end
  end

  describe "PATCH /features/:id" do
    it "should return 401" do
      patch api_feature_path(feature), format: :json, name: "New Name"
      expect(response).to have_http_status(401)
    end

    it "should return 403" do
      login user
      patch api_feature_path(feature), format: :json, name: "New Name"
      expect(response).to have_http_status(403)
    end

    it "should update the name" do
      login editor
      expect {
        patch api_feature_path(feature), format: :json, name: "New Name"
        expect(response).to have_http_status(201)
        feature.reload
        expect(feature.updated_by).to eql(editor.id)
      }.to change(feature, :name).to("New Name")
    end
  end

  describe "DELETE /features/:id" do
    it "should return 401" do
      delete api_feature_path(feature), format: :json
      expect(response).to have_http_status(401)
    end

    it "should return 403" do
      login user
      delete api_feature_path(feature), format: :json
      expect(response).to have_http_status(403)
    end

    it "should delete the feature" do
      login editor
      feature
      expect {
        delete api_feature_path(feature), format: :json
        expect(response).to have_http_status(204)
      }.to change(Feature, :count).by(-1)
    end
  end
end
