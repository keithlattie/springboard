require 'rails_helper'
require 'auth_helper'

RSpec.describe "Users", type: :request do

  let!(:user) { create(:user) }
  let!(:user2) { create(:user) }
  let!(:user3) { create(:user) }

  describe "GET /bulk/users" do
    it "should return ideaed users" do
      users = [user, user2]
      user_ids = users.collect(&:id)
      get api_bulk_user_path(user_ids.join(',')), format: :json

      expect(response).to have_http_status(200)
      json = JSON.parse(response.body)
      json_user_ids = json.collect{|u| u["id"]}
      expect(json_user_ids).to eql(user_ids)
    end
  end
end
