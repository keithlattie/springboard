//= require underscore/underscore-min
//= require moment/min/moment.min
//= require jquery/dist/jquery.min
//= require jquery_ujs
//= require autosize-input/autosize-input
//= require Sortable/Sortable.min
//= require bootstrap-sass/assets/javascripts/bootstrap.min
//= require angular/angular.min
//= require angular-resource/angular-resource.min
//= require angular-ui-router/release/angular-ui-router.min
//= require angular-bootstrap/ui-bootstrap-tpls.min
//= require angular-sortable-view/src/angular-sortable-view.min
//= require angular-elastic/elastic
//= require angular-rails-templates
//= require ng-idle/angular-idle.min
//= require format-as-currency/dist/format-as-currency
//= require_tree ./config
//= require_tree ../templates
//= require ./shared/module
//= require ./admin/module
//= require ./dashboard/module
//= require ./product/module
//= require_self

(function() {
  angular.module('springboard', ['ui.router', 'springboard.admin', 'springboard.dashboard', 'springboard.product', 'ngIdle'])

  // Setup CSRF / JSON
  .config(function($httpProvider) {
    var headers = $httpProvider.defaults.headers.common;
    headers['Accept'] = 'application/json';
  })

  // Setup default page
  .config(function($urlRouterProvider) {
    $urlRouterProvider.when('', '/dashboard');
  })

  .config(function(IdleProvider, TitleProvider) {
    //for all options, see https://github.com/HackedByChinese/ng-idle/wiki/Idle-and-Idleprovider
    IdleProvider.idle(3600);
    IdleProvider.timeout(120);
    IdleProvider.keepalive(false); //disable keepalive service
    TitleProvider.enabled(false); //disable Title service

    //mostly the defaults, removing mousemove since it causes the modal to prematurely dismiss
    IdleProvider.interrupt('keydown DOMMouseScroll mousewheel mousedown');
  })

  // Session / Routing
  .run(function($rootScope, $uibModalStack, $urlRouter, $q, Session, MetricService) {
    $rootScope.session = Session;

    // Load ideas to complete before starting routeing
    function load() {
      return $q.all([
        Session.load(),
        MetricService.load()
      ]);
    }

    $rootScope.$on("$locationChangeSuccess", function (event) {
      // Close any modals
      $uibModalStack.dismissAll();

      // If the session hasn't been loaded yet, load it before routing
      if (!Session.loaded) {
        event.preventDefault();
        load().then(function() { $urlRouter.sync(); });
      }
    });
  })

  // Favorites navigation
  .run(function($rootScope) {
    $rootScope.showFavorites = false;

    // Debounce the favorites flag to only take the latest
    var nextVisible;
    var applyVisible = _.debounce(function() {
      $rootScope.showFavorites = nextVisible;
      $rootScope.$apply();
    }, 1);

    // Defer actually setting the visible variable to handle rolling
    // over the navigation into the favorites
    $rootScope.setFavoritesVisible = function(visible) {
      nextVisible = visible;
      applyVisible();
    };

    $rootScope.$on('$stateChangeSuccess', function() {
      $rootScope.showFavorites = false;
    });
  })

  //Configure Idle Timeout on $rootScope
  .run(function($rootScope, $http, $uibModalStack, $state, Session, SessionModalService) {

    $rootScope.$on('IdleStart', function() {
      if (Session.canExtendSession()) {
        SessionModalService.openModal();
      } else {
        Session.signOut();
        $rootScope.$apply();
        $uibModalStack.dismissAll();
        SessionModalService.openSecondaryModal();
      }
    });

    $rootScope.$on('IdleTimeout', function() {
      Session.signOut();
      $state.go('dashboard');
      $rootScope.$apply();
      $uibModalStack.dismissAll();
      SessionModalService.openSecondaryModal();
    });

    $rootScope.$on('IdleEnd', function() {
      //Send a request to the server to reset its timeout
      $http({method: 'GET', url: '/session'});
    });
  })

  // Make ui.router state available for templates to show current state
  .run(function($rootScope, $state, $stateParams) {
    $rootScope.$state = $state;
    $rootScope.$stateParams = $stateParams;
  });
}());
