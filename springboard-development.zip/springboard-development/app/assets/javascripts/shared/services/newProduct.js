(function() {
  angular.module('springboard.shared')
    .service('NewProduct', function($uibModal, Portfolio, Product) {
      this.show = function(product) {
        return $uibModal.open({
          templateUrl: 'product/newProduct.html',
          controller: NewProductController,
          controllerAs: 'ctrl',
          windowClass: 'add-product',
          backdrop: 'static',
          resolve: {
            portfolios: function() { return Portfolio.query().$promise; },
            product: function() { return product; }
          }
        }).result;
      };

      return this;
    });

  function NewProductController($scope, $uibModalInstance, Product, Toaster, portfolios) {
    var ctrl = this;
    ctrl.portfolios = portfolios;
    ctrl.product = new Product();

    ctrl.submit = function () {
      ctrl.submitting = true;
      ctrl.product.$save().then(function() {
        $uibModalInstance.close(ctrl.product);
      }, function(err) {
        ctrl.submitting = false;
        Toaster.add('Error creating Product', 'danger', 100000);
      });
    };

    ctrl.cancel = function () {
      $uibModalInstance.dismiss('cancel');
    };

    ctrl.setPortfolio = function(portfolio) {
      ctrl.portfolio = portfolio;
      ctrl.product.portfolio_id = portfolio.id;
    };

    // Initialize the portfolio
    ctrl.setPortfolio(portfolios[0]);
  };
})();
