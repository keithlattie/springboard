(function() {
  angular.module('springboard.shared')
    .service('Resource', function($http, $q, $resource) {
      // Default parseJSON just returns the JSON
      function parseJSON(json) {
        return json;
      }

      // Define a resource like $resource, but add $patch and fromJSON
      this.define = function(url, paramDefaults, actions, options) {
        // Default the transforms for GETs, but allow them to be overriden
        actions = _.extend({}, {
          get: {
            method: 'GET',
            transformResponse: function(data) {
              try {
                var json = JSON.parse(data);
                return Resource.parseJSON(json);
              } catch(e) {
                return data;
              }
            }
          },
          query: {
            method: 'GET',
            isArray: true,
            transformResponse: function(data) {
              try {
                var json = JSON.parse(data);
                return _.map(json, Resource.parseJSON);
              } catch(e) {
                return data;
              }
            }
          }
        }, actions);

        // Create the resource
        var Resource = $resource(url, paramDefaults, actions, options);

        // Default the parseJSON (json->json). This attribute should be overriden
        Resource.parseJSON = parseJSON;

        // Set the fromJSON (json->resource)
        Resource.fromJSON = function(json) {
          json = Resource.parseJSON(json);
          return new Resource(json);
        };

        // Add PATCH function, which will send changes to
        // the server and then apply them to our resource
        // TODO: Make URL more versatile
        // one parameter: object of changes
        // two params: key and value to change
        Resource.prototype.$patch = function() {
          var data = {};
          if (arguments.length === 1) {
            data = arguments[0];
          } else {
            data[arguments[0]] = arguments[1];
          }

          var resource = this;
          return $http({
            method: 'PATCH',
            url: url.replace(':id', this.id),
            data: data
          }).then(function(result) {
            var json = Resource.parseJSON(result.data);
            _.extend(resource, data, json);
          });
        };

        return Resource;
      };
    });
}());
