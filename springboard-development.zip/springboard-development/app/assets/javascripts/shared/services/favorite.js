(function() {
  angular.module('springboard.shared')
    .service('FavoriteService', function($http, Session, Toaster) {

      this.isFavorite = function(favorable_type, favorable_id) {
        if (!Session.user) return false;
        return !!_.findWhere(Session.user.favorites, {favorable_type: favorable_type, favorable_id: favorable_id});
      };

      this.addFavorite = function(favorable_type, object) {
        return $http.post('/api/favorites', {
          favorite: {
            favorable_type: favorable_type,
            favorable_id: object.id
          }
        }).then(function(response){
          object.favorite = true;
          Session.user.favorites.push(response.data);
        }, function(err){
          Toaster.add('Error adding Favorite', 'danger');
        });
      };

      this.removeFavorite = function(favorable_type, object) {
        var favorite = _.findWhere(Session.user.favorites, {favorable_type: favorable_type, favorable_id: object.id});
        return $http.delete('/api/favorites/' + favorite.id).then(function(response) {
          var index = Session.user.favorites.indexOf(favorite);
          object.favorite = false;
          Session.user.favorites.splice(index, 1);
        }, function(err){
          Toaster.add('Error adding Favorite', 'danger');
        });
      };
    });
}());
