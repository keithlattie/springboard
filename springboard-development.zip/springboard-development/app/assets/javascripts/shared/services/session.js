(function() {
  angular.module('springboard.shared')
    .service('Session', function($http, $uibModal, User, Idle) {
      var session = this;
      this.loaded = false;
      this.loading = false;
      this.user = null;
      this.extensionCount = 0;

      // Login to LDAP with user id and password
      this.logIn = function(params) {
        return $http({
          method: 'POST',
          url: '/users/sign_in',
          data: { "user": params }
        }).then(function(result) {
          Idle.watch(); //start watching for Idle Sessions after logging in
          return User.fromJSON(result.data);
        });
      };

      // Query the current session information
      this.query = function() {
        return $http({method: 'GET', url: '/session'}).then(function(response) {
          Idle.watch();
          return response.data;
        }, function(error) {
          session.loading = false;
          session.loaded = false;
          Idle.unwatch(); //stop watching for Idle Sessions when logged out/or server side timeout occurs
          return session;
        });
      };

      // Load the current session information
      this.load = function() {
        this.loading = true;
        return this.query().then(function(json) {
          if (json.user) session.user = User.fromJSON(json.user);
          session.loading = false;
          session.loaded = true;
          return session;
        });
      };

      // Open the sign in modal
      this.signIn = function() {
        var modal = $uibModal.open({
          templateUrl: 'signIn.html',
          controller: SignInController,
          controllerAs: 'ctrl',
          windowClass: 'sign-in',
          backdrop: 'static'
        });

        return modal.result.then(function(json) {
          session.user = User.fromJSON(json.user);
          return session.user;
        });
      };

      // Cancel Session and SignOut
      this.signOut = function() {
        session.loaded = true;
        session.loading = false;
        session.user = null;
        session.extensionCount = 0
        Idle.unwatch(); //stop watching for Idle Sessions when logged out/or server side timeout occurs
        return session;
      };

      this.incrementExtensionCount = function() {
        session.extensionCount = session.extensionCount + 1;
      };

      this.canExtendSession = function() {
        return session.extensionCount < 8;
      };

      return this;
    });

  function SignInController($scope, $uibModalInstance, Session) {
    var ctrl = this;
    ctrl.username = '';
    ctrl.password = '';

    ctrl.submit = function() {
      ctrl.submitting = true;
      ctrl.lastError = undefined;

      var params = _.pick(ctrl, 'username', 'password');
      Session.logIn(params).then(function(user) {
        $uibModalInstance.close(user);
      }).catch(function(err) {
        ctrl.submitting = false;
        ctrl.lastError = _.first(err.data);
      });
    };

    ctrl.close = function() {
      $uibModalInstance.dismiss('cancel');
    };
  }
}());
