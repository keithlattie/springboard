(function() {
  angular.module('springboard.shared')
    .service('Sortable', function() {
      // Reset the positions of the collection to match their indices
      this.resetPositions = function(collection) {
        _.each(collection, function(resource, index) {
          resource.position = index + 1;
        });
      };

      // Insert this object into the collection at its position
      this.insert = function(collection, object) {
        // Increase positions of objects that got bumped down
        _.each(collection, function(obj) {
          if (obj.position >= object.position) obj.position += 1;
        });

        // Add to list
        collection.push(object);
      };

      // Adjust the other objects in this collection after this object has been moved
      this.afterMove = function(collection, object, oldPosition) {
        // Move everything, except the initial object
        var objects = _.difference(collection, [object]);
        debugger;

        // Determine what to move and hte direction to move it
        var delta;
        if (object.position < oldPosition) { // Moved down
          delta = 1;
          objects = _.filter(objects, function(obj) {
            return obj.position >= object.position && obj.position < oldPosition;
          });
        } else { // Moved up
          delta = -1;
          objects = _.filter(objects, function(obj) {
            return obj.position <= object.position && obj.position > oldPosition;
          });
        }

        // Move the objects by the delta
        _.each(objects, function(obj) {
          obj.position += delta;
        })
      };

      return this;
    });
}());
