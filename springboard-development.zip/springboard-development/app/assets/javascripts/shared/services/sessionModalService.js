(function() {
  angular.module('springboard.shared')
    .service('SessionModalService', function($uibModal) {

      this.openModal = function() {
        return $uibModal.open({
          templateUrl: 'shared/sessionModalService.html',
          controller: SessionTimeoutController,
          controllerAs: 'ctrl',
          windowClass: 'session-timeout',
          backdrop: 'static'
        }).result;
      };

      this.openSecondaryModal = function() {
        return $uibModal.open({
          templateUrl: 'shared/secondarySessionModalService.html',
          controller: SecondarySessionTimeoutController,
          controllerAs: 'ctrl',
          windowClass: 'session-timeout',
          backdrop: 'static'
        }).result;
      };
    });

  function SessionTimeoutController($scope, $uibModalInstance, Session, Idle) {
    var ctrl = this;

    $scope.extendSession = function() {
      Idle.unwatch();
      Session.incrementExtensionCount();
      Idle.watch();
      $uibModalInstance.dismiss('cancel');
    };
  };

  function SecondarySessionTimeoutController($scope, $uibModalInstance, Session) {
    var ctrl = this;

    $scope.close = function() {
      $uibModalInstance.dismiss('cancel');
    };
  };
}());