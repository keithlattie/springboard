(function() {
  angular.module('springboard.shared')
    .service('Toaster', function() {
      var id = 0;
      this.toasts = [];
      this.multiple = true;

      // Clear all the toasts
      this.reset = function() {
        this.toasts.splice(0, this.toasts.length);
      };

      // Remove this specific toast
      this.remove = function(toast) {
        var index = _.indexOf(this.toasts, toast);
        this.toasts.splice(index, 1);
      };

      // Add this toast
      // If we don't allow multiple, remove the rest
      this.add = function(message, type, duration) {
        // If we don't allow multiple, clear out the current one
        if (!this.multiple) this.reset();

        // Add the new one
        this.toasts.push({
          id: (id = id + 1),
          message: message,
          type: type || 'info',
          duration: duration || 3000
        });
      };
    });
}());
