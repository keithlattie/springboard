(function() {
  angular.module('springboard.shared')
    .service('UserCache', function($q, $timeout, User) {
      var service = this;
      var cache = [];
      var queue = [];

      // Process the contents of the queue
      function processQueue() {
        var ids = _.pluck(queue, 'id');
        return User.bulkLoad(ids).then(function(users) {
          // Resolve all of the promises
          _.each(queue, function(entry) {
            var user = _.findWhere(users, {id: entry.id});
            if (user) entry.deferred.resolve(user);
          });

          // Clear the queuE
          queue = [];
        });
      }

      // Add this id to the load queue and return a promise that returns the user
      function addToQueue(id) {
        var deferred = $q.defer();

        // Kick the queue to run on the next cycle, if it hasn't been kicked yet
        if (!queue.length) $timeout(processQueue);

        // Add to the queue, for a bulk load
        queue.push({
          id: id,
          deferred: deferred
        });

        // Add to the cache, so it can be referenced later
        cache.push({
          id: id,
          promise: deferred.promise
        });

        return deferred.promise;
      }

      // Load a user by ID, return a promise that returns the user
      this.loadById = function(id) {
        // No ID, return nothing
        if (!id) return $q.when();

        // If we have it in our cache, return from cache, otherwise add to cache
        var entry = _.findWhere(cache, {id: id});
        return entry ? entry.promise : addToQueue(id);
      };

      // Load this attribute onto this object
      this.loadAttribute = function(obj, key, id) {
        return service.loadById(id).then(function(user) {
          obj[key] = user;
          return obj;
        });
      };

      // Load this array of attributes onto the object/objects
      this.loadObject = function(obj, attr) {
        // Load all the attributes
        var promises = _.map(attr, function(id, key) {
          return service.loadAttribute(obj, key, id);
        });

        // Wait for everything to complete and return the input
        return $q.all(promises).then(function() {
          return obj;
        });
      };

      return this;
    });
}());
