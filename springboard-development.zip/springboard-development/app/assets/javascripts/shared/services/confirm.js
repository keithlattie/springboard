(function() {
  angular.module('springboard.shared')
    .service('Confirm', function($uibModal) {
      this.show = function(options) {
        return $uibModal.open({
          templateUrl: 'shared/confirm.html',
          controller: ConfirmController,
          controllerAs: 'ctrl',
          windowClass: 'confirm',
          backdrop: 'static',
          resolve: {
            title: function() { return options.title; },
            body: function() { return options.body; },
            action: function() { return options.action; },
            challenge: function() { return options.challenge; }
          }
        }).result;
      };

      return this;
    });

  function ConfirmController($scope, $uibModalInstance, title, body, action, challenge) {
    var ctrl = this;
    ctrl.title = title;
    ctrl.body = body;
    ctrl.action = action;
    ctrl.challenge = challenge;
    ctrl.challenger = {};

    ctrl.ok = function () {
      $uibModalInstance.close();
    };

    ctrl.cancel = function () {
      $uibModalInstance.dismiss('cancel');
    };
  };
})();
