(function() {
  angular.module('springboard.shared')
    .service('Versionable', function($http, $q, UserCache) {
      // Convert the json coming back from the server
      function fromJSON(json) {
        json.created_at = Date.fromJSON(json.created_at);
        return json;
      }

      // Load users onto the version
      function loadUsers(version) {
        return UserCache.loadObject(version, {
          whodunnit: version.whodunnit
        });
      }

      // Get the version history at this URL endpoint
      this.getHistory = function(url) {
        return $http({
          url: url
        }).then(function(result) {
          var versions = _.map(result.data, fromJSON);
          var promises = _.map(versions, loadUsers);
          return $q.all(promises);
        });
      };

      // Format the version using the given strategy
      this.format = function(version, strategy) {
        if (version.event === 'create') return [strategy.create];
        if (version.event === 'update') return this.formatUpdates(version.changeset, strategy.update);
      };

      // Format the updates from this changeset
      this.formatUpdates = function(changeset, formatters) {
        return _.reduce(changeset, function(result, values, key) {
          var format = formatters[key];
          if (format) {
            var update = format(values[0], values[1]);
            result.push(update);
          }
          return result;
        }, []);
      };

      return this;
    });
}());
