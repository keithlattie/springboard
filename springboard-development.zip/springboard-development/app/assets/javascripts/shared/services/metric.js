(function() {
  angular.module('springboard.shared')
  .service('MetricService', function($http, $q) {
    var service = this;

    // Load all of the categories/metrics
    this.load = function() {
      return this.categories ? $q.when(this.categories) : $http.get('/api/metric_categories').success(function(categories) {
        service.categories = categories;
        service.metrics = _.chain(categories).pluck('metrics').flatten().value();
        return service.categories;
      });
    };

    // Reduce these metric ids down to categories of metrics
    this.reduceIds = function(metricIds) {
      // Find all of the metrics
      var metrics = _.map(metricIds, function(metricId) {
        return _.findWhere(service.metrics, {id: metricId});
      });

      // Group them into categories
      return _.chain(metrics).groupBy('metric_category_id').map(function(metrics, categoryId) {
        categoryId = parseInt(categoryId, 10); // key is always a string
        var category = _.findWhere(service.categories, {id: categoryId});
        category = _.clone(category);
        category.metrics = metrics;
        return category;
      }).value();
    };

    return this;
  });
}());
