//= require_self
//= require_tree ./directives
//= require_tree ./factories
//= require_tree ./filters
//= require_tree ./services

(function() {
  angular.module('springboard.shared', ['monospaced.elastic', 'ngResource', 'ui.bootstrap']);
}());
