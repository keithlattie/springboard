(function() {
  angular.module('springboard.shared')
    .filter('feature', function() {
      // Create a text filter
      function textFilter(text) {
        var regexp = new RegExp(text, 'i');
        return function(feature) {
          var values = [feature.name];
          return _.any(values, function(value) {
            return regexp.test(value);
          });
        }
      }

      return function(features, filter) {
        if (!filter) return features;

  			// Populate filters
        var filters = [];
  			if (filter.text && filter.text.length) filters.push(textFilter(filter.text));

  			// Run the filters on each feature
  			if (!filters.length) return features;
  			return _.filter(features, function(feature) {
  				return _.all(filters, function(filter) {
  					return filter(feature);
  				});
  			});
  		};
    });
}());
