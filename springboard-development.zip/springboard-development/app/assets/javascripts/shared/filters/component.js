(function() {
  angular.module('springboard.shared')
    .filter('component', function() {
      // Create a text filter
      function textFilter(text) {
        var regexp = new RegExp(text, 'i');
        return function(component) {
          var features = _.pluck(component.features, 'name');
          var values = [component.name].concat(features);
          return _.any(values, function(value) {
            return regexp.test(value);
          });
        }
      }

      return function(components, filter) {
        if (!filter) return components;

  			// Populate filters
        var filters = [];
  			if (filter.text && filter.text.length) filters.push(textFilter(filter.text));

  			// Run the filters on each component
  			if (!filters.length) return components;
  			return _.filter(components, function(component) {
  				return _.all(filters, function(filter) {
  					return filter(component);
  				});
  			});
  		};
    });
}());
