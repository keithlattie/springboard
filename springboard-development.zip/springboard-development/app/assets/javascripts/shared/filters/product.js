(function() {
  angular.module('springboard.shared')
  .filter('product', function() {
    return function(products, filter) {
        // Do not filter if no filter present, no filter text, or the text length is 0
        if (!filter || !filter.text || !filter.text.length) return products;

  			// Run the filters on each product
  			return _.select(products, function(product) {
          return (product.name.toUpperCase().indexOf(filter.text.toUpperCase()) > -1) ||
          (_.any(_.pluck(product.team_members, 'name'), function(team_member_name) {
           return team_member_name.toUpperCase().indexOf(filter.text.toUpperCase()) > -1;
         }));
        });
  		};
    });
}());
