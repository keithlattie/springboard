(function() {
  angular.module('springboard.shared')
    .factory('Feature', function($http, Resource, Benefit) {
      var Feature = Resource.define('/api/features/:id', {
        id: '@id'
      });

      Feature.parseJSON = function(json) {
        json.created_at = Date.fromJSON(json.created_at);
        json.updated_at = Date.fromJSON(json.updated_at);
        if (json.benefits) json.benefits = _.map(json.benefits, Benefit.fromJSON);
        return json;
      };

       // Add a component to this product
      Feature.prototype.addBenefit = function(json) {
        //might encapsulate this into a Service once we need to add Benefits to Components also
        var feature = this;
        return $http({
          method: 'POST',
          url: '/api/features/' + feature.id + '/benefits',
          data: json
        }).then(function(result) {
          var benefit = Benefit.fromJSON(result.data);
          feature.benefits.push(benefit);
          return benefit;
        });
      };

      // Delete this benefit and then remove it from our list
      Feature.prototype.removeBenefit = function(benefit) {
        var feature = this;
        return benefit.$delete().then(function() {
          var index = feature.benefits.indexOf(benefit);
          feature.benefits.splice(index, 1);
        });
      };

      return Feature;
    });
}());
