(function() {
  angular.module('springboard.shared')
    .factory('Product', function($http, Component, Idea, Resource, FavoriteService, Sortable, Spend, TeamMember) {
      var Product = Resource.define('/api/products/:id', {
        id: '@id'
      });

      Product.parseJSON = function(json) {
        json.created_at = Date.fromJSON(json.created_at);
        json.updated_at = Date.fromJSON(json.updated_at);
        if (json.components) json.components = _.map(json.components, Component.fromJSON);
        if (json.spends) json.spends = _.map(json.spends, Spend.fromJSON);
        if (json.team_members) json.team_members = _.map(json.team_members, TeamMember.fromJSON);
        json.favorite = FavoriteService.isFavorite('Product', json.id);

        return json;
      };

      // Add a component to this product
      Product.prototype.addComponent = function(json) {
        var product = this;
        return $http({
          method: 'POST',
          url: '/api/products/' + product.id + '/components',
          data: json
        }).then(function(result) {
          var component = Component.fromJSON(result.data);
          Sortable.insert(product.components, component);
          return component;
        });
      };

      // Delete this component and then remove it from our list
      Product.prototype.removeComponent = function(component) {
        var product = this;
        return component.$delete().then(function() {
          var index = product.components.indexOf(component);
          product.components.splice(index, 1);
        });
      };

      // Move this component to a new position
      Product.prototype.moveComponent = function(component, position) {
        var product = this;
        var oldPosition = component.position;
        return component.$patch({position: position}).then(function() {
          Sortable.afterMove(product.components, component, oldPosition);
        });
      };

      // Add a spend to this product
      Product.prototype.addSpend = function(json) {
        var product = this;
        return $http({
          method: 'POST',
          url: '/api/products/' + product.id + '/spends',
          data: json
        }).then(function(result) {
          var spend = Spend.fromJSON(result.data);
          product.spends.push(spend);
          return spend;
        });
      };

      // Delete this spend and then remove it from our list
      Product.prototype.removeSpend = function(spend) {
        var product = this;
        return spend.$delete().then(function() {
          var index = product.spends.indexOf(spend);
          product.spends.splice(index, 1);
        });
      };

      // Add a spend to this product
      Product.prototype.addTeam = function(json) {
        var product = this;
        return $http({
          method: 'POST',
          url: '/api/products/' + product.id + '/team_members',
          data: json
        }).then(function(result) {
          var team_member = TeamMember.fromJSON(result.data);
          product.team_members.push(team_member);
          return team_member;
        });
      };

      // Delete this spend and then remove it from our list
      Product.prototype.removeTeam = function(team_member) {
        var product = this;
        return team_member.$delete().then(function() {
          var index = product.team_members.indexOf(team_member);
          product.team_members.splice(index, 1);
        });
      };

      Product.prototype.toggleFavorite = function() {
        if(this.favorite) {
          FavoriteService.removeFavorite('Product', this);
        } else {
          FavoriteService.addFavorite('Product', this);
        }
      };

      // Find a component by ID
      Product.prototype.findComponentById = function(id) {
        return _.findWhere(this.components, {id: id});
      };

      // Find a feature by ID
      Product.prototype.findFeatureById = function(id) {
        return _.chain(this.components).pluck('features').flatten().findWhere({id: id}).value();
      };

      // Add a idea to this product
      Product.prototype.addIdea = function(json) {
        return $http({
          method: 'POST',
          url: '/api/products/' + this.id + '/ideas',
          data: json
        }).then(function(result) {
          var idea = Idea.fromJSON(result.data);
          return idea.loadUsers();
        });
      };

      // Find a component / feature by a pinnable
      Product.prototype.findPinnable = function(type, id) {
        if (type === 'Component') return this.findComponentById(id);
        else if (type === 'Feature') return this.findFeatureById(id);
      };

      // Load this pinnable with component and/or feature
      Product.prototype.mapPinnable = function(pinnable) {
        var type = pinnable.pinnable_type;
        var id = pinnable.pinnable_id;

        var component, feature;
        if (type === 'Component') {
          component = this.findComponentById(id);
        } else if (type === 'Feature') {
          feature = this.findFeatureById(id);
          component = this.findComponentById(feature.component_id);
        }

        return _.extend({}, pinnable, {
          component: component,
          feature: feature
        })
      };

      Product.prototype.hasTwoOrMoreSpends = function() {
        return this.spends.length > 1;
      };

      Product.prototype.hasOwner = function() {
        return !!this.productOwner();
      };

      Product.prototype.productOwner = function() {
        return _.findWhere(this.team_members, {role: "Product Owner"});
      };

      return Product;
    });
}());
