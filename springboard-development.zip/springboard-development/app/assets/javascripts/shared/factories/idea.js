(function() {
  angular.module('springboard.shared')
    .factory('Idea', function($http, $q, $sce, Goal, Resource, Session, UserCache, Versionable) {
      var Idea = Resource.define('/api/ideas/:id', {
        id: '@id'
      });

      Idea.parseJSON = function(json) {
        json.created_at = Date.fromJSON(json.created_at);
        json.updated_at = Date.fromJSON(json.updated_at);
        if (json.goals) json.goals = _.map(json.goals, Goal.fromJSON);
        return json;
      };

      // Constants
      Idea.businessValues = _.range(0, 5);
      Idea.productHealths = _.range(0, 5);
      Idea.investmentPoints = [{
        value: 0,
        label: '0',
        tooltip: $sce.trustAsHtml('<h4>0 Investment Points</h4><p>Somewhere between...</p><p><strong>1 FTE for 5 minutes</strong> and <strong>1 FTE for a few hours</strong></p>')
      }, {
        value: 1,
        label: '1',
        tooltip: $sce.trustAsHtml('<h4>1 Investment Point</h4><p>Somewhere between...</p><p><strong>1 FTE for 4 hours</strong> and <strong>2 FTEs for a couple days</strong></p>')
      }, {
        value: 2,
        label: '2',
        tooltip: $sce.trustAsHtml('<h4>2 Investment Points</h4><p>Somewhere between...</p><p><strong>1 FTE for several days</strong> and <strong>2 FTEs for a week</strong></p>')
      }, {
        value: 3,
        label: '3',
        tooltip: $sce.trustAsHtml('<h4>3 Investment Points</h4><p>Somewhere between...</p><p><strong>2 FTEs for a week</strong> and <strong>3 FTEs for a couple weeks</strong></p>')
      }, {
        value: 5,
        label: '5',
        tooltip: $sce.trustAsHtml('<h4>5 Investment Points</h4><p>Somewhere between...</p><p><strong>2 FTEs for a month</strong> and <strong>4 FTEs for a month</strong></p>')
      }, {
        value: 8,
        label: '8',
        tooltip: $sce.trustAsHtml('<h4>8 Investment Points</h4><p>Somewhere between...</p><p><strong>2 FTEs for two months</strong> to <strong>4 FTEs for three months</strong></p>')
      }, {
        value: -1,
        label: '>8',
        tooltip: $sce.trustAsHtml('<h4>&gt;8 Investment Points</h4><p>This is a placeholder estimate for anything more than 8 points that must be broken down later</p>')
      }];

      // Available statuses and their attributes
      // id - unique identifier that goes to the db
      // label - label for the UI
      // canRemove - Whether or not this status can be added in the UI
      // canRemove - Whether or not this status can be removed in the UI
      Idea.statuses = [{
        id: 'open',
        label: 'open',
        canAdd: true,
        canRemove: true
      }, {
        id: 'in-progress',
        label: 'in progress',
        canAdd: false,
        canRemove: true
      }, {
        id: 'completed',
        label: 'completed',
        canAdd: false,
        canRemove: false
      }]

      // Get the investment points
      // minimum: Minimum value to allow
      Idea.getInvestmentPoints = function(minimum) {
        if (minimum === undefined) return Idea.investmentPoints;
        return _.filter(Idea.investmentPoints, function(point) {
          return point.value >= minimum;
        });
      };

      // Strategy for formatting versions
      Idea.formatVersion = {
        create: 'created this idea.',
        update: {
          status: function(before, after) {
            if (!before) return 'added to roadmap.';
            if (!after) return 'removed from roadmap.';
            return 'changed the status to "' + after + '".';
          }
        }
      };

      // Determine if the currently logged in user can edit this idea
      Idea.prototype.canEdit = function() {
        var user = Session.user;
        if (!user) return false;
        return user.editor || this.originator_id == user.id;
      };

      // Load the users related to this idea
      Idea.prototype.loadUsers = function() {
        return UserCache.loadObject(this, {
          owner: this.owner_id,
          originator: this.originator_id,
          createdBy: this.created_by,
          updatedBy: this.updated_by
        });
      };

      // Set the impact, save to db is this idea exists
      Idea.prototype.setImpact = function(impact) {
        // Apply the attributes
        impact = _.pick(impact, 'business_value', 'product_health');
        impact = _.extend({
          business_value: null,
          product_health: null
        }, impact);

        // Set the current impact and save to the db
        _.extend(this, impact);
        if (this.id) return this.$patch(impact);
      };

      // Set the business value (clearing all other impacts)
      Idea.prototype.setBusinessValue = function(value) {
        return this.setImpact({business_value: value});
      };

      // Set the product health (clearing all other impacts)
      Idea.prototype.setProductHealth = function(health) {
        return this.setImpact({product_health: health});
      };

      // Set the number of investment points
      Idea.prototype.setInvestmentPoints = function(points) {
        this.investment_points = points;
        if (this.id) return this.$patch({investment_points: points});
      };

      // Determine if this idea has investment points
      Idea.prototype.hasInvestmentPoints = function() {
        var points = this.investment_points;
        return points != undefined && points >= 0;
      };

      // Set the number of investment points
      Idea.prototype.setStatus = function(status) {
        this.status = status;
        if (this.id) return this.$patch({status: status});
      };

      // Get the versions for this idea
      Idea.prototype.getVersions = function() {
        var url = '/api/ideas/' + this.id + '/versions';
        return Versionable.getHistory(url);
      };

      // Add a goal to this idea
      Idea.prototype.addGoal = function(json) {
        var idea = this;
        return $http({
          method: 'POST',
          url: '/api/ideas/' + idea.id + '/goals',
          data: json
        }).then(function(result) {
          var goal = Goal.fromJSON(result.data);
          idea.goals.push(goal);
          return goal;
        });
      };

      // Delete a goal from this idea
      Idea.prototype.removeGoal = function(goal) {
        var idea = this;
        return goal.$delete().then(function() {
          var index = idea.goals.indexOf(goal);
          idea.goals.splice(index, 1);
        });
      };

      // Determine if this idea has this metric as a goal
      Idea.prototype.hasGoalMetric = function(metricId) {
        return _.any(this.goals, function(goal) {
          return goal.metric_id === metricId;
        });
      };

      return Idea;
    });
}());
