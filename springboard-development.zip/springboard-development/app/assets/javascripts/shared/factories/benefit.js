(function() {
  angular.module('springboard.shared')
    .factory('Benefit', function($http, MetricService, Resource, Toaster) {
      var Benefit = Resource.define('/api/benefits/:id', {
        id: '@id'
      });

      Benefit.parseJSON = function(json) {
        json.created_at = Date.fromJSON(json.created_at);
        json.updated_at = Date.fromJSON(json.updated_at);
        json.metricCategories = MetricService.reduceIds(json.metric_ids);
        return json;
      };

      // Determine if this metric id is in our list
      Benefit.prototype.hasMetric = function(metricId) {
        return _.contains(this.metric_ids, metricId);
      };

      // Add Metric to the Database, if all checks out insert it into Angular's brain
      Benefit.prototype.addMetric = function(metricId) {
        var benefit = this;
        return $http({
          method: 'POST',
          url: '/api/benefits/' + benefit.id + '/metrics',
          data: {
            //Don't need to pass much, the server just needs the two foreign keys - benefit.id and metric.id
            metric_id: metricId
          }
        }).then(function(result) {
          benefit.metric_ids.push(metricId);
          benefit.metricCategories = MetricService.reduceIds(benefit.metric_ids);
          return result;
        }, function(err) {
          Toaster.add('Error adding Metric', 'danger');
        });
      };

      Benefit.prototype.deleteMetric = function(metric) {
        var benefit = this;
        return $http({
          method: 'DELETE',
          url: '/api/benefits/' + benefit.id + '/metrics/' + metric.id,
        }).then(function() {
          var index = benefit.metric_ids.indexOf(metric.id);
          benefit.metric_ids.splice(index, 1);
          benefit.metricCategories = MetricService.reduceIds(benefit.metric_ids);
        }, function(err) {
          Toaster.add('Error deleting Metric', 'danger');
        });
      };

      return Benefit;
    });
}());
