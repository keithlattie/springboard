(function() {
  angular.module('springboard.shared')
    .factory('TeamMember', function(Resource) {
      var TeamMember = Resource.define('/api/team_members/:id', {
        id: '@id'
      });

      TeamMember.parseJSON = function(json) {
        json.created_at = Date.fromJSON(json.created_at);
        json.updated_at = Date.fromJSON(json.updated_at);
        return json;
      };

      return TeamMember;
    });
}());
