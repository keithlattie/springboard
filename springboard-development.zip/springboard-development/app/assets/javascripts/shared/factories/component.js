(function() {
  angular.module('springboard.shared')
    .factory('Component', function($http, Feature, Benefit, Resource, Sortable) {
      var Component = Resource.define('/api/components/:id', {
        id: '@id'
      });

      Component.parseJSON = function(json) {
        json.created_at = Date.fromJSON(json.created_at);
        json.updated_at = Date.fromJSON(json.updated_at);
        if (json.features) json.features = _.map(json.features, Feature.fromJSON);
        if (json.benefits) json.benefits = _.map(json.benefits, Benefit.fromJSON);
        return json;
      };

      // Add a component to this product
      Component.prototype.addFeature = function(json) {
        var component = this;
        return $http({
          method: 'POST',
          url: '/api/components/' + this.id + '/features',
          data: json
        }).then(function(result) {
          var feature = Feature.fromJSON(result.data);
          Sortable.insert(component.features, feature);
          return feature;
        });
      };

      // Delete this component and then remove it from our list
      Component.prototype.removeFeature = function(feature) {
        var component = this;
        return feature.$delete().then(function() {
          var index = component.features.indexOf(feature);
          component.features.splice(index, 1);
        });
      };

      // Add a component to this product
      Component.prototype.addBenefit = function(json) {
        var component = this;
        return $http({
          method: 'POST',
          url: '/api/components/' + component.id + '/benefits',
          data: json
        }).then(function(result) {
          var benefit = Benefit.fromJSON(result.data);
          component.benefits.push(benefit);
          return benefit;
        });
      };

      // Delete this benefit and then remove it from our list
      Component.prototype.removeBenefit = function(benefit) {
        var component = this;
        return benefit.$delete().then(function() {
          var index = component.benefits.indexOf(benefit);
          component.benefits.splice(index, 1);
        });
      };

      return Component;
    });
}());
