(function() {
  angular.module('springboard.shared')
    .factory('Goal', function($filter, MetricService, Resource) {
      var Goal = Resource.define('/api/goals/:id', {
        id: '@id'
      });

      Goal.parseJSON = function(json) {
        json.created_at = Date.fromJSON(json.created_at);
        json.metric = _.findWhere(MetricService.metrics, {id: json.metric_id});
        return json;
      };

      // Possible amount types
      Goal.amountTypes = [{
        id: 'percentage',
        short: '%',
        format: function(value) {
          return value + '%';
        }
      }, {
        id: 'dollars',
        short: '$',
        format: function(value) {
          var decimals = value != Math.floor(value);
          return $filter('currency')(value, '$', decimals ? 2 : 0);
        }
      }];

      // Possible duration types
      Goal.durationTypes = [{
        id: 'quarters',
        short: 'qtrs'
      }, {
        id: 'years',
        short: 'years'
      }];

      // Format the amount
      Goal.prototype.formatAmount = function() {
        var type = _.findWhere(Goal.amountTypes, {id: this.amount_type});
        if (type) return type.format(this.amount);
      };

      return Goal;
    });
}());
