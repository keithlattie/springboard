(function() {
  angular.module('springboard.shared')
    .factory('Spend', function($http, Resource) {
      var Spend = Resource.define('/api/spends/:id', {
        id: '@id'
      });

      Spend.parseJSON = function(json) {
        return json;
      };

      Spend.prototype.getSpendLabel = function() {
        return (this.year < new Date().getFullYear()) ? 'Spend' : 'Plan';
      };

      return Spend;
    });
}());