(function() {
  angular.module('springboard.shared')
    .factory('Portfolio', function(Resource) {
      var Portfolio = Resource.define('/api/portfolios/:id', {
        id: '@id'
      });

      Portfolio.parseJSON = function(json) {
        json.created_at = Date.fromJSON(json.created_at);
        json.updated_at = Date.fromJSON(json.updated_at);
        return json;
      };

      return Portfolio;
    });
}());
