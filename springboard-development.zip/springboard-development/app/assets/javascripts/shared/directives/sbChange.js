(function() {
  // Create rw-change="callback" event that handles the enter key, blur or when the user stops typing (optional)
  angular.module('springboard.shared')
    .directive('sbChange', function() {
      return {
        restrict: 'A',
        require: 'ngModel',
        link: function ($scope, $el, attr, ctrl) {
          if (attr.type === 'radio' || attr.type === 'checkbox') return;

          // Unbind original ng-model events
          $el.unbind('input').unbind('keydown').unbind('change');

          // Bind enter, blur and debounce other inputs
          $el.bind('blur', updateValue);
          $el.bind('keydown keypress', function(e) {
            if (e.which === 13) {
              updateValue();
              e.preventDefault();
            } else if (updateValueDebounced) {
              updateValueDebounced();
            }
          });

          // Update the model from the UI and call the change function
          function updateValue() {
            var value = $el.val();
            ctrl.$setViewValue(value);
            $scope.$apply();
          }

          // Debounce inputs?
          var timerDelay = parseInt(attr.sbChangeDelay, 10);
          if (timerDelay) var updateValueDebounced = _.debounce(updateValue, timerDelay);
        }
      };
    });
}());
