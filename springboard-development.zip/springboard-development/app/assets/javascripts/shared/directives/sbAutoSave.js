(function() {
  angular.module('springboard.shared')
    // Watch an input/textarea's state and PATCH the value to the server
    // when appropriate
    .directive('sbAutoSave', function(Toaster) {
      return {
        require: 'ngModel',
        restrict: 'A',
        link: function ($scope, $el, attr, ctrl) {
          // Pull out the resource / attribute we're editing from ng-model
          var parts = attr.ngModel.split('.');
          if (parts < 2) throw "Invalid ng-model. Must be in the form of resource.attribute";
          var resourceName = _.initial(parts).join('.');
          var attribute = _.last(parts);

          // Save the value on focus, so we don't save when nothing changes
          var initialValue;
          $el.bind('focus', function() {
            initialValue = ctrl.$viewValue;
          });

          // Both inputs and textareas save on blur
          $el.bind('blur', function() {
            var changed = ctrl.$viewValue != initialValue;
            var valid = ctrl.$valid;
            if (changed && valid) patchValue();
            $scope.$apply();
          });

          // Patch the value in the DB
          function patchValue(value) {
            var resource = $scope.$eval(resourceName);
            resource.$patch(attribute, ctrl.$viewValue).catch(function(err) {
              Toaster.add('Error saving: ' + attr.ngModel, 'danger');
            });
          }
        }
      };
    });
}());
