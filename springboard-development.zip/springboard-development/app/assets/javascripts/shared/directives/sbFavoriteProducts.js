(function() {
  angular.module('springboard.shared')
    .directive('sbFavoriteProducts', function($state, Session) {
      return {
        restrict: 'E',
        templateUrl: 'shared/favoriteProducts.html',
        link: function ($scope, $el, attr) {
          // Keep track of a list of products
          $scope.$watchCollection(function() {
            return Session.user.favorites;
          }, function(favorites) {
            $scope.products = _.map(favorites, function(favorite) {
              return {
                id: favorite.favorable_id,
                name: favorite.name,
                imageUrl: favorite.image_url
              }
            });
          });

          // Determine the product URL
          $scope.productUrl = function(product) {
            // Determine the state, keep the current one, if on a product
            var current = $state.current.name.split('.');
            var isProduct = current[0] === 'product';
            var state = isProduct ? $state.current.name : 'product.profile';

            // Go to the state for the current product
            var params = {id: product.id};
            return $state.href(state, params)
          };
        }
      };
    });
}());
