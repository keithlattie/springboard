(function() {
  angular.module('springboard.shared')
    .directive('sbCreateInPlace', function() {
      return {
        restrict: 'E',
        scope: {
          create: '&sbCreate', // Callback to create an object
          placeholder: '@' // Placeholder of the input
        },
        templateUrl: 'shared/createInPlace.html',
        link: function ($scope, $el, attr) {
          $scope.name = '';
          $scope.submitted = false;

          // Call create with this name
          function create(name) {
            $scope.createing = true;
            $scope.create({name: $scope.name}).then(function() {
              $scope.name = '';
              $scope.createing = false;
              $scope.submitted = false;
            });
          }

          // Submit the name (if valid)
          $scope.submit = function() {
            $scope.submitted = true;
            if ($scope.name.length) create($scope.name);
          };

          // If we lose focus, clear the error
          $scope.onBlur = function() {
            $scope.submitted = false;
          };

          // Detetmine if we have an error
          function hasError() {
            return $scope.submitted && !$scope.name.length;
          }

          // Update our error state
          $scope.$watch(hasError, function(hasError) {
            hasError ? $el.addClass('has-error') : $el.removeClass('has-error');
          })
        }
      };
    });
}());
