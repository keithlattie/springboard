(function() {
  // Scroll Spy on the secondary nav. Since we're using hashtag routing,
  // we can't put the anchor name in the url.
  angular.module('springboard.shared')
    .directive('sbScrollspyNav', function() {
      return {
        restrict: 'A',
        scope: {
          spy: '=sbScrollspyNav' // Watch this variable and update the active
        },
        link: function ($scope, $el, attr) {
          // Determine the header height
          function headerHeight() {
            return $('nav.primary').height() + $('nav.secondary').height();
          }

          // Click on a link to animate there
          $el.on('click', '> li[sb-scrollspy] > a', function(e) {
            e.preventDefault();
            var id = $(this).attr('href');
            var scrollTop = $(id).offset().top - headerHeight();
            $("body").stop().animate({ scrollTop: scrollTop}, 750);
          });

          // Determine the best ID
          function findBestId() {
            // Determine the top of the scroll
            var scrollTop = $('body').scrollTop();
            var pos = scrollTop + headerHeight();

            // Determine the available IDs
            var ids = $el.find('> li[sb-scrollspy] > a').map(function() {
              return $(this).attr('href');
            });

            // Destermine the best
            return _.reduce(ids, function(best, id) {
              // Determine dimensions
              var offset = $(id).offset();
              var height = $(id).height();
              if (!offset) return best;

              // Determine the position of this id
              var top = offset.top;
              var bottom = top + height;

              // Determine how far away this one is from the top
              var delta = 0;
              if (top > pos) delta = top - pos;
              if (bottom < pos) delta = pos - bottom;

              // Determine if this is our best yet
              var better = best.delta === undefined || delta < best.delta;
              if (better) best = { id: id, delta: delta };
              return best;
            }, {}).id;
          }

          // Update the active item
          function updateActive() {
            // Clear previous active
            $el.find('> li[sb-scrollspy]').removeClass('active');

            // Set latest active
            var id = findBestId();
            if (id) $el.find('a[href="' + id + '"]').parent().addClass('active');
          }

          // Bind to events that perform updates
          var throttled = _.throttle(updateActive, 100);
          $(window).on('resize.scrollspy', throttled);
          $(window).on('scroll.scrollspy', throttled);

          // Watch the spy variable for updates
          $scope.$watch('spy', function() {
            _.defer(updateActive);
          });

          // Unbind from events
          $scope.$on('$destroy', function() {
            $(window).off('resize.scrollspy');
            $(window).off('scroll.scrollspy');
          });
        }
      };
    });
}());
