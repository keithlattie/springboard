(function() {
  angular.module('springboard.shared')
    .directive('sbScrollGuard', function() {
      return {
        restrict: 'A',
        link: function ($scope, $el) {
          $el.on('wheel', function (e) {
            if (e.originalEvent.deltaY < 0) { // Scroll up
              return ($el.scrollTop() > 0);
            } else { // Scroll down
              return ($el.scrollTop() + $el.innerHeight() < $el[0].scrollHeight);
            }
          });
        }
      };
    });
}());
