(function() {
  angular.module('springboard.shared')
    .directive('sbWatchBenefits', function() {
      return {
        restrict: 'E',
        scope: {
          benefits: '='
        },
        link: function ($scope, $el, attr) {
          $scope.$watchCollection(function() {
            return $scope.benefits;
          }, function(benefits) {
            $scope.benefits = benefits;
          });
        }
      };
    });
}());
