(function() {
  // Create a notification tool that is globally registerable
  angular.module('springboard.shared')
    .directive('sbToaster', function(Toaster) {
      return {
        restrict: 'E',
        templateUrl: 'shared/toaster.html',
        link: function ($scope) {
          // Keep the list of toasts up to date
          $scope.toasts = Toaster.toasts;
          $scope.$watchCollection('toasts', function(curr, prev) {
            var toasts = _.difference(curr, prev);
            _.each(toasts, fadeAway);
          }, true);

          // User wants to remove this toast
          $scope.remove = function(toast) {
            Toaster.remove(toast);
          };

          // Fade this toast away after the duration
          function fadeAway(toast) {
            setTimeout(function() {
              var $el = $('#toast-' + toast.id);
              $el.fadeOut(750, function() {
                $scope.remove(toast);
                $scope.$apply();
              });
            }, toast.duration);
          }
        }
      };
    });
}());
