(function() {
  // Run all the callbacks on resize
  var callbacks = [];
  function onResize() {
    _.each(callbacks, function(callback) {
      callback();
    });
  }

  // Debounce the resize call
  $(window).resize(_.throttle(onResize, 100));

  // Automatically set the height of the div based on the width of the div
  angular.module('springboard.shared')
    .directive('sbAutoHeight', function() {
      return {
        restrict: 'A',
        link: function ($scope, $el, attr) {
          // Update the height to match the width
          // _.defer(updateHeight);
          function updateHeight() {
            var width = $el.width();
            $el.height(width);
          }
          updateHeight();

          // Add to callbacks list
          callbacks.push(updateHeight);

          // Remove from lists on destroy
          $scope.$on('$destroy', function() {
            var index = _.indexOf(callbacks, updateHeight);
            callbacks.splice(index, 1);
          });
        }
      };
    });
}());
