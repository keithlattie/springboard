(function() {
  angular.module('springboard.shared')
    // Add behavior for input/textarea's that are edit-in-place
    // Trigger blur on enter (if desired)
    .directive('sbEditInPlace', function(Toaster) {
      return {
        require: 'ngModel',
        restrict: 'A',
        link: function ($scope, $el, attr, ctrl) {
          // Should we blur on enter?
          var tagName = $el.prop('tagName').toLowerCase();
          var blurOnEnter = tagName === 'input' || attr.sbEditInPlaceInput !== undefined;

          // Override handler
          $el.bind('keydown keypress', function(e) {
            if (e.which === 13 && blurOnEnter) {
              $el.blur();
              e.preventDefault();
            }
          });
        }
      };
    });
}());
