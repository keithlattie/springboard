(function() {
  angular.module('springboard.shared')
    // Set the background-image attribute, because it's painful/ugly to do it in the HTML
    .directive('sbBackgroundImage', function() {
      return {
        restrict: 'A',
        scope: {
          imageUrl: '=sbBackgroundImage'
        },
        link: function ($scope, $el) {
          $scope.$watch('imageUrl', function(imageUrl) {
            if (imageUrl) {
              $el.css('background-image', "url('" + imageUrl + "')");
            } else {
              $el.css('background-image', null);
            }
          });
        }
      };
    });
}());
