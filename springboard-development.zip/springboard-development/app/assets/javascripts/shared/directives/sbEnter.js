(function() {
  // Add an event handler for the enter key
  angular.module('springboard.shared')
    .directive('sbEnter', function() {
      return {
        restrict: 'A',
        link: function ($scope, $el, attr) {
          // Listen for the enter key and trap it
          $el.bind('keydown keypress', function(e) {
            if (e.which === 13) {
              e.preventDefault();
              onEnter();
            }
          });

          // Handle the enter event
          function onEnter() {
            $scope.$eval(attr.sbEnter);
            $scope.$apply();
          }
        }
      };
    });
}());
