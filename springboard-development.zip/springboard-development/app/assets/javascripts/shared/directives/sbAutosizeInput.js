(function() {
  angular.module('springboard.shared')
    // Add behavior for input/textarea's that are edit-in-place
    // Trigger blur on enter (if desired)
    .directive('sbAutosizeInput', function(Toaster) {
      return {
        restrict: 'A',
        link: function ($scope, $el, attr) {
          var el = $el[0];
          _.defer(function() {
            autosizeInput(el);
          });
        }
      };
    });
}());
