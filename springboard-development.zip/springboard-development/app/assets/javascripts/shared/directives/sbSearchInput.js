(function() {
  // Create an input control with a search icon and a close icon
  angular.module('springboard.shared')
    .directive('sbSearchInput', function() {
      return {
        restrict: 'E',
        require: 'ngModel',
        scope: {
          closeIcon: '=', // Override the close icon
          debounce: '=', // Milliseconds to debounce, if not specified only alter on blur
          placeholder: '@',
          searchIcon: '=', // Override the search icon
          inputName: '='
        },
        templateUrl: 'shared/searchInput.html',
        link: function ($scope, $el, attr, ctrl) {
          // Render update the input value
          ctrl.$render = function() {
            $scope.value = ctrl.$viewValue;
          };

          // User cleared the value
          $scope.clear = function() {
            $scope.value = '';
            ctrl.$setViewValue($scope.value);
          };

          // User change the value
          $scope.onChange = function() {
            ctrl.$setViewValue($scope.value);
          }

          // When the value changes, update the empty state
          $scope.$watch('value', function(value) {
            var empty = !value || value.length == 0;
            empty ? $el.addClass('empty') : $el.removeClass('empty');
          });

          // Autofocus the input?
          if (attr.autofocus != undefined) _.defer(function() {
            $el.find('input').focus();
          });
        }
      };
    });
}());
