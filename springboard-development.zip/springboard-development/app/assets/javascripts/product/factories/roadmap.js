(function() {
  angular.module('springboard.product')
    .factory('Roadmap', function(Idea, Sortable, Toaster) {

      // Create an inbox lane
      function InboxLane() {
        return {
          id: 'inbox',
          active: true,
          icon: 'fa-lightbulb-o',
          title: 'Ideas',
          templateUrl: 'product/roadmap/lane/inbox.html',
          queues: [{
            id: 'inbox',
            where: {priority: null, spend_id: null, status: null},
            newIdea: true
          }, {
            id: 'priority-1',
            where: {priority: 1, spend_id: null, status: null}
          }, {
            id: 'priority-2',
            where: {priority: 2, spend_id: null, status: null}
          }, {
            id: 'priority-3',
            where: {priority: 3, spend_id: null, status: null}
          }]
        }
      }

      InboxLane.fromProduct = function(product) {
        return new InboxLane();
      };

      // Create a roadmap lane
      function RoadmapLane(spends) {
        // Map a spend to its budgets and queues
        var budgets = _.map(spends, function(spend) {
          var queues = _.map(Idea.statuses, function(status) {
            return {
              id: ['roadmap', spend.id, status.id].join('-'),
              where: {priority: null, spend_id: spend.id, status: status.id},
              spend: spend,
              status: status
            }
          });

          return {
            spend: spend,
            queues: queues
          }
        });

        // Pull out all the queues
        var queues = _.chain(budgets).pluck('queues').flatten().value();

        return {
          id: 'roadmap',
          active: true,
          icon: 'fa-map-signs',
          title: 'Roadmap',
          templateUrl: 'product/roadmap/lane/roadmap.html',
          budgets: budgets,
          queues: queues
        }
      }

      RoadmapLane.fromProduct = function(product) {
        var year = moment().year();
        var spends = _.where(product.spends, {year: year});
        if (spends.length) return new RoadmapLane(spends);
      };

      // Constructor
      function Roadmap(product, ideas) {
        this.product = product;
        this.ideas = ideas;
        this.lanes = Roadmap.createLanes(product);
        this.queues = _.chain(this.lanes).pluck('queues').flatten().value();

        // Load the ideas onto each queue
        _.each(this.queues, function(queue) {
          queue.ideas = _.where(ideas, queue.where);
        });
      }

      // Investment Points
      Roadmap.dollarsPerInvestmentPoint = 100000;

      // Create lanes on a roadmap
      Roadmap.lanes = [InboxLane, RoadmapLane];
      Roadmap.createLanes = function(product) {
        return _.chain(Roadmap.lanes).invoke('fromProduct', product).compact().value();
      };

      // Determine if this idea can be moved to this queue
      Roadmap.canMoveIdea = function(idea, queue) {
        // Moving to the roadmap?
        if (!idea.spend_id && queue.spend) {
          var canMove = idea.hasInvestmentPoints();
          if (!canMove) return false;
        }

        // Changing status?
        var fromStatus = _.findWhere(Idea.statuses, {id: idea.status});
        var toStatus = queue.status;
        if (fromStatus != toStatus) {
          var canAdd = !fromStatus && toStatus && toStatus.canAdd;
          var canRemove = !toStatus && fromStatus && fromStatus.canRemove;
          var canChange = canAdd || canRemove;
          if (!canChange) return false;
        }

        // Passed all the checks
        return true;
      };

      // Add a new idea
      Roadmap.prototype.addIdea = function(json) {
        var roadmap = this;
        return this.product.addIdea(json).then(function(idea) {
          // Add to entire list
          roadmap.ideas.push(idea);

          // Add to the top of the inbox queue
          var inbox = _.findWhere(roadmap.queues, {id: 'inbox'});
          inbox.ideas.unshift(idea);
          Sortable.resetPositions(inbox.ideas);
        });
      };

      // Move a idea
      Roadmap.prototype.moveIdea = function(idea, fromQueue, toQueue, index) {
        // Update the from queue
        var oldIndex = fromQueue.ideas.indexOf(idea);
        fromQueue.ideas.splice(oldIndex, 1);
        Sortable.resetPositions(fromQueue.ideas);

        // Update the to queue
        if (index == undefined) index = toQueue.ideas.length;
        toQueue.ideas.splice(index, 0, idea);
        Sortable.resetPositions(toQueue.ideas);

        // Determine the changes
        var changes = _.clone(toQueue.where);
        changes.position = index + 1;

        // Make the changes
        _.extend(idea, changes);
        if (idea.id) idea.$patch(changes);
      };

      // Remove an idea
      Roadmap.prototype.removeIdea = function(idea) {
        // Remove from roadmap
        var index = _.indexOf(this.ideas, idea);
        this.ideas.splice(index, 1);

        // Remove from queues
        _.each(this.queues, function(queue) {
          var index = _.indexOf(queue.ideas, idea);
          if (index != -1) queue.ideas.splice(index, 1);
        });
      };

      // Change an idea's status
      Roadmap.prototype.setStatus = function(idea, status) {
        // Find the queue this idea is moving from
        var fromQueue = _.find(this.queues, function(queue) {
          return _.contains(queue.ideas, idea);
        });

        // Find the queue this is is moving to
        if (fromQueue) var toQueue = _.findWhere(this.queues, {spend: fromQueue.spend, status: status});

        // If we have both queues, then make the switch
        if (toQueue) this.moveIdea(idea, fromQueue, toQueue);
      };

      return Roadmap;
    });
})();
