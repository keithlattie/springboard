(function() {
  angular.module('springboard.product')
    .service('SpendModalService', function($http, $uibModal) {

      // Open the modal
      this.openSpendModal = function(product) {
        var modal = $uibModal.open({
          templateUrl: 'product/spend/spendModal.html',
          controller: SpendModalController,
          controllerAs: 'ctrl',
          windowTopClass: 'spend-modal',
          windowClass: 'spend-modal',
          backdrop: 'static',
          resolve: { product: product },
          keyboard: false
        });

        // https://angular-ui.github.io/bootstrap/
        // return modal.result.then(function(json) {
        //   session.user = User.fromJSON(json.user);
        //   return session.user;
        // });
        return modal;
      };

      return this;
    });

  function SpendModalController($scope, $uibModalInstance, $timeout, product, $http) {
    var ctrl = this;
    $scope.product = product;

    if (product.spends.length == 0) {
      $scope.newSpend = {
        year: null,
        kind: 'budget',
        expense: null,
        capital: null
      };
      // Focus on an input in the new spend
      $timeout(function() {
        $('.new-spend input[name=year]').focus();
      });
    };

    $scope.showNewSpend = function() {
      // If it's not showing, create a new object to work with
      if (!$scope.newSpend) $scope.newSpend = {
        year: null,
        kind: 'budget',
        expense: null,
        capital: null
      };

      // Focus on an input in the new spend
      $timeout(function() {
        $('.new-spend input[name=year]').focus();
      });
    };

    $scope.createNewSpend = function() {
      $scope.submittingNewSpend = true;
      $scope.product.addSpend($scope.newSpend).then(function() {
        $scope.newSpend = undefined;
        $scope.submittingNewSpend = false;
      }, function(err) {
        $scope.submittingNewSpend = false;
      });
    };

    $scope.close = function() {
      $uibModalInstance.dismiss('cancel');
    };
  }
}());
