(function() {
  angular.module('springboard.product')
    .service('EditPortfolio', function($uibModal, Portfolio) {
      this.show = function(product) {
        return $uibModal.open({
          templateUrl: 'product/editPortfolio.html',
          controller: EditPortfolioController,
          controllerAs: 'ctrl',
          windowClass: 'edit-portfolio',
          backdrop: 'static',
          resolve: {
            portfolios: function() { return Portfolio.query().$promise; },
            product: function() { return product; }
          }
        }).result;
      };

      return this;
    });

  function EditPortfolioController($scope, $uibModalInstance, portfolios, product, Toaster) {
    var ctrl = this;
    ctrl.product = product;
    ctrl.portfolios = portfolios;
    ctrl.portfolio = _.findWhere(portfolios, {id: product.portfolio_id});

    ctrl.submit = function () {
      ctrl.submitting = true;
      product.$patch({portfolio_id: ctrl.portfolio.id}).then(function() {
        $uibModalInstance.close();
      }, function(err) {
        ctrl.submitting = false;
        Toaster.add('Error updating Product Portfolio', 'danger');
      });
    };

    ctrl.cancel = function () {
      $uibModalInstance.dismiss('cancel');
    };
  };
})();
