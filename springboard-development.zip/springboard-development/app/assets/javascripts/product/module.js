//= require_self
//= require_tree ./controllers
//= require_tree ./directives
//= require_tree ./factories
//= require_tree ./services
//= require_tree ./filters

(function() {
  angular.module('springboard.product', ['ui.router', 'angular-sortable-view', 'springboard.shared', 'springboard.templates', 'bcherny/formatAsCurrency']);
}());
