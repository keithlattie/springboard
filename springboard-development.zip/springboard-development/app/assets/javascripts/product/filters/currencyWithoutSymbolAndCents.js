(function() {
  angular.module('springboard.product')
    .filter('currencyWithoutSymbolAndCents', function ($filter) {
      return function (value) {
        return $filter('currency')(value, '', 0);
      }
    });
}());
