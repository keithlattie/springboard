(function() {
  angular.module('springboard.product')
    .config(function($stateProvider) {
      $stateProvider.state('product.profile', {
        url: '?feature',
        controller: 'ProductProfileCtrl',
        controllerAs: 'ctrl',
        templateUrl: 'product/profile.html',
        expandedTemplateUrl: 'product/profile/expanded.html',
        reloadOnSearch: false
      });
    })
    .controller('ProductProfileCtrl', function($element, $scope, $state, $timeout, Confirm, Feature, Session, Sortable, Toaster) {
      var ctrl = this;
      var filter = ctrl.filter = $scope.ctrl.filter = {text: ''};
      var product = ctrl.product = $scope.ctrl.product;

      // Add to the product menu
      var menu = _.union([{
        id: 'add-component',
        role: 'editor',
        text: 'Add Component',
        onClick: addComponent
      }], $scope.ctrl.productMenu);

      // Prepend to product menu
      $scope.ctrl.setProductMenu(menu);

      // Add a new component
      function addComponent() {
        ctrl.product.addComponent({
          name: 'New Component #' + (ctrl.product.components.length + 1),
          position: 1
        }).then(function(component) {
          var focus = _.partial(focusComponent, component);
          $timeout(focus);
        }, function(err) {
          Toaster.add('Error adding Component', 'danger');
        });
      }

      // Component updated
      ctrl.updatedComponent = function(err) {
        if (err) Toaster.add('Error updating Component', 'danger');
      };

      // Delete this component
      ctrl.deleteComponent = function(component) {
        return Confirm.show({
          title: 'Remove Component?',
          body: 'Are you sure you want to remove "' + component.name + '" and all of its features?',
          action: 'Remove'
        }).then(function() {
          return product.removeComponent(component).catch(function(err) {
            Toaster.add('Error deleting Component', 'danger');
          });
        });
  		};

      // Focus on this component
      function focusComponent(component) {
        var $componentEl = $element.find('li.component[data-id=' + component.id + ']');
        $componentEl.find('> .component [name=name]').select();
      }

      // Add a feature
      ctrl.addFeature = function(component, name) {
        return component.addFeature({
          name: name,
          position: 1
        }).catch(function(err) {
          Toaster.add('Error adding Feature', 'danger');
        });
      };

      // Feature updated
      ctrl.updatedFeature = function(err) {
        if (err) Toaster.add('Error updating Feature', 'danger');
      };

      // Delete this feature
      ctrl.deleteFeature = function(feature) {
        var component = _.find(product.components, function(component) {
          return _.contains(component.features, feature);
        });

        Confirm.show({
          title: 'Remove Feature?',
          body: 'Are you sure you want to remove "' + feature.name + '"?',
          action: 'Remove'
        }).then(function() {
          return component.removeFeature(feature).then(function() {
            ctrl.setFeature();
          }, function(err) {
            Toaster.add('Error deleting Feature', 'danger');
          });
        });
      };

      // Move a feature
      ctrl.moveFeature = function(feature, oldFeatures, newFeatures, oldIndex, newIndex) {
        if (oldFeatures === newFeatures) { // Same Component
          Sortable.resetPositions(newFeatures);
          feature.$patch({position: feature.position});
        } else { // Different Component
          var component = _.findWhere(product.components, {features: newFeatures});
          Sortable.resetPositions(oldFeatures);
          Sortable.resetPositions(newFeatures);
          feature.$patch({position: feature.position, component_id: component.id});
        }
      };

      // Add a benefit to the current feature
      ctrl.addFeatureBenefit = function() {
        var feature = ctrl.feature;
        feature.addBenefit({
          name: 'New Benefit #' + (feature.benefits.length + 1)
        }).then(function(benefit) {
          $timeout(function() {
            var $benefitEl = $element.find('aside.feature li.benefit[data-id=' + benefit.id + ']');
            var $inputEl = $benefitEl.find('.benefit-name');
            $inputEl.focus().select();
          });
        }, function(err) {
          Toaster.add('Error adding Benefit', 'danger');
        });
      };

      // Keep track of the current feature
      $scope.$watch(function() {
        if ($state.params.feature) return parseInt($state.params.feature, 10);
      }, function(featureId) {
        var features = _.chain(product.components).pluck('features').flatten().value();
        ctrl.feature = _.findWhere(features, {id: featureId});
      });

      // Set this as the current feature in the sidebar
      ctrl.setFeature = function(feature) {
        var featureId = feature ? feature.id : null;
        $state.go('.', {feature: featureId}, {notify: false});
      };
    });
}());
