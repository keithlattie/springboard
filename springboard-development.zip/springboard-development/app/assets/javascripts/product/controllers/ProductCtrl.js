  (function() {
  angular.module('springboard.product')
    .config(function($stateProvider) {
      $stateProvider.state('product', {
        abstract: true,
        url: '/products/:id',
        controller: 'ProductCtrl',
        controllerAs: 'ctrl',
        templateUrl: 'product/layout.html'
      });
    })
    .controller('ProductCtrl', function($scope, $state, $stateParams, Confirm, EditPortfolio, Product, Session, Toaster, SpendModalService, TeamModalService) {
      var ctrl = this;

      // Load the product
      Product.get({id: $stateParams.id}).$promise.then(function(product) {
        ctrl.product = product;
      });

      // Menu -----------------------------------------------------------------

      // Default product menu
      var productMenu = [{
        id: 'edit-portfolio',
        role: 'editor',
        text: 'Edit Portfolio',
        onClick: editPortfolio
      }, {
        id: 'delete-product',
        role: 'admin',
        text: 'Delete Product',
        onClick: deleteProduct
      }];

      // Change the menu
      ctrl.setProductMenu = function(menu) {
        ctrl.productMenu = _.clone(menu);
        updateUserMenu(Session.user);
      };

      // Update a user's menu
      function updateUserMenu(user) {
        ctrl.userProductMenu = _.filter(ctrl.productMenu, function(item) {
          return !item.role || (user && user[item.role]);
        });
      }

      // Trigger menu updates
      $scope.$watch(function() {
        return Session.user;
      }, updateUserMenu);

      // State Change ---------------------------------------------------------

      // When the state changes, reset attributes that are defined by child controllers
      function onStateChange(state) {
        var expandedTemplateUrl = state.expandedTemplateUrl;
        ctrl.expanded = !!expandedTemplateUrl;
        ctrl.expandedAnimate = false;
        ctrl.expandedTemplateUrl = expandedTemplateUrl;
        ctrl.filter = false;
        ctrl.setProductMenu(productMenu);
      }

      // Set the initial state
      onStateChange($state.current);

      // Handle state changes after initial load
      $scope.$on('$stateChangeStart', function(event, toState) {
        onStateChange(toState);
      });

      // Handlers ---------------------------------------------------------

      // Edit the portfolio for the product
      function editPortfolio() {
        EditPortfolio.show(ctrl.product);
      }

      // Delete the product
      function deleteProduct() {
        Confirm.show({
          title: 'Remove Product?',
          body: 'Are you sure you want to remove "' + ctrl.product.name + '"? This will remove all components, features, benefits, metrics, ideas, etc.',
          action: 'Remove',
          challenge: ctrl.product.name
        }).then(function() {
          return ctrl.product.$delete().then(function() {
            $state.go('dashboard');
          }, function(err) {
            Toaster.add('Error deleting Product', 'danger');
          });
        });
      };

      // Toggle the expanded state
      ctrl.toggleExpanded = function() {
        ctrl.expandedAnimate = true;
        ctrl.expanded = !ctrl.expanded;
      };

      ctrl.openSpendModal = function() {
        SpendModalService.openSpendModal(ctrl.product);
      };

      ctrl.openTeamModal = function() {
        TeamModalService.openModal(ctrl.product);
      };
    });
}());
