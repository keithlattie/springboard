(function() {
  angular.module('springboard.product')
    .config(function($stateProvider) {
      $stateProvider.state('product.roadmap', {
        url: '/roadmap?idea',
        controller: 'ProductRoadmapCtrl',
        controllerAs: 'ctrl',
        templateUrl: 'product/roadmap.html',
        reloadOnSearch: false
      });
    })
    .controller('ProductRoadmapCtrl', function($scope, $q, Idea, Roadmap) {
      var ctrl = this;
      var product = ctrl.product = $scope.ctrl.product;

      // Load all of the ideas for this product
      Idea.query({product: product.id}).$promise.then(function(ideas) {
        ctrl.ideas = ideas;
        var promises = _.invoke(ideas, 'loadUsers');
        return $q.all(promises);
      }).then(function(ideas) {
        ctrl.roadmap = new Roadmap(product, ideas);
        ctrl.loaded = true;
      });

      // Show the new idea form
      ctrl.showNewIdea = function() {
        // Make sure the inbox lane is visible
        var inbox = _.findWhere(ctrl.roadmap.lanes, {id: 'inbox'});
        inbox.active = true;

        // Show the new idea
        ctrl.newIdea = true;

        // Focus on the new idea
        _.defer(function() {
          $('sb-idea-new input[name=title]').focus();
        });
      };

      // Hide the new idea form
      ctrl.hideNewIdea = function() {
        ctrl.newIdea = false;
      };

      // Toggle this lane being visible
      ctrl.toggleLane = function(lane) {
        lane.active = !lane.active;

        // If inbox, turn the new idea off
        if (!lane.active && lane.id === 'inbox') ctrl.newIdea = false;
      };
    });
}());
