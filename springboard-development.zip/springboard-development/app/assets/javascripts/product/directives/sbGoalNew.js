(function() {
  angular.module('springboard.product')
    .directive('sbGoalNew', function(Goal, MetricService, Toaster) {
      return {
        restrict: 'E',
        scope: {
          close: '&', // Callback to close
          idea: '='
        },
        templateUrl: 'product/roadmap/goalNew.html',
        controllerAs: 'ctrl',
        controller: function ($scope) {
          var ctrl = this;
          ctrl.amountTypes = Goal.amountTypes;
          ctrl.amountType = _.first(ctrl.amountTypes);
          ctrl.durationTypes = Goal.durationTypes;
          ctrl.durationType = _.first(ctrl.durationTypes);

          // Determine the paramters
          function goalParams() {
            // Start with required params
            var params = {
              metric_id: ctrl.metric.id
            };

            // Is amount?
            if (ctrl.amount) {
              params.amount = ctrl.amount;
              params.amount_type = ctrl.amountType.id;
            }

            // Is duration
            if (ctrl.duration) {
              params.duration = ctrl.duration;
              params.duration_type = ctrl.durationType.id;
            }

            return params;
          }

          // Create the goal
          ctrl.submit = function() {
            var params = goalParams();
            ctrl.submitting = true;
            $scope.idea.addGoal(params).then(function() {
              $scope.close();
            }, function(err) {
              ctrl.submitting = false;
              Toaster.add('Error creating Goal', 'danger');
            });
          };

          // Set the current metric
          ctrl.setMetric = function(metricId) {
            ctrl.metric = _.findWhere(MetricService.metrics, {id: metricId});
          };
        }
      };
    });
}());
