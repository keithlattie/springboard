(function() {
  angular.module('springboard.product')
    .directive('sbSpendRowForm', function(Session) {
      return {
        restrict: 'A',
        scope: {
          remove: '&', // Callback to remove this spend
          spend: '=', // The spend to edit
          submit: '&', // Callback to submit the spend,
          submitting: '=' // Flag to whether we're submitting the spend
        },
        templateUrl: 'product/spend/spendRowForm.html',
        link: function($scope, $el, attr) {
          $scope.canRemove = !!attr.remove;
          $scope.session = Session;
        }
      };
    });
}());
