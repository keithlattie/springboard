(function() {
  angular.module('springboard.product')
    .directive('sbIdeaDetails', function(Confirm, Idea, Session, Versionable) {
      var viewTpl = 'product/roadmap/ideaDetails.html';
      var editTpl = 'product/roadmap/ideaDetailsEdit.html';

      return {
        restrict: 'E',
        scope: {
          idea: '=', // Idea to detail (required)
          product: '=', // Product the idea is on (required)
          onRemove: '&', // Callback after the idea is removed (optional)
          roadmap: '=', // Roadmap this idea is a part of (optional)
          queue: '=' // Queue this idea is a part of (optional)
        },
        template: '<div class="idea-details" ng-include="templateUrl"></div>',
        controller: function ($scope) {
          var product = $scope.product;
          var idea = $scope.idea;
          $scope.businessValues = Idea.businessValues;
          $scope.productHealths = Idea.productHealths;
          $scope.session = Session;
          $scope.statuses = Idea.statuses;

          // Keep track of allowed investment points
          $scope.$watch('queue.spend', function(spend) {
            var minimum = spend ? 0 : undefined;
            $scope.investmentPoints = Idea.getInvestmentPoints(minimum);
          });

          // Keep track of our mode
          $scope.$watch(function() {
            return idea.canEdit();
          }, function(canEdit) {
            $scope.templateUrl = canEdit ? editTpl : viewTpl;
          });

          // Keep track of the pinnables for formatting
          var mapPinnable = _.bind(product.mapPinnable, product);
          $scope.$watchCollection('idea.pinnables', function(pinnables) {
            $scope.pinnables = _.map(pinnables, mapPinnable);
          });

          // Keep generated list of followers
          // TODO: This will be replaced by an actual relation
          $scope.$watchCollection(function() {
            return _.chain([
              idea.createdBy,
              idea.updatedBy,
              idea.owner,
              idea.originator,
            ]).compact().uniq().value();
          }, function(followers) {
            $scope.followers = followers;
          });

          // Keep track of history
          $scope.$watch('idea.status', getVersions, true);

          // Get all the versions for this idea
          function getVersions() {
            idea.getVersions().then(function(versions) {
              $scope.versions = _.chain(versions).map(function(version) {
                version.messages = Versionable.format(version, Idea.formatVersion);
                return version;
              }).filter(function(version) {
                return version.whodunnit && version.messages.length;
              }).value();
            });
          }

          // Delete this idea
          $scope.remove = function() {
            return Confirm.show({
              title: 'Remove Idea?',
              body: 'Are you sure you want to remove "' + idea.title + '"?',
              action: 'Remove'
            }).then(function() {
              return idea.$delete().then(function() {
                if ($scope.onRemove) $scope.onRemove();
              });
            });
          };

          // Show the new goal form
          $scope.showNewGoalForm = function() {
            $scope.showNewGoal = true;
          };

          // Hide the new goal form
          $scope.hideNewGoalForm = function() {
            $scope.showNewGoal = false;
          };
        }
      };
    });
}());
