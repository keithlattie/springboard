(function() {
  angular.module('springboard.product')
    .directive('sbIdeaQueue', function($compile, $state, $templateCache, Roadmap, Session) {
      // Template for a idea summary
      var ideaTplUrl = 'product/roadmap/idea.html';
      var ideaTpl = _.template($templateCache.get(ideaTplUrl));

      // Placeholder template for idea details
      var detailsTpl = '<div class="idea-details">\
      <button type="button" class="btn-icon fa fa-caret-down" ng-click="close()"></button>\
      <sb-idea-details product="product" idea="idea" queue="queue" roadmap="roadmap" on-remove="onRemove()"></sb-idea-details>\
      </div>';

      return {
        restrict: 'E',
        scope: {
          queue: '=', // Queue to render,
          roadmap: '=' // Roadmap we're a part of
        },
        link: function ($scope, $el) {
          var queue = $scope.queue;
          var roadmap = $scope.roadmap;

          // Add an idea to the element, so other queues know who we are
          $el.data('id', queue.id);

          // Render the ideas
          var html = _.map(queue.ideas, renderIdea);
          $el.html(html);

          // If there is a idea parameter, start with that one open
          if ($state.params.idea) {
            var id = parseInt($state.params.idea, 10);
            var idea = _.findWhere(queue.ideas, {id: id});
            if (idea) showIdeaDetails(idea);
          }

          // Watch for changes
          $scope.$watchCollection('queue.ideas', function(ideas, prev) {
            // Look for additions
            var newIdeas = _.difference(ideas, prev);
            _.each(newIdeas, function(idea) {
              var $ideaEl = findIdeaElById(idea.id);
              if (!$ideaEl.length) insertIdea(idea);
            });

            // Look for removals
            var oldIdeas = _.difference(prev, ideas);
            _.each(oldIdeas, removeIdea);
          });

          // Insert a idea
          function insertIdea(idea) {
            var index = queue.ideas.indexOf(idea);
            var html = renderIdea(idea);
            $el.insertAt(index, html);
          }

          // Remove a idea from the UI
          function removeIdea(idea) {
            findIdeaElById(idea.id).remove();
          }

          // SORTING ----------------------------------------------------------

          var dragGhost;
          var sortable = new Sortable($el[0], {
            group: 'idea-queue',
            handle: '.idea-summary',
            filter: '.idea-show-details',
            sort: true,

            // Changed sorting within list
            onUpdate: function (e) {
              // Determine the idea
              var id = $(e.item).data('id');
              var idea = _.findWhere(roadmap.ideas, {id: id});

              // Move the idea
              roadmap.moveIdea(idea, queue, queue, e.newIndex);
              $scope.$apply();
            },

            // Element is dropped into the list from another list
            onAdd: function (e) {
              // Determine the idea
              var id = $(e.item).data('id');
              var idea = _.findWhere(roadmap.ideas, {id: id});

              // Determine the from queue
              var fromId = $(e.from).data('id');
              var fromQueue = _.findWhere(roadmap.queues, {id: fromId});

              // Move the queues
              roadmap.moveIdea(idea, fromQueue, queue, e.newIndex);
              $scope.$apply();
            },

            // Handler for moving an idea
            onMove: function(e) {
              // Determine the idea
              var id = $(e.dragged).data('id');
              var idea = _.findWhere(roadmap.ideas, {id: id});

              // Determine queue to move it to
              var toId = $(e.to).data('id');
              var toQueue = _.findWhere(roadmap.queues, {id: toId});

              // Determine if this is allowed
              return Roadmap.canMoveIdea(idea, toQueue);
            }
          });

          // Helper for editing
          function canSort() {
            var user = Session.user;
            return user && user.editor;
          }

          // Keep track of our mode
          $scope.$watch(canSort, function(canSort) {
            sortable.option('disabled', !canSort);
          });

          // HANDLERS ---------------------------------------------------------

          // Find a idea element by id
          function findIdeaElById(id) {
            return $el.find('.idea[data-id=' + id + ']');
          }

          // Find a idea element from the current element
          function findIdeaElByEl(el) {
            return $(el).closest('.idea[data-id]');
          }

          // Find a idea from the current element
          function findIdeaByEl(el) {
            var id = findIdeaElByEl(el).data('id');
            return _.findWhere(queue.ideas, {id: id});
          }

          // Render the summary HTML for this idea
          function renderIdea(idea) {
            return ideaTpl({idea: idea});
          }

          // Show the idea details in place of the summary
          function showIdeaDetails(idea) {
            // Find the element(s)
            var $ideaEl = findIdeaElById(idea.id);

            // Create the details scope
            var scope = $scope.$new();
            scope.onRemove = function() {
              scope.$destroy();
              roadmap.removeIdea(idea);
            };
            scope.product = roadmap.product;
            scope.queue = queue;
            scope.roadmap = roadmap;
            scope.idea = idea;
            scope.close = function() {
              scope.$destroy();
              var html = renderIdea(idea);
              $ideaEl.replaceWith(html);
            };

            // Render the details
            var detailsEl = $compile(detailsTpl)(scope);
            $ideaEl.html(detailsEl);
          }

          // Handle showing idea details (click)
          $el.on('click', '.idea .idea-show-details', function() {
            var idea = findIdeaByEl(this);
            showIdeaDetails(idea);
            $scope.$apply();
          });

          // Handle showing idea details (double click)
          $el.on('dblclick', '.idea-summary', function() {
            var idea = findIdeaByEl(this);
            showIdeaDetails(idea);
            $scope.$apply();
          });
        }
      };
    });
}());
