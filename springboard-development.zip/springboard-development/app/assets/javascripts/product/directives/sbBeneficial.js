(function() {
  angular.module('springboard.product')
    .directive('sbBeneficial', function() {
      return {
        restrict: 'A',
        scope: {
          beneficial: '=sbBeneficial'
        },
        templateUrl: 'product/profile/beneficial.html'
      };
    });
}());
