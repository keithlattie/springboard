(function() {
  angular.module('springboard.product')
    .directive('sbBeneficialEdit', function(Confirm) {
      return {
        restrict: 'A',
        scope: {
          beneficial: '=sbBeneficialEdit'
        },
        templateUrl: 'product/profile/beneficialEdit.html',
        controller: function($scope) {
          var beneficial = $scope.beneficial;
          $scope.newBenefit = {};

          // Add a benefite and reset the new benefit
          $scope.addBenefit = function() {
            $scope.creatingBenefit = true;
            beneficial.addBenefit($scope.newBenefit).then(function() {
              $scope.creatingBenefit = false;
              $scope.newBenefit = {};
            }, function(err) {
              $scope.creatingBenefit = false;
            });
          };

          // Remove this benefit. Confirm if it has metrics
          $scope.removeBenefit = function(benefit) {
            // If it has no metric, just delete
            if (!benefit.metric_ids.length) return beneficial.removeBenefit(benefit);

            // If it has metrics, confirm delete
            return Confirm.show({
              title: 'Remove Benefit?',
              body: 'Are you sure you want to remove "' + benefit.name + '" and all of its metrics?',
              action: 'Remove'
            }).then(function() {
              return beneficial.removeBenefit(benefit);
            });
          };
        }
      };
    });
}());
