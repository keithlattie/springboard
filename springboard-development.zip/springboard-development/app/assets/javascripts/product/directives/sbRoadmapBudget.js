(function() {
  angular.module('springboard.product')
    .directive('sbRoadmapBudget', function(Roadmap) {
      return {
        restrict: 'E',
        scope: {
          spend: '=', // Spend to render
          roadmap: '=' // Roadmap we're a part of
        },
        templateUrl: 'product/roadmap/budget.html',
        link: function ($scope, $el) {
          // Calculate the totals of all the ideas
          function calculateTotals() {
            var spend = $scope.spend;
            return _.chain($scope.roadmap.ideas).where({
              spend_id: spend.id
            }).reduce(function(total, idea) {
              total.businessValue += idea.business_value || 0;
              total.investmentPoints += idea.investment_points || 0;
              total.productHealth += idea.product_health || 0;
              return total;
            }, {
              businessValue: 0,
              investmentPoints: 0,
              productHealth: 0
            }).value();
          }

          // Calculate the budget
          function calculateBudget(total) {
            var spend = $scope.spend;
            var current = total.investmentPoints;
            var max = Math.floor(spend.capital / Roadmap.dollarsPerInvestmentPoint);
            var percentage = Math.floor(current * 100 / max);
            return {
              current: current,
              max: max,
              percentage: percentage,
              valid: percentage <= 100,
              progress: Math.min(percentage, 100)
            }
          }

          // Watch the totals
          $scope.$watch(calculateTotals, function(total) {
            $scope.total = total;
            $scope.budget = calculateBudget(total);
          }, true);
        }
      };
    });
}());
