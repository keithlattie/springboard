(function() {
  angular.module('springboard.product')
    .directive('sbTeamRowForm', function(Session) {
      return {
        restrict: 'A',
        scope: {
          remove: '&', // Callback to remove this team
          team: '=', // The team to edit
          submit: '&', // Callback to submit the team,
          submitting: '=' // Flag to whether we're submitting the team
        },
        templateUrl: 'product/team/teamRowForm.html',
        link: function($scope, $el, attr) {
          $scope.canRemove = !!attr.remove;
          $scope.session = Session;
          $scope.roles = ["Architect", "Delivery Manager", "Director", "Manager", "Product Lead", "Project Lead", "Senior Director", "Senior Manager", "Technical Lead", "VP"];
        }
      };
    });
}());
