(function() {
  angular.module('springboard.shared')
  .directive('sbTeamRolesDropdown', function(Toaster) {
    return {
      restrict: 'A',
      templateUrl: 'product/team/rolesDropdown.html',
      scope: {
        teamMember: '=team'
      },
      controller: function($scope) {
        $scope.roles = ["Architect", "Delivery Manager", "Director", "Manager", "Product Lead", "Project Lead", "Senior Director", "Senior Manager", "Technical Lead", "VP"];

        $scope.updateRole = function(role) {
          if($scope.teamMember.id) {
            $scope.teamMember.$patch("role", role).then(function() {
              $scope.teamMember.role = role;
            }, function() {
              Toaster.add('Error applying role: ' + role + ' to ' + $scope.teamMember.name, 'danger');
            });
          } else {
            $scope.teamMember.role = role;
          }
        };
      }
    }
  });
}());
