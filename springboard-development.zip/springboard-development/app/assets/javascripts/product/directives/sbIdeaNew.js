(function() {
  angular.module('springboard.product')
    .directive('sbIdeaNew', function(Idea, Session, Toaster) {
      return {
        restrict: 'E',
        scope: {
          close: '&', // Callback to close
          roadmap: '='
        },
        templateUrl: 'product/roadmap/ideaNew.html',
        controller: function ($scope) {
          var roadmap = $scope.roadmap;

          // Get constants
          $scope.businessValues = Idea.businessValues;
          $scope.productHealths = Idea.productHealths;
          $scope.investmentPoints = Idea.investmentPoints;

          // Create the idea
          $scope.idea = new Idea({
            originator: Session.user
          });

          // Create the idea
          $scope.submit = function() {
            $scope.submitting = true;

            // Create the idea
            var params = _.pick($scope.idea, 'title', 'description', 'business_value', 'product_health', 'investment_points');
            params.position = 1;
            params.originator_id = $scope.idea.originator.id;
            roadmap.addIdea(params).then(function() {
              $scope.close();
            }, function(err) {
              $scope.submitting = false;
              Toaster.add('Error creating Idea', 'danger');
            });
          };
        }
      };
    });
}());
