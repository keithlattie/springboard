(function() {
  angular.module('springboard.shared')
  .directive('sbMetricsDropdown', function(MetricService) {
    return {
      restrict: 'A',
      scope: {
        addMetric: '&',
        hasMetric: '&'
      },
      templateUrl: 'product/profile/metricsDropdown.html',
      controller: function($scope) {
        $scope.metric_categories = MetricService.categories;
      }
    }
  });
}());
