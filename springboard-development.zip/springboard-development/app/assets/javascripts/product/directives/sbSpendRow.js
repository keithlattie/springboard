(function() {
  angular.module('springboard.product')
    .directive('sbSpendRow', function($timeout, Confirm, Session) {
      return {
        restrict: 'E',
        scope: {
          product: '=',
          spend: '='
        },
        templateUrl: 'product/spend/spendRow.html',
        controller: function($scope, $element) {
          var product = $scope.product;
          var spend = $scope.spend;
          $scope.session = Session;

          // Go into editing mode, by cloning the atttributes to change
          $scope.startEditing = function(field) {
            $scope.edit = _.pick(spend, 'year', 'capital', 'expense');
            $timeout(function() {
              $element.find('input[name=' + field + ']').focus();
            });
          };

          $scope.submit = function() {
            $scope.submitting = true;
            spend.$patch($scope.edit).then(function() {
              $scope.submitting = false;
              $scope.edit = undefined;
            }, function(err) {
              $scope.submitting = false;
            });
          };

          $scope.remove = function() {
            return Confirm.show({
              title: 'Remove Spend for ' + spend.year + '?',
              body: 'Are you sure you want to remove ' + spend.year + ' Spend data?',
              action: 'Remove'
            }).then(function() {
              return product.removeSpend(spend);
            });
          };
        }
      };
    });
}());
