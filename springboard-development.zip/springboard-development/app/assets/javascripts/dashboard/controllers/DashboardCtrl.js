(function() {
  angular.module('springboard.dashboard')
    .config(function($stateProvider) {
      $stateProvider.state('dashboard', {
        url: '/dashboard',
        controller: 'DashboardCtrl',
        controllerAs: 'ctrl',
        templateUrl: 'dashboard.html',
        primaryNavCls: 'container-banner'
      });
    })
    .controller('DashboardCtrl', function($scope, $state, $q, NewProduct, Portfolio, Product, productFilter) {
      var ctrl = this;
      ctrl.filter = {};

      // Load what we need
      $q.all([
        Portfolio.query().$promise,
        Product.query().$promise,
      ]).then(function(result) {
        ctrl.portfolios = _.sortBy(result[0], 'position');
        ctrl.allProducts = _.sortBy(result[1], 'name');
        ctrl.updateProducts();
        ctrl.loaded = true;
      });

      // Update the list of products
      ctrl.updateProducts = function() {
        ctrl.products = productFilter(ctrl.allProducts, ctrl.filter);
        _.each(ctrl.portfolios, function(portfolio) {
          portfolio.products = _.where(ctrl.products, {portfolio_id: portfolio.id});
        });
      };

      // Create a new product
      ctrl.newProduct = function() {
        NewProduct.show().then(function(product) {
          $state.go('product.profile', {id: product.id});
        });
      };
    });
}());
