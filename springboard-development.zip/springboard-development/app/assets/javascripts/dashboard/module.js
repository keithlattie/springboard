//= require_self
//= require_tree ./controllers

(function() {
  angular.module('springboard.dashboard', ['ui.router', 'springboard.shared', 'springboard.templates']);
}());
