//= require_self
//= require_tree ./controllers

(function() {
  angular.module('springboard.admin', ['ui.router', 'springboard.shared', 'springboard.templates']);
}());
