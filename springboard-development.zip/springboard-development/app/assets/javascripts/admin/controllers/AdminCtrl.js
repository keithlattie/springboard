(function() {
  angular.module('springboard.admin')
    .config(function($stateProvider) {
      $stateProvider.state('admin', {
        abstract: true,
        url: '/admin',
        controller: 'AdminCtrl',
        controllerAs: 'ctrl',
        templateUrl: 'admin/layout.html'
      });
    })
    .controller('AdminCtrl', function() {
      var ctrl = this;
    });
}());
