(function() {
  angular.module('springboard.admin')
    .config(function($stateProvider) {
      $stateProvider.state('admin.users', {
        url: '/users',
        controller: 'AdminUsersCtrl',
        controllerAs: 'ctrl',
        templateUrl: 'admin/users.html'
      });
    })
    .controller('AdminUsersCtrl', function(User) {
      var ctrl = this;

      // Load data
      User.query().$promise.then(function(users) {
        ctrl.users = users;
      });
    });
}());
