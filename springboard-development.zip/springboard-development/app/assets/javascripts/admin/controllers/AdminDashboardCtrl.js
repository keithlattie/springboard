(function() {
  angular.module('springboard.admin')
    .config(function($stateProvider) {
      $stateProvider.state('admin.dashboard', {
        url: '',
        controller: 'AdminDashboardCtrl',
        controllerAs: 'ctrl',
        templateUrl: 'admin/dashboard.html'
      });
    })
    .controller('AdminDashboardCtrl', function(User) {
      var ctrl = this;

      // Load data
      User.query().$promise.then(function(users) {
        ctrl.users = users;
      });
    });
}());
