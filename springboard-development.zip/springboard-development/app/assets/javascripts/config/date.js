Date.fromJSON = function(date) {
  if (!date) return null;
  if (date instanceof Date) return date;
  return moment.parseZone(date).toDate();
};

Date.prototype.format = function(format) {
  return moment(this).format(format);
};

Date.prototype.fromNow = function() {
  return moment(this).fromNow();
};

Date.prototype.fromToday = function() {
  // Determine the difference in days
  var today = moment().startOf('day');
  var delta = moment(this).startOf('day').diff(today);

  // Format based on the difference in days
  if (delta === -1) return 'yesterday';
  if (delta === 0) return 'today';
  if (delta === 1) return 'tomorrow';
  return moment(this).format('MMMM D, YYYY');
};
