$.fn.insertAt = function(index, el) {
  index === 0 ? $(this).prepend(el) : $(this).children().eq(index - 1).after(el);
};
