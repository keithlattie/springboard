class Product < ActiveRecord::Base
  DEFAULT_IMAGE_URL = '/images/products/default.jpg'.freeze

  belongs_to :portfolio

  with_options dependent: :destroy do |assoc|
    assoc.has_many :components
    assoc.has_many :ideas
    assoc.has_many :spends
    assoc.has_many :team_members
  end

  has_many :favorites,
    as: :favorable

  has_many :favored_users,
    through: :favorites,
    class_name: 'User',
    source: :user

  #@@OVERRIDE of ActiveRecord's `image_url`
  def image_url
    read_attribute(:image_url) || DEFAULT_IMAGE_URL
  end
end
