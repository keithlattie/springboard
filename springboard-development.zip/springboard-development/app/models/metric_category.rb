class MetricCategory < ActiveRecord::Base
  validates :name, :icon, presence: true

  has_many :metrics
end
