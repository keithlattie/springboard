class Spend < ActiveRecord::Base
  belongs_to :product
  has_many :ideas
end
