class TeamMember < ActiveRecord::Base
  include TeamMemberRoles

  belongs_to :product

  validates :name, :role, :product_id, presence: true

  validates :role,
    uniqueness: { scope: [:name, :product_id] }

  validate :can_only_have_one_product_owner

  private

  #this could be a partial unique index in Postgres - but it requires a custom trigger in MySQL to accomplish the same
  # I'll go that route if we *really* need it.  This validation should hold for a while though.
  def can_only_have_one_product_owner
    if new_record? && product_owner? && TeamMember.where(product_id: self.product_id, role: PRODUCT_OWNER).exists?
      errors.add(:role, 'There can only be one Product Owner')
    end
  end

  def product_owner?
    self.role == PRODUCT_OWNER
  end

end
