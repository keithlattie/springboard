require 'csv'

class Products::Export::DataInventory < Products::Export::Base

  def self.to_csv
    new().to_csv
  end

  def initialize
    #load all the data in a giant INNER JOIN
    @component_products = ::Product.
                    joins([:portfolio, {components: {benefits: {metrics: :metric_category}}}]).
                    select("products.id, products.name as product_name, portfolios.name as portfolio_name, components.name as component_name, benefits.name as benefit_name, metrics.name as metric_name, metric_categories.name as mc_name")

    @feature_products = ::Product.
                    joins([:portfolio, {components: {features: {benefits: {metrics: :metric_category}}}}]).
                    select("products.id, products.name as product_name, portfolios.name as portfolio_name, components.name as component_name, features.name as feature_name, benefits.name as benefit_name, metrics.name as metric_name, metric_categories.name as mc_name")
  end

  def to_csv
    CSV.generate do |csv|
      csv << 'ETL Owner,VP Owner,Product Group,Product,Component,Feature,Benefit,Metric Type,Metric'.split(',') #header row
      @component_products.each do |product|
        csv << [etl_owner_for(product),
                vp_owner_for(product),
                product.portfolio_name,
                product.product_name,
                product.component_name,
                'ALL',
                product.benefit_name,
                product.mc_name,
                product.metric_name]
      end

      @feature_products.each do |product|
        csv << [etl_owner_for(product),
                vp_owner_for(product),
                product.portfolio_name,
                product.product_name,
                product.component_name,
                product.feature_name,
                product.benefit_name,
                product.mc_name,
                product.metric_name]
      end
    end
  end
end