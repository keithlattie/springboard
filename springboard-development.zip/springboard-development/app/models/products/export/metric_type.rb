require 'csv'

class Products::Export::MetricType < Products::Export::Base

  def self.to_csv
    new().to_csv
  end

  def initialize
    #load all the data in a giant INNER JOIN
    @products = ::Product.
                    joins({components: {benefits: {metrics: :metric_category}}}).
                    select("metric_categories.name as mc_name, products.name as product_name, products.id").
                    group("metric_categories.name, products.name")
  end

  def to_csv
    CSV.generate do |csv|
      csv << 'Metric Type,ETL Owner,VP Owner,IT VP Owner,Product'.split(',') #header row
      @products.each do |product|
        csv << [product.mc_name, etl_owner_for(product), vp_owner_for(product), it_vp_owner_for(product), product.product_name]
      end
    end
  end
end