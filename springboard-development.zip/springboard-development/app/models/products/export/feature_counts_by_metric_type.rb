require 'csv'

class Products::Export::FeatureCountsByMetricType < Products::Export::Base

  def self.to_csv
    new().to_csv
  end

  def initialize
    #load all the data in a giant INNER JOIN
    @products = ::Product.
                    joins([:portfolio, {components: {benefits: {metrics: :metric_category}}}]).
                    select("products.id, products.name as product_name, metric_categories.name as mc_name, portfolios.name as portfolio_name, count(metric_categories.name) as mc_count").
                    group("products.id, products.name, metric_categories.name, portfolios.name").
                    order("products.name, metric_categories.name")
  end

  def to_csv
    CSV.generate do |csv|
      csv << 'ETL Owner,VP Owner,IT VP Owner,Product Group,Product,Metric Type,Count'.split(',') #header row
      @products.each do |product|
        csv << [etl_owner_for(product),
                vp_owner_for(product),
                it_vp_owner_for(product),
                product.portfolio_name,
                product.product_name,
                product.mc_name,
                product.mc_count]
      end
    end
  end

end