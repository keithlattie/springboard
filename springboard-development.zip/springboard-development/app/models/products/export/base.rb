class Products::Export::Base

  #ETL Owner,VP Owner,IT VP Owner
  def etl_owner_for(product)
    product.team_members.where(role: TeamMember::PRODUCT_OWNER).first&.name
  end

  def vp_owner_for(product)
    product.team_members.where(role: TeamMember::VICE_PRESIDENT).first&.name
  end

  def it_vp_owner_for(product)
    product.team_members.where(role: TeamMember::TECHNICAL_LEAD).first&.name
  end
end