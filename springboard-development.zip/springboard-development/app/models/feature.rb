class Feature < ActiveRecord::Base
  has_many :benefits,
    as: :beneficial
  has_many :pinnables,
    as: :pinnable,
    dependent: :destroy
  has_many :ideas, through: :pinnables, source: :idea
  belongs_to :component
  counter_culture [:component, :product]
  acts_as_list scope: [:component_id]
  validates :name, presence: true

  default_scope { order(component_id: :asc, position: :asc) }
  scope :where_product_id, ->(id) { joins(:component).where("components.product_id" => id) }
end
