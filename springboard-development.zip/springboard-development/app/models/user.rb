class User < ActiveRecord::Base

  # Include default devise modules. Others available are:
  # :confirmable, :lockable, and :omniauthable
  devise :rememberable, :timeoutable, :trackable, :home_depot_authenticatable

  validates :email, presence: true
  validates :username, presence: true, uniqueness: true

  has_many :favorites
  has_many :favorite_products,
    through: :favorites,
    source: :favorable,
    source_type: 'Product'

  # Create a user from the MyTHDPassport profile
  def self.find_or_create_by_profile(profile)
    User.where({
      username: profile.user_id
    }).first_or_create({
      email: profile.e_mail_address,
      first_name: profile.first_name,
      last_name: profile.last_name
    })
  end

  def refresh_thd_groups
    self.home_depot_user_groups = thd_user_groups.select do |user_group|
      Rails.configuration.thd_groups.values.include?(user_group)
    end
  end

  def thd_user_groups
    thd_profile&.user_groups || []
  end

  def thd_profile
    Devise::Strategies::HomeDepotAuthenticatable.
      new(sso_token: self.sso_token).
      get_authentication_profile
  end
end
