module TeamMemberRoles
  extend ActiveSupport::Concern

  included do
    ARCHITECT        = 'Architect'.freeze
    DELIVERY_MANAGER = 'Delivery Manager'.freeze
    PRODUCT_OWNER    = 'Product Owner'.freeze
    PRODUCT_LEAD     = 'Product Lead'.freeze
    TECHNICAL_LEAD   = 'Technical Lead'.freeze
    PROJECT_LEAD     = 'Project Lead'.freeze
    MANAGER          = 'Manager'.freeze
    SENIOR_MANAGER   = 'Senior Manager'.freeze
    DIRECTOR         = 'Director'.freeze
    SENIOR_DIRECTOR  = 'Senior Director'.freeze
    VICE_PRESIDENT   = 'VP'.freeze

    ROLES = [PRODUCT_OWNER, PRODUCT_LEAD, TECHNICAL_LEAD,
             PROJECT_LEAD, ARCHITECT, MANAGER, SENIOR_MANAGER,
              DIRECTOR, SENIOR_DIRECTOR, VICE_PRESIDENT, DELIVERY_MANAGER].freeze

    validates :role, inclusion: {in: ROLES }
  end

  class_methods do
    def self.sorted_roles
      @@sorted_roles ||= [PRODUCT_LEAD, TECHNICAL_LEAD, PROJECT_LEAD, ARCHITECT, MANAGER,
        SENIOR_MANAGER, DIRECTOR, SENIOR_DIRECTOR, VICE_PRESIDENT, DELIVERY_MANAGER].sort
    end
  end
end