class Goal < ActiveRecord::Base
  belongs_to :idea
  belongs_to :metric
  validates :amount_type, inclusion: {in: %w{percentage dollars}}, :allow_nil => true
  validates :duration_type, inclusion: {in: %w{quarters years}}, :allow_nil => true

  def amount
    return nil unless self.amount_hundreths
    self.amount_hundreths.to_f / 100
  end

  def amount=(amount)
    self.amount_hundreths = (amount * 100).round
  end
end
