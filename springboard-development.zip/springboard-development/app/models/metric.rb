class Metric < ActiveRecord::Base
  belongs_to :metric_category

  validates :name, presence: true, uniqueness: true
  validates :directionality, inclusion: {in: %w{up down}}

  has_and_belongs_to_many :benefits
end
