class Favorite < ActiveRecord::Base
  belongs_to :user
  belongs_to :favorable, polymorphic: true

  validates :user_id, :favorable_type, :favorable_id, presence: true
  validates :user_id, uniqueness: { scope: [:favorable_type, :favorable_id] }

  delegate :name, to: :favorable, allow_nil: true
  delegate :image_url, to: :favorable, allow_nil: true

end
