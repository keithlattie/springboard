class Component < ActiveRecord::Base
  belongs_to :product

  counter_culture :product

  has_many :features, dependent: :destroy
  has_many :benefits,
    as: :beneficial
  has_many :pinnables,
    as: :pinnable,
    dependent: :destroy
  has_many :ideas, through: :pinnables, source: :idea
  acts_as_list scope: [:product_id]

  default_scope { order(product_id: :asc, position: :asc) }
end
