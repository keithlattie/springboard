class Idea < ActiveRecord::Base
  belongs_to :product
  belongs_to :originator, class_name: 'User'
  belongs_to :owner, class_name: 'User'
  belongs_to :spend
  validates :status, inclusion: {in: %w{open in-progress completed}}, :allow_nil => true
  has_many :goals, dependent: :destroy
  has_many :pinnables, dependent: :destroy
  has_paper_trail skip: [:id, :mongo_id, :created_at, :created_by, :updated_at, :updated_by]
  acts_as_list scope: [:product_id, :priority, :spend_id]
  default_scope { order(product_id: :asc, priority: :asc, position: :asc) }
end
