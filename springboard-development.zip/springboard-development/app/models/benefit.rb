class Benefit < ActiveRecord::Base
  belongs_to :beneficial, polymorphic: true #component or feature
  has_and_belongs_to_many :metrics

  validates :name, presence: true
end
