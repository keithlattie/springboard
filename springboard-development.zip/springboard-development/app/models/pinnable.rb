class Pinnable < ActiveRecord::Base
  belongs_to :idea
  belongs_to :pinnable, polymorphic: true #component or feature
end
