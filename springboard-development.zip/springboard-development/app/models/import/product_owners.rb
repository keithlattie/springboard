class Import::ProductOwners

  def perform
    {
      'Asset Protection' => 'Stacy Gordon',
      'Associate-Guided Product Selling Tools' => 'Jen Birney',
      'Cash & Carry Checkout' => 'Griff Lewis',
      'Facilities Management' => 'Stacy Gordon',
      'Repair' => 'Fielder Roberts',
      'Reverse Logistics (Returns)' => 'Fielder Roberts',
      'Store Associate Workbench' => 'Dustin Bennett',
      'Store Inventory Management' => 'Subodh Deshpande',
      'Store Merchandising Execution (MET)' => 'Mike Israel',
    }.each do |product_name, owner|
      product = Product.where(name: product_name).first
      team_member = product.team_members.create({
        name: owner,
        role: TeamMember::PRODUCT_OWNER
      }) if product
    end
  end

end
