require 'import/utils'

class Import::HorizonImporter

  attr_accessor :users, :portfolios #accessors for ActiveRecord collections of processed objects

  def perform
    #begin # USERS
    process_users
    process_portfolios

    # PRODUCTS
    products = client[:products].find.sort(portfolioId: 1).map do |json|
      puts "Processing Product: #{json}"

      created_at = json[:_id].generation_time
      portfolio = @portfolios.detect {|p| p.mongo_id == json[:portfolioId]}
      portfolio_id = portfolio.id if portfolio
      product = Product.create({
        mongo_id: json[:_id],
        portfolio_id: portfolio_id,
        name: json[:name].strip,
        description: json[:description][:benefit],
        created_at: created_at,
        updated_at: created_at
      })

      process_spends(json, product)
      process_team_members(json, product)

      product
    end

    # COMPONENTS/FEATURES
    product_components = client[:productReleaseComponents].find().reduce({}) do |memo, json|
      product_id = json[:productId]
      memo[product_id] = json
      memo
    end

    components = product_components.map do |product_id, json|
      product = products.detect {|p| p.mongo_id == product_id.to_s}
      next unless product

      components = json[:components] || []
      components.sort_by {|f| f[:position]}.map do |json|
        puts "Processing Component: #{json}"
        # CREATE PARENT COMPONENT
        component = Component.create({
          mongo_id: json[:_id],
          product_id: product.id,
          name: json[:name].strip,
          description: "Helps with #{json[:name].downcase}.",
          created_at: Import::Utils.parse_time(json[:createdTimestamp]),
          created_by: find_user_id_by_username(json[:createdUserId]),
          updated_at: Import::Utils.parse_time(json[:lastUpdateTimestamp]),
          updated_by: find_user_id_by_username(json[:lastUpdateUserId])
        })

        #CREATE CHILD FEATURES
        features_json = json[:features] || []
        features = features_json.sort_by {|f| f[:position]}.map do |json|
          puts "Processing Feature: #{json}"
          feature = Feature.create({
            mongo_id: json[:_id],
            component_id: component.id,
            name: json[:name].strip,
            created_at: Import::Utils.parse_time(json[:createdTimestamp]),
            created_by: find_user_id_by_username(json[:createdUserId]),
            updated_at: Import::Utils.parse_time(json[:lastUpdateTimestamp]),
            updated_by: find_user_id_by_username(json[:lastUpdateUserId])
          })

          benefits_json = json[:benefits] || []

          feature_benefits = benefits_json.map do |json|
            puts "Processing Feature Benefits: #{json}"

            benefit = feature.benefits.create({
              name: json[:description].strip
            })

            #TODO PROCESS Feature METRICS and Categories HERE
            process_metrics(json, benefit)

            benefit
          end

          feature
        end

        component_benefits = json[:benefits] || []
        component_benefits = component_benefits.map do |json|
          puts "Processing Component Benefits: #{json}"
          benefit = component.benefits.create({
            name: json[:description]
          })

          #TODO PROCESS Component level METRICS and Categories HERE
          process_metrics(json, benefit)

          benefit
        end

        component
      end
    end

    # REQUESTS
    ideas = client[:productSuggestions].find.sort(productId: 1).map do |json|
      puts "Processing Suggestion: #{json}"

      product = products.detect {|p| p.mongo_id == json[:productId].to_s }
      updated_at = Import::Utils.parse_time(json[:lastUpdateTimestamp])
      updated_by = find_user_id_by_username(json[:lastUpdateUserId])
      created_at = Import::Utils.parse_time(json[:createdTimestamp]) || updated_at
      created_by = find_user_id_by_username(json[:createdUserId]) || updated_by
      effort = json[:effort]
      effort = 8 if effort == 4
      effort = 5 if effort == 3

      PaperTrail.whodunnit = created_by
      idea = Idea.create({
        mongo_id: json[:_id],
        product_id: product.id,
        originator_id: created_by,
        title: json[:title].strip,
        description: json[:description].strip,
        business_value: json[:impact],
        investment_points: effort,
        created_at: created_at,
        created_by: created_by,
        updated_at: updated_at,
        updated_by: updated_by
      })
      PaperTrail.whodunnit = nil

      if json[:featureId]
        feature = Feature.find_by_mongo_id(json[:featureId].to_s)
        puts "Associating Feature: #{feature.id}" if feature
        feature.ideas << idea if feature
      elsif json[:componentId]
        component = Component.find_by_mongo_id(json[:componentId].to_s)
        puts "Associating Component: #{component.id}" if component
        component.ideas << idea if component
      end
    end
  end

  def process_metrics(benefit_json, benefit)
    puts "Processing Metrics for Benefit: #{benefit_json}"

    metrics_json = benefit_json[:metrics] || []
    metrics_json.each do |metric_json|
      puts "Processing Metric: #{metric_json}"
      #create Metric
      split_categories = metric_json[:type].split('.')

      #Lookup existing Metric by name or create a new one
      metric = Metric.where(name: Import::Utils.get_metric_name(*split_categories)).
        first_or_create({
          metric_category: get_metric_category(split_categories.first),
          directionality: Import::Utils.get_directionality(split_categories[0], split_categories[1])
        })

      #shovel onto HABTM association
      benefit.metrics << metric
    end
  end

  def process_users
    @users = client[:users].find().reject {|json| !json[:email]}.map do |json|
      puts "Processing User: #{json}"

      names = json[:fullName].split
      created_at = json[:_id].generation_time
      User.create({
        mongo_id: json[:_id],
        username: json[:userId],
        email: json[:email],
        first_name: names.take(names.length - 1).join(' '),
        last_name: names.last,
        last_sign_in_at: created_at,
        created_at: created_at,
        updated_at: created_at
      })
    end
  end

  def find_user_id_by_username(username)
    user = @users.detect {|u| u.username.downcase == username.downcase} if username
    user.id if user
  end

  def process_portfolios
    # PORTFOLIOS
    @portfolios = client[:portfolios].find.sort(position: 1).map do |json|
      puts "Processing Portfolio: #{json}"

      created_at = json[:_id].generation_time
      Portfolio.create({
        mongo_id: json[:_id],
        name: json[:fullName].strip,
        created_at: created_at,
        updated_at: created_at
      })
    end

    def process_spends(product_json, product)
      dollars = product_json[:dollars] || []
      spends = dollars.map do |json|
        puts "Processing Spend for Product(#{product.id}): #{product_json}"
        product.spends.create({
          year: json[:year],
          kind: json[:type],
          capital: json[:capital].to_i,
          expense: json[:expense].to_i,
        })
      end

      # Seed 2016 spend from the last 3 years, if possible
      spend_2016 = spends.detect{|s| s.year == 2016}
      spend_2015 = spends.detect{|s| s.year == 2015}
      spend_2014 = spends.detect{|s| s.year == 2014}
      spend_2013 = spends.detect{|s| s.year == 2013}
      if !spend_2016 && spend_2015 && spend_2014 && spend_2013
        product.spends.create({
          year: 2016,
          kind: 'plan',
          capital: (spend_2015.capital + spend_2014.capital + spend_2013.capital) / 3,
          expense: (spend_2015.expense + spend_2014.expense + spend_2013.expense) / 3
        })
      end
    end

    def process_team_members(product_json, product)
      puts "Processing Team Members for Product(#{product.id}): #{product_json}"
      people = product_json[:people] || []
      people.each do |people_json|
        (people_json[:names] || []).each do |name|
          puts "Processing Team Member #{name} with role #{people_json[:role]}"
          product.team_members.create({
            role: people_json[:role],
            name: name,
          })
        end
      end
    end
  end

  private

  def client
    @client ||= Mongo::Client.new('mongodb://cpwidirr.amer.homedepot.com:27017/horizon3')
  end

  def get_metric_category(category_name)
    MetricCategory.where(name: Import::Utils.get_category_name(category_name)).first_or_create(icon: Import::Utils.get_icon(category_name))
  end

end
