class Import::Utils

  # sales.voc,55
  # cost.operations,32
  # sales.conversion,28
  # cost.labor,28
  # cost,22
  # margin,19
  # sales,18
  # sales.instock,18
  # sales.comp,16
  # cost.labor.hours,15
  # margin.markdowns,10
  # margin.shrink,10
  # turns.onhand,7
  # sales.sales-sf,7
  # turns,6
  # margin.cogs,5
  # cost.gna,5
  # sales.comp.transaction,3
  # sales.new-category,2
  # sales.comp.ticket,2
  # sales.returns,1
  # sales.online-penetration,1

  HORIZON_CATEGORIES =
  {
    "sales": {
      "delta": "+",
      "icon": "fa-line-chart",
      "description": "Sales",
      "comp": {
        "description": "Comparable Store Sales",
        "transaction": {
          "description": "Transaction Comp"
        },
        "ticket": {
          "description": "Average Ticket Comp"
        }
      },
      "online-penetration": {
        "description": "Online Sales Penetration"
      },
      "conversion": {
        "description": "Conversion Rate"
      },
      "sales-sf": {
        "description": "Sales / Square Foot"
      },
      "new-category": {
        "description": "% Sales from new categories/new SKUs"
      },
      "instock": {
        "description": "In Stock"
      },
      "voc": {
        "description": "Customer VOC Metrics"
      },
      "returns": {
        "delta": "-",
        "description": "Return Rate"
      }
    },
    "margin": {
      "delta": "+",
      "icon": 'fa-tag',
      "description": "Gross Margin",
      "cogs": {
        "delta": "-",
        "description": "Cost of Goods Sold"
      },
      "markdowns": {
        "delta": "-",
        "description": "Markdowns"
      },
      "shrink": {
        "delta": "-",
        "description": "Shrink"
      }
    },
    "cost": {
      "delta": "-",
      "icon": 'fa-dollar',
      "description": "Costs",
      "labor": {
        "description": "Labor % of Sales",
        "hours": {
          "description": "Sales per Labor Hour"
        },
        "overtime": {
          "description": "Overtime"
        }
      },
      "operations": {
        "description": "Operating expenses (% of sales)"
      },
      "gna": {
        "description": "G&A expenses (% of sales)"
      }
    },
    "turns": {
      "delta": "+",
      "icon": 'fa-cubes',
      "description": "Inventory Turns",
      "onhand": {
        "delta": "-",
        "description": "Average Inventory On Hand"
      },
      "cogs": {
        "description": "COGS/Sell-through"
      }
    }
  }.with_indifferent_access.freeze

  def self.parse_time(date_string)
    DateTime.strptime(date_string, '%Y-%m-%d %H.%M.%S')
  end

  def self.get_category_name(horizon_category)
    category = HORIZON_CATEGORIES[horizon_category]
    category.present? ? category["description"] : ""
  end

  def self.get_metric_name(horizon_category, horizon_metric = nil, horizon_submetric = nil)
    return get_category_name(horizon_category) if horizon_metric.nil? && horizon_submetric.nil?

    category = HORIZON_CATEGORIES[horizon_category]

    metric_description = if category[horizon_metric]
      category[horizon_metric]["description"]
    end

    submetric_description = if category[horizon_metric] && category[horizon_metric][horizon_submetric]
      category[horizon_metric][horizon_submetric]["description"]
    end

    [metric_description, submetric_description].compact.join(" - ")
  end

  def self.get_directionality(horizon_category, horizon_metric = nil)
    category = HORIZON_CATEGORIES[horizon_category]

    if horizon_metric && category[horizon_metric] && category[horizon_metric]["delta"]
      category[horizon_metric]["delta"] == "+" ? "up" : "down"
    else
      category["delta"] == "+" ? "up" : "down"
    end
  end

  def self.get_icon(horizon_category)
    HORIZON_CATEGORIES[horizon_category]["icon"]
  end
end
