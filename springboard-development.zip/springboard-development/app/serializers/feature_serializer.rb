class FeatureSerializer < ActiveModel::Serializer
  attributes :id, :component_id, :position, :name, :description, :created_by, :updated_by, :created_at, :updated_at

  has_many :benefits
end
