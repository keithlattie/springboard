class TeamMemberSerializer < ActiveModel::Serializer
  attributes :id, :role, :name, :created_at, :updated_at
end
