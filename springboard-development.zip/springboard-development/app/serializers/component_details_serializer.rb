class ComponentDetailsSerializer < ComponentSerializer
  has_many :features
end
