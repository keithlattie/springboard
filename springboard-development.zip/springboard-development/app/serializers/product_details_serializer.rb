class ProductDetailsSerializer < ProductSerializer

  has_many :components, serializer: ComponentDetailsSerializer

  has_many :spends

  has_many :team_members

  def components
    object.components.includes([{benefits: :metrics}, {features: {benefits: :metrics}}])
  end

end
