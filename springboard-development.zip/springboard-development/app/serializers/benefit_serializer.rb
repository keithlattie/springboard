class BenefitSerializer < ActiveModel::Serializer
  attributes :id, :name, :beneficial_id, :metric_ids, :beneficial_type, :created_at, :updated_at, :created_by, :updated_by
end
