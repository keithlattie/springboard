class FavoriteSerializer < ActiveModel::Serializer
  attributes :id, :user_id, :favorable_id, :favorable_type, :name, :image_url
end
