class IdeaSerializer < ActiveModel::Serializer
  attributes :id, :product_id, :originator_id, :owner_id, :title, :description, :business_value, :product_health, :investment_points, :priority, :position, :spend_id, :status, :created_by, :updated_by

  has_many :goals
  has_many :pinnables
end
