class SessionSerializer < ActiveModel::Serializer
  attributes :id, :username, :email, :first_name, :last_name, :last_sign_in_at, :created_at, :updated_at, :groups

  has_many :favorites

  def groups
    object.home_depot_user_groups
  end

end
