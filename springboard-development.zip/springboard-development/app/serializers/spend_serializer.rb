class SpendSerializer < ActiveModel::Serializer
  include ActionView::Helpers::NumberHelper

  attributes :id, :year, :kind, :capital, :expense, :created_by, :updated_by

end
