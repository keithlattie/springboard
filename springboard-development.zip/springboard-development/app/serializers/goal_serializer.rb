class GoalSerializer < ActiveModel::Serializer
  attributes :id, :idea_id, :metric_id, :amount, :amount_type, :duration, :duration_type, :created_by, :created_at, :updated_at
end
