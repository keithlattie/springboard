class UserSerializer < ActiveModel::Serializer
  attributes :id, :username, :email, :first_name,
          :last_name, :last_sign_in_at, :created_at, :updated_at
end
