class PortfolioSerializer < ActiveModel::Serializer
  attributes :id, :position, :name, :created_by, :updated_by, :created_at, :updated_at
end
