class ProductSerializer < ActiveModel::Serializer
  attributes :id, :portfolio_id, :name, :description, :image_url, :created_by, :updated_by, :created_at, :updated_at,
    :components_count, :features_count

  has_many :team_members
end
