class MetricSerializer < ActiveModel::Serializer
  attributes :id, :name, :directionality, :metric_category_id
end