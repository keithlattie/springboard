class VersionSerializer < ActiveModel::Serializer
  attributes :id, :event, :whodunnit, :changeset, :created_at

  def whodunnit
    object.whodunnit.to_i if object.whodunnit
  end
end
