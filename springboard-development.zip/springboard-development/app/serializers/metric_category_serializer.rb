class MetricCategorySerializer < ActiveModel::Serializer
  attributes :id, :name, :icon

  has_many :metrics
end
