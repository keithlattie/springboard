class ComponentSerializer < ActiveModel::Serializer
  attributes :id, :product_id, :position, :name, :description, :created_by, :updated_by, :created_at, :updated_at

  has_many :benefits
  has_many :features
end
