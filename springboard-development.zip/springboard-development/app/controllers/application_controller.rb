class ApplicationController < ActionController::Base
  # Prevent CSRF attacks by raising an exception.
  # For APIs, you may want to use :null_session instead.
  protect_from_forgery with: :exception

  before_action :refresh_thd_groups
  before_filter :set_paper_trail_whodunnit

  after_action :set_csrf_cookie_for_ng

  def set_csrf_cookie_for_ng
    cookies['XSRF-TOKEN'] = form_authenticity_token if protect_against_forgery?
  end

  def authenticate_editor!
    is_a_role?("editor")
  end

  def authenticate_admin!
    is_a_role?("admin")
  end

  def refresh_thd_groups
    current_user.refresh_thd_groups if user_signed_in?
  end

  protected

    # In Rails 4.2 and above
    def verified_request?
      super || valid_authenticity_token?(session, request.headers['X-XSRF-TOKEN'])
    end

  private

  def is_a_role?(role)
    unless current_user.home_depot_user_groups.include? Rails.configuration.thd_groups[role]
      render nothing: true, status: :forbidden
    end
  end
end
