class Products::ExportController < ApplicationController

  #Non-RESTful CSV exports, could be extended to support other output formats

  def metric_type
    send_data Products::Export::MetricType.to_csv,
              filename: "springboard-product-metric-types-#{Date.today}.csv",
              type: Mime::CSV
  end

  def feature_counts_by_metric_type
    send_data Products::Export::FeatureCountsByMetricType.to_csv,
              filename: "springboard-product-feature-counts-by-metric-type-#{Date.today}.csv",
              type: Mime::CSV
  end

  def feature_counts_by_metric
    send_data Products::Export::FeatureCountsByMetric.to_csv,
              filename: "springboard-product-feature-counts-by-metric-#{Date.today}.csv",
              type: Mime::CSV
  end

  def springboard_data_inventory
    send_data Products::Export::DataInventory.to_csv,
              filename: "springboard-data-inventory-#{Date.today}.csv",
              type: Mime::CSV
  end
end