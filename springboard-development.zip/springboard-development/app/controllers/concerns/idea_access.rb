module IdeaAccess
  extend ActiveSupport::Concern

  def authenticate_idea_editor!
    editor = current_user.home_depot_user_groups.include?(Rails.configuration.thd_groups["editor"])
    originator = @idea.created_by == current_user.id
    render nothing: true, status: :forbidden unless editor || originator
  end
end
