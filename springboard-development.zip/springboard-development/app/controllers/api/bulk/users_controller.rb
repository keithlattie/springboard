class Api::Bulk::UsersController < ApplicationController
  def show
    @users = User.where(id: user_ids)
    render json: @users
  end

  private

    def user_ids
      params[:id].split(',')
    end
end
