class Api::VersionsController < ApplicationController
  before_action :load_versionable

  def index
    @versions = @versionable.versions
    render json: @versions, each_serializer: VersionSerializer
  end

  private

    def load_versionable
      params.each do |name, value|
        if name =~ /(.+)_id$/
          @versionable = $1.classify.constantize.find(value)
        end
      end
    end
end
