class Api::SpendsController < ApplicationController

  before_action :authenticate_user!
  before_action :authenticate_editor!
  before_action :load_product, only: :create
  before_action :load_spend, only: [:update, :destroy]

  def create
    params = permitted_params.merge(created_by: current_user.id, updated_by: current_user.id)
    @spend = @product.spends.new(params)
    if @spend.save
      render json: @spend, status: :created
    else
      render json: @spend.errors, status: :unprocessable_entity
    end
  end

  def update
    params = permitted_params.merge(updated_by: current_user.id)
    if @spend.update(params)
      render json: @spend, status: :created
    else
      render json: @spend.errors, status: :unprocessable_entity
    end
  end

  def destroy
    @spend.destroy
    render nothing: true, status: :no_content
  end

  private

  def load_product
    @product = Product.find(params[:product_id])
  end

  def load_spend
    @spend = Spend.find(params[:spend_id] || params[:id])
  end


  def permitted_params
    params.permit(:component_id, :year, :kind, :capital, :expense)
  end
end
