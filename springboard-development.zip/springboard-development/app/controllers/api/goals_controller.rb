class Api::GoalsController < ApplicationController
  include IdeaAccess
  before_action :load_idea, only: [:create]
  before_action :load_goal, only: [:destroy]
  before_action :authenticate_user!
  before_action :authenticate_idea_editor!

  def create
    params = goal_params.merge(created_by: current_user.id)
    @goal = @idea.goals.new(params)
    if @goal.save
      render json: @goal, status: :created
    else
      render json: @goal.errors, status: :unprocessable_entity
    end
  end

  def destroy
    @goal.destroy
    render nothing: true, status: :no_content
  end

  private

  def load_idea
    @idea = Idea.find(params[:idea_id])
  end

  def load_goal
    @goal = Goal.find(params[:id])
    @idea = @goal.idea
  end

  def goal_params
    params.permit(:metric_id, :amount, :amount_type, :duration, :duration_type)
  end

end
