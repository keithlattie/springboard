class Api::ComponentsController < ApplicationController
  before_action :authenticate_user!, except: [:index, :show]
  before_action :authenticate_editor!, except: [:index, :show]
  before_action :load_product, only: [:create]
  before_action :load_component, only: [:show, :update, :destroy]

  def index
    @components = Component.all
    @components = @components.where(product_id: params[:product]) if params[:product]
    render json: @components
  end

  def create
    params = component_params.merge(created_by: current_user.id, updated_by: current_user.id)
    @component = @product.components.new(params)
    if @component.save
      render json: @component, serializer: ComponentDetailsSerializer, status: :created
    else
      render json: @component.errors, status: :unprocessable_entity
    end
  end

  def show
    render json: @component, serializer: ComponentDetailsSerializer, status: :ok
  end

  def update
    params = component_params.merge(updated_by: current_user.id)
    if @component.update(params)
      render json: @component, status: :created
    else
      render json: @component.errors, status: :unprocessable_entity
    end
  end

  def destroy
    @component.destroy
    render nothing: true, status: :no_content
  end

  private

  def load_product
    @product = Product.find(params[:product_id])
  end

  def load_component
    @component = Component.find(params[:id])
  end

  def component_params
    params.permit(:product_id, :position, :name, :description)
  end
end
