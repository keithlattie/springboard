class Api::IdeasController < ApplicationController
  include IdeaAccess
  before_action :load_product, only: [:create]
  before_action :load_idea, only: [:show, :update, :destroy]
  before_action :authenticate_user!, except: [:index, :show]
  before_action :authenticate_idea_editor!, only: [:update, :destroy]

  def index
    @ideas = Idea.all
    @ideas = @ideas.where(product_id: params[:product]) if params[:product]
    @ideas = @ideas.includes(:goals, :pinnables)
    render json: @ideas
  end

  def create
    params = idea_params.merge(created_by: current_user.id, updated_by: current_user.id)
    @idea = @product.ideas.new(params)
    if @idea.save
      render json: @idea, status: :created
    else
      render json: @idea.errors, status: :unprocessable_entity
    end
  end

  def show
    render json: @idea, status: :ok
  end

  def update
    params = idea_params.merge(updated_by: current_user.id)
    if @idea.update(params)
      render json: @idea, status: :created
    else
      render json: @idea.errors, status: :unprocessable_entity
    end
  end

  def destroy
    @idea.destroy
    render nothing: true, status: :no_content
  end

  private

    def load_product
      @product = Product.find(params[:product_id])
    end

    def load_idea
      @idea = Idea.find(params[:id])
    end

    def idea_params
      params.permit(:title, :description, :originator_id, :owner_id, :business_value, :product_health, :investment_points, :priority, :position, :spend_id, :status)
    end

end
