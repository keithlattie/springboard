class Api::FeaturesController < ApplicationController
  before_action :authenticate_user!, except: [:index, :show]
  before_action :authenticate_editor!, except: [:index, :show]
  before_action :load_component, only: [:create]
  before_action :load_feature, only: [:show, :update, :destroy]

  def index
    @features = Feature.all
    @features = @features.where(component_id: params[:component]) if params[:component]
    @features = @features.where_product_id(params[:product]) if params[:product]
    render json: @features
  end

  def create
    params = feature_params.merge(created_by: current_user.id, updated_by: current_user.id)
    @feature = @component.features.new(params)
    if @feature.save
      render json: @feature, status: :created
    else
      render json: @feature.errors, status: :unprocessable_entity
    end
  end

  def show
    render json: @feature, status: :ok
  end

  def update
    params = feature_params.merge(updated_by: current_user.id)
    if @feature.update(params)
      render json: @feature, status: :created
    else
      render json: @feature.errors, status: :unprocessable_entity
    end
  end

  def destroy
    @feature.destroy
    render nothing: true, status: :no_content
  end

  private

  def load_component
    @component = Component.find(params[:component_id])
  end

  def load_feature
    @feature = Feature.find(params[:id])
  end

  def feature_params
    params.permit(:component_id, :position, :name, :description)
  end
end
