class Api::BenefitsController < ApplicationController
  before_action :authenticate_user!, except: [:index, :show]
  before_action :authenticate_editor!, except: [:index, :show]
  before_action :load_feature, only: [:create]
  before_action :load_benefit, only: [:update, :destroy]

  def create
    @resource = @feature.benefits.new(permitted_params.merge(created_by: current_user.id, updated_by: current_user.id))
    if @resource.save
      render json: @resource, status: :created
    else
      render json: @resource.errors, status: :unprocessable_entity
    end
  end

  def update
    if @benefit.update_attributes(permitted_params.merge(updated_by: current_user.id))
      render json: @benefit, status: :created
    else
      render json: @benefit.errors, status: :unprocessable_entity
    end
  end

  def destroy
    @benefit.destroy
    render nothing: true, status: :no_content
  end

  private

  def load_feature
    @feature = Feature.find(params[:feature_id])
  end

  def load_benefit
    @benefit = Benefit.find(params[:id])
  end

  def permitted_params
    params.permit(:name)
  end
end
