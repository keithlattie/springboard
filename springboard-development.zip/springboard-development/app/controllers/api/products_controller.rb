class Api::ProductsController < ApplicationController
  before_action :authenticate_user!, except: [:index, :show]
  before_action :authenticate_editor!, except: [:index, :show]
  before_action :authenticate_admin!, only: [:create, :destroy]
  before_action :load_product, only: [:show, :update, :destroy]

  def index
    @products = Product.includes(:team_members).distinct
    render json: @products
  end

  def create
    params = product_params.merge(created_by: current_user.id, updated_by: current_user.id)
    @product = Product.new(params)
    if @product.save
      render json: @product, serializer: ProductDetailsSerializer, status: :created
    else
      render json: @product.errors, status: :unprocessable_entity
    end
  end

  def show
    render json: @product, serializer: ProductDetailsSerializer, status: :ok
  end

  def update
    params = product_params.merge(updated_by: current_user.id)
    if @product.update(params)
      render json: @product, status: :created
    else
      render json: @product.errors, status: :unprocessable_entity
    end
  end

  def destroy
    @product.destroy
    render nothing: true, status: :no_content
  end

  private

    def load_product
      @product = Product.find(params[:id])
    end

    def product_params
      params.permit(:portfolio_id, :name, :description)
    end

end
