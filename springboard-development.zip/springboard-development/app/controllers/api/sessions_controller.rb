#Class that allows Devise's controller to respond to JSON requests
module Api
  class SessionsController < Devise::SessionsController
    #no need to refresh before logging in
    skip_before_action :refresh_thd_groups

    respond_to :json
  end
end