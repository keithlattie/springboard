class Api::MetricCategoriesController < ApplicationController
  def index
    render json: MetricCategory.includes(:metrics)
  end
end
