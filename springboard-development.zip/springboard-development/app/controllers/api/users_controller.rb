class Api::UsersController < ApplicationController
  before_action :authenticate_user!
  before_action :authenticate_admin!
  before_action :load_user, only: [:show, :update, :destroy]

  def index
    @users = User.all
    render json: @users
  end

  def show
    render json: @user
  end

  def update
    if @user.update(user_params)
      render json: @user, status: :created
    else
      render json: @user.errors, status: :unprocessable_entity
    end
  end

  def destroy
    @user.destroy
    render nothing: true, status: :no_content
  end

  private

    def user_params
      params.permit(:first_name, :last_name)
    end

    def load_user
      @user = User.where(id: (params[:user_id] || params[:id])).first
    end
end
