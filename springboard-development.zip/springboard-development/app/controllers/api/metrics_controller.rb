class Api::MetricsController < ApplicationController
  before_action :authenticate_user!, except: [:index, :show]
  before_action :authenticate_editor!, except: [:index, :show]
  before_action :load_metric, only: [:create, :destroy]
  before_action :load_benefit, only: [:create, :destroy]

  #associates a metric with a benefit.  this controller *could* be renamed because we aren't creating Metrics, we're creating join table records.
  def create
    if @benefit && @metric
      @benefit.metrics << @metric
      return render nothing: true, status: :created
    end
    render nothing: true, status: :unprocessable_entity
  end

  def destroy
    if @benefit && @metric
      @benefit.metrics.destroy(@metric)
      return render nothing: true, status: :no_content
    end
    render nothing: true, status: :unprocessable_entity
  end

  private

  def load_metric
    @metric = Metric.find(params[:id] || params[:metric_id])
  end

  def load_benefit
    @benefit = Benefit.find(params[:benefit_id])
  end
end
