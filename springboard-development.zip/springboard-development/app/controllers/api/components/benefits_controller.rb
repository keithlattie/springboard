class Api::Components::BenefitsController < ApplicationController

  before_action :authenticate_user!
  before_action :authenticate_editor!
  before_action :load_component

  def create
    @resource = @component.benefits.new(permitted_params.merge(created_by: current_user.id, updated_by: current_user.id))
    if @resource.save
      render json: @resource, status: :created
    else
      render json: @resource.errors, status: :unprocessable_entity
    end
  end

  private

  def load_component
    @component = Component.find(params[:component_id])
  end

  def permitted_params
    params.permit(:name)
  end
end
