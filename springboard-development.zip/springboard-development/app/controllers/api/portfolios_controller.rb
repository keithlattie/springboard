class Api::PortfoliosController < ApplicationController
  before_action :authenticate_user!, except: [:index, :show]
  before_action :authenticate_editor!, except: [:index, :show]
  before_action :load_portfolio, only: [:show, :update, :destroy]

  def index
    @portfolios = Portfolio.all
    render json: @portfolios
  end

  def create
    params = portfolio_params.merge(created_by: current_user.id, updated_by: current_user.id)
    @portfolio = Portfolio.new(params)
    if @portfolio.save
      render json: @portfolio, status: :created
    else
      render json: @portfolio.errors, status: :unprocessable_entity
    end
  end

  def show
    render json: @portfolio, status: :ok
  end

  def update
    params = portfolio_params.merge(updated_by: current_user.id)
    if @portfolio.update(params)
      render json: @portfolio, status: :created
    else
      render json: @portfolio.errors, status: :unprocessable_entity
    end
  end

  def destroy
    @portfolio.destroy
    render nothing: true, status: :no_content
  end

  private

    def load_portfolio
      @portfolio = Portfolio.find(params[:id])
    end

    def portfolio_params
      params.permit(:position, :name)
    end
end
