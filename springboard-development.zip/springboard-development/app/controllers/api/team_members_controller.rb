module Api
  class TeamMembersController < BaseController

    before_action :authenticate_editor!
    before_action :load_product, only: :create
    before_action :load_team_member, only: [:update, :destroy]

    def create
      params = permitted_params.merge(created_by: current_user.id, updated_by: current_user.id)
      @team_member = @product.team_members.new(params)
      if @team_member.save
        render json: @team_member, status: :created
      else
        render json: @team_member.errors, status: :unprocessable_entity
      end
    end

    def update
      params = permitted_params.merge(updated_by: current_user.id)
      if @team_member.update(params)
        render json: @team_member, status: :created
      else
        render json: @team_member.errors, status: :unprocessable_entity
      end
    end

    def destroy
      @team_member.destroy
      render nothing: true, status: :no_content
    end

    private

    def load_product
      @product = Product.find(params[:product_id])
    end

    def load_team_member
      @team_member = TeamMember.find(params[:team_member_id] || params[:id])
    end


    def permitted_params
      params.permit(:project_id, :name, :role)
    end
  end
end
