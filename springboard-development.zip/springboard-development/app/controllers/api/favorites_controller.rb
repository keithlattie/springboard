module Api
  class FavoritesController < BaseController

    def index
      render json: current_user.favorites
    end

    def create
      @favorite = current_user.favorites.build(favorable_attributes)
      if @favorite.save
        render json: @favorite, status: :created
      else
        render json: @favorite.errors, status: :unprocessable_entity
      end
    end

    def destroy
      if @favorite = current_user.favorites.where(id: params[:id]).first
        @favorite.destroy
        render nothing: true, status: :no_content
      else
        render nothing: true, status: :not_found
      end
    end

    private

    def favorable_attributes
      params.require(:favorite).permit(:favorable_type, :favorable_id)
    end
  end
end