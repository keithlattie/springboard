class MysqlConnectionsController < ApplicationController
  skip_before_action :verify_authenticity_token, only: :destroy

  def show
    @connections = get_connections_to_be_killed
  end

  def destroy
    @connections = get_connections_to_be_killed

    @connections.each do |row|
      active_record_connection.execute("kill #{row['ID']};")
    end
    redirect_to(action: :show)
  end

  private

  def active_record_connection
    ActiveRecord::Base.connection_pool.connection
  end

  def get_connections_to_be_killed
    active_record_connection.exec_query(
      <<-SQL
        SELECT ID, COMMAND, TIME
        FROM INFORMATION_SCHEMA.PROCESSLIST
        WHERE COMMAND = 'Sleep'
        AND TIME > 300;
    SQL
    )
  end
end