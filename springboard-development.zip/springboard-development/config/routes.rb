Rails.application.routes.draw do

  devise_for :users, controllers: { sessions: 'api/sessions' }

  # Application
  root to: 'home#index'

  # Authentication
  resource :session, only: :show, controller: 'session' #default controller is pluralized `sessions`, might rename the controller and fix specs later

  resource :mysql_connections, only: [:show, :destroy]

  namespace :products do
    namespace :export, constraints: { format: 'csv' } do
      get :metric_type
      get :feature_counts_by_metric_type
      get :feature_counts_by_metric
      get :springboard_data_inventory
    end
  end

  namespace :api, constraints: { format: 'json' } do

    concern :versionable do
      resources :versions, only: [:index]
    end

    resources :benefits, only: [:update, :destroy] do
      resources :metrics, only: [:create, :destroy]
    end

    namespace :bulk do
      resources :users, only: [:show]
    end

    resources :components, only: [:index, :show, :update, :destroy] do
      resources :benefits, only: [:create], controller: 'components/benefits'
      resources :features, only: [:create]
    end

    resources :favorites, only: [:index, :create, :destroy]

    resources :features, only: [:index, :show, :update, :destroy] do
      resources :benefits, only: [:create]
    end

    resources :goals, only: [:destroy]

    resources :metric_categories, only: :index

    resources :portfolios, only: [:index, :create, :show, :update, :destroy]

    resources :products, only: [:index, :create, :show, :update, :destroy] do
      resources :components, only: [:create]
      resources :ideas, only: [:create]
      resources :spends, only: [:create]
      resources :team_members, only: [:create]
    end

    resources :ideas, only: [:index, :show, :update, :destroy], concerns: :versionable do
      resources :goals, only: [:create]
    end

    resources :spends, only: [:update, :destroy]

    resources :team_members, only: [:update, :destroy]

    resources :users, only: [:index, :show, :update, :destroy]

  end
end
