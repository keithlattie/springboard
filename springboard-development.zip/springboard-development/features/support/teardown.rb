#After each scenario, log out and clear any lingering Sessions.
After do |scenario|
  within('nav.primary') do
    click_on "Sign Out", visible: false
  end if page.has_content?('Sign Out')
end