#Prevents the test suite from leaking external requests.
WebMock.disable_net_connect!(:allow_localhost => true)