#configured THD authentication memory store in Rails' Configuration

#Initialize as an empty array, User Factory will add profiles to this as users are created.
Rails.configuration.thd_users = []