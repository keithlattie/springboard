Given(/^I have a product named "([^"]*)" with a Product Owner named "([^"]*)"$/) do |arg1, arg2|
  @product = FactoryGirl.create(:product, name: arg1)
  @product_owner = FactoryGirl.create(:team_member, role: 'Product Owner', name: arg2, product: @product)
end

When(/^I do a product search for "([^"]*)"$/) do |arg1|
  visit '/'
  within('nav.secondary') { fill_in 'products_filter', with: arg1 }
end

Then(/^I should see "([^"]*)" on the products page$/) do |arg1|
  within('article.dashboard') do
    expect(page).to have_content(arg1)
  end
end

Then(/^I should not see "([^"]*)" on the products page$/) do |arg1|
  within('article.dashboard') do
    expect(page).to_not have_content(arg1)
  end
end
