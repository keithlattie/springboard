Given(/^I have a product$/) do
  @product = FactoryGirl.create :product
end

Given(/^I am a Springboard Admin$/) do
  @user = FactoryGirl.create :admin
end

Given(/^I am a Springboard Viewer$/) do
   @user = FactoryGirl.create :user
end

Given(/^I am a Springboard Editor$/) do
  @user = FactoryGirl.create :editor
end

When(/^I sign in$/) do
  visit root_path
  within('nav.primary') {
    click_on "Sign In"
  }
  within('div[window-class=sign-in]') {
    fill_in "username", with: @user&.username || 'username'
    fill_in "password", with: @user&.username || 'wrong'
    click_on "Sign In"
  }
end

Then(/^I should see my name$/) do
  within('nav.primary') do
    expect(page).to have_content(@user.first_name)
  end
end

Then(/^I should be able to access the Admin portal$/) do
  # visit '#/admin'
  # within('nav.secondary') { expect(page).to have_content('Administration') }
  within('nav.primary') do
    expect(page).to have_link('Admin', visible: false)
  end
end

Given(/^I should not be able to access the Admin portal$/) do
  # visit '#/admin'
  # within('nav.secondary') { expect(page).to_not have_content('Administration') }
  within('nav.primary') do
    expect(page).to_not have_link('Admin', visible: false)
  end
end

Then(/^I should see that I can not log in$/) do
  within('div[window-class=sign-in]') do
    expect(page).to have_content('Sign In to Springboard')
  end
end

Given(/^I should not be able to change a product description$/) do
  within('nav.primary') { click_on 'Product Index' }
  within('article.dashboard') { click_on @product.name }
  expect(page).to_not have_css('textarea.product-description')
end

Then(/^I should be able to change a product description$/) do
  within('nav.primary') { click_on 'Product Index' }
  within('article.dashboard') { click_on @product.name }
  expect(page).to have_css('textarea.product-description')
end

