require Rails.root.join('lib/devise/strategies/home_depot_authenticatable')

module Devise
  module Models
    module HomeDepotAuthenticatable
      extend ActiveSupport::Concern

      included do
        attr_accessor :sso_token
        attr_accessor :home_depot_user_groups
      end

      module ClassMethods

        def find_or_create_with_authentication_profile(profile, sso_token)
          resource = self.where(username: profile.user_id).
            first_or_create({
              email: profile.e_mail_address,
              first_name: profile.first_name,
              last_name: profile.last_name,
            })
          resource.sso_token = sso_token
          resource.home_depot_user_groups = profile.user_groups
          resource
        end

        ####################################
        # Overriden methods from Devise::Models::Authenticatable
        ####################################

        #
        # This method is called from:
        # Warden::SessionSerializer in devise
        #
        # It takes as many params as elements had the array
        # returned in serialize_into_session
        #
        # Recreates a resource from session data
        #
        def serialize_from_session(id, sso_token)
          resource = find(id)
          resource.sso_token = sso_token
          resource
        end

        #
        # Here you have to return and array with the data of your resource
        # that you want to serialize into the session
        #
        # Storing the primary key for the User record allows for easy retrieval
        #
        def serialize_into_session(record)
          [record.id, record.sso_token]
        end
      end
    end
  end
end