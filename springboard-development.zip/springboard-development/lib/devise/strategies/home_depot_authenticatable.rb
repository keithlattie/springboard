require 'devise/strategies/authenticatable'

module Devise
  module Strategies
    class HomeDepotAuthenticatable < Authenticatable

      def authenticate!
        if password.present? && valid_home_depot_user?
          #we have an sso token, we can now create their User record in Springboard and sign them in.
          resource = mapping.to.find_or_create_with_authentication_profile(get_authentication_profile, env[:sso_token])
          success!(resource)
        else
          fail(:unable_to_authenticate)
        end
      end

      ## returns true or false if the given user is found on MyPassport
      def valid_home_depot_user?
        login_and_set_sso_token.present?
      end

      def login_and_set_sso_token
        env[:sso_token] ||= login
      end

      def login
        thd_login_service.login(username, password, Rails.configuration.thd_passport["store_number"])
      end

      # # Create a real LDAP service
      def thd_ldap_login_service
        HomeDepotAuthentication.login_service(config["base_url"], config["calling_program"])
      end

      # Create an in-memory LDAP service
      def thd_memory_login_service
        HomeDepotAuthentication.in_memory_login_service(Rails.configuration.thd_users.map(&:symbolize_keys))
      end

      # # Create an instance of the THD MyPassport login service
      def thd_login_service
        @login_service ||= Rails.env.production? ? thd_ldap_login_service : thd_memory_login_service
      end

      def get_authentication_profile
        thd_login_service.get_user_profile(env[:sso_token]) if env[:sso_token]
      end

      private

      def username
        authentication_hash[:username]
      end

      def config
        @config ||= Rails.configuration.thd_passport
      end

    end
  end
end

Warden::Strategies.add(:home_depot_authenticatable, Devise::Strategies::HomeDepotAuthenticatable)
