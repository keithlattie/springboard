# Springboard

Welcome to the Home Depot Springboard product README!

Source Code can be found at:
  https://github.homedepot.com/Back-Office-And-In-Aisle-Systems/springboard

## Setup

### Install editor

https://atom.io/

### Install homebrew

http://brew.sh/

### Install latest git/gitk

    brew install git
    brew cask install tcl

### Configure git

Update your name and email to match your accounts at Home Depot. See: https://git-scm.com/book/en/v2/Customizing-Git-Git-Configuration

    git config --global user.name "John Doe"
    git config --global user.email JOHN_DOE@homedepot.com

### Install database

    cp config/database.example.yml config/database.yml
    brew install mysql

NOTE: Make sure to start mysql and on startup.

MySQL Workbench: https://dev.mysql.com/doc/workbench/en/wb-installing.html

### Install rvm

https://rvm.io/rvm/install

    \curl -sSL <a href="https://get.rvm.io">https://get.rvm.io</a> | bash -s stable --ruby

### Install ruby

    rvm install 2.3
    gem install bundler
    bundle install

### Install nodejs

    brew install node
    npm install -g bower
    npm install -g karma

### Install packages

    bower install
    npm install

## Testing

### Server Unit Testing (rspec)

    rspec

### Client Unit Testing (karma)

    bundle exec rake karma:run

## Local Development

### Foreman / Procfile

    One can start all required development dependencies by using `foreman`.  Foreman emulates a containerized production environment, without all the overhead of having to set it up yourself.  Open up `Procfile.dev.example` to see how threads are defined.

    * Right now the app depends on having a running Postgresql database, which is run inside of a `postgres` thread.
    * The development server is run inside of a `web` thread.

    In order to start your development server (assuming you are using homebrew), simply run `foreman start -f Procfile.dev.example` or create your own environment specific Procfile!

## Environments

This app is hosted internally using Pivotal Cloud Foundry.

There are two Cloud Foundry Environments, [Production](https://apps.run.homedepot.com) and [Non-Production](https://apps.run-np.homedepot.com).

### Development Environment

The development server currently resides at [http://springboard-dev.apps-np.homedepot.com/#/dashboard](http://springboard-dev.apps-np.homedepot.com/#/dashboard).  You must be on The Home Depot's VPN in order to access the system.  Furthermore, you must login with your THD ID  in order to edit any of the products or data.

Push updates to this server using the supplied manifest.yml file: `cf push -f manifest.development.yml`

### Acceptance Environment

The Acceptance server currently resides at [http://springboard.apps-np.homedepot.com/#/dashboard](http://springboard.apps-np.homedepot.com/#/dashboard).  You must be on The Home Depot's VPN in order to access the system.  Furthermore, you must login with your THD ID  in order to edit any of the products or data.

Push updates to this server using the supplied manifest.yml file: `cf push -f manifest.acceptance.yml`

#### PCF And Dependencies

Pivotal Cloud Foundry will not easily allow you to use Bundler or Bower, and as such you must push all app code at once.

Before deploying, please run `bundle package --all`.  This will place all of the apps gems in `vendor/cache`, which will be uploaded to PCF when you run `cf push`.  Without the gems on your local file system, the build will fail.

Please don't commit these files to Git either.  They're ignored right now, but if they were committed they would just increase the size of the Git repo for no good reason.

Ensure all Javascript components have also been installed.

Essentially, if you can run the app locally - you should be in a position to push the app to Cloud Foundry.

#### Seeding the PCF MySQL DB

To seed a database, open a terminal and run the following commands:

    * `rake db:reset import:horizon`
    * `mysqldump -h localhost -u root springboard_development > tmp/springboard.dump`
    * `mysql -h 172.20.247.31 -u 8xTNq7vPh92i3H2Q -p cf_ae28af4f_bbbd_498b_bc20_a68df34bf4db < tmp/springboard.dump`
      * The values above came from `cf env springboard-dev | grep mysql` and parsing the mysql connection string.

NOTE: Its not possible to manage the database inside of Cloud Foundry at this time.  You must push databases from your local system up to Cloud Foundry (and vice versa).

#### Deploying to PCF the first time

The staging server resides on Pivotal Cloud Foundry's non production environment, http://springboard.apps-np.homedepot.com/#/dashboard.  Deployments to the Staging Server are accomplished using PCF's command line utility, `cf push`.

You will need to register your THD account with Cloud Foundry first.  Please go to https://apps.run-np.homedepot.com/ and sign in once.  This will create a profile that a PCF Admin can then assign to an organization.  Please ask Jermaine Brown to assign you to the Springboard organization.

After you have access to Cloud Foundry, you may run `cf push -f <your-manifest.yml>` to deploy new versions of the product!

### Production Environment

Deploying to the production environment is the same process as Acceptance and Development, but you will target a different PCF deployment.  Before you begin, do ensure you have an approved Change Order first!

Before you begin, your PCF account will need to be associated with the springboard organization and space.  Please ask Keith Lattie or reach out to the PCF Admins in Slack's #cloudfoundry channel for help.

#### Step 0: Getting access to PCF Zone B.

1. Log into [PCF Zone B](run-zb.homedepot.com) so it knows your THD ID
2. `cf set-org-role <THD_ID> springboard OrgManager`
3. `cf set-space-role <THD_ID> springboard springboard SpaceDeveloper`

The two commands above must be performed by an OrgManager or a PCF Admin.  As of writing this, Daniel Rice (dcr8292) and Sam Duvall (swd8301) are Org Managers.

#### Step 1: Log into PCF Zone B

`cf login -a api.run-zb.homedepot.com`

#### Step 2: Checkout `master` branch

`git checkout master`

Ensure `git` is clean by running `git status`.  There should be no uncommitted changes or staged files.

#### Step 3: Push to PCF

`cf push -f manifest.production.yml`

The app will deploy using PCF's Ruby Buildpack, just like it does on the Non Production system!

### Testing

This app uses Rspec and Cucumber.

Rspec provides testing for the Rails app itself, including unit testing, controller testing, and API request Specs.

Cucumber provides full-stack integration tests using Google Chrome, Selenium, and Capybara.

Rspec does not require any special configuration.  Just `bundle install`, `rake db:test:prepare` and then you should be able run `rspec spec`.

Running Cucumber tests requires installing the Google Chrome driver, first.  Running `which chromedriver` will tell you if you have it installed already.  If not, [Download it](http://chromedriver.storage.googleapis.com/index.html) and place it in your `$PATH` (for me, I placed it in `/usr/local/bin`).  If you use Homebrew, you may also install it using `brew install chromedriver`.  Once `chromedriver` is installed, feel free to run `cucumber`!
