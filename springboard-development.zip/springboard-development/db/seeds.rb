### Seeds.rb

# Seed your development database with Random data here

# If you are looking for the Horizon Import code, that code has been moved to a Rake Task, rake import:horizon and the models inside of app/models/import.
# Invoke that rake task instead of rake db:seed.

