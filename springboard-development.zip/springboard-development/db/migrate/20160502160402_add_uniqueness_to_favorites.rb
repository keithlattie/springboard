class AddUniquenessToFavorites < ActiveRecord::Migration
  def change
    add_index :favorites, [:user_id, :favorable_type, :favorable_id], unique: true
  end
end
