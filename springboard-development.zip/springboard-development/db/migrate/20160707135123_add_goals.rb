class AddGoals < ActiveRecord::Migration
  def change
    create_table :goals do |t|
      t.references :idea, null: false, foreign_key: true
      t.references :metric, null: false, foreign_key: true

      t.integer :amount_hundreths
      t.string :amount_type

      t.integer :duration
      t.string :duration_type

      t.integer :created_by, unsigned: true
      t.timestamps null: false
    end
  end
end
