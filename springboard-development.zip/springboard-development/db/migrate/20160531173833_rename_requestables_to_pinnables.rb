class RenameRequestablesToPinnables < ActiveRecord::Migration
  def change
    rename_table :requestables, :pinnables
    rename_column :pinnables, :requestable_type, :pinnable_type
    rename_column :pinnables, :requestable_id, :pinnable_id
    rename_index :pinnables, 'index_request_associations_on_requestable', 'index_pinnables_on_pinnable'
    rename_index :pinnables, 'index_request_associations_on_request_id_and_requestable', 'index_pinnables_on_request_id_and_pinnable'
  end
end
