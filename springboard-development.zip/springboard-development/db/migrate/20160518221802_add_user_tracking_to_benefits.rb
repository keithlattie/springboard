class AddUserTrackingToBenefits < ActiveRecord::Migration
  def change
    add_column :benefits, :created_by, :string
    add_column :benefits, :updated_by, :string
  end
end
