class CreateSpends < ActiveRecord::Migration
  def change
    create_table :spends do |t|
      t.integer :year, null: false
      t.string :kind, null: false
      t.integer :capital, null: false
      t.integer :expense, null: false
      t.references :product, index: true, foreign_key: true

      t.timestamps null: false
    end
  end
end
