class AddSpendToIdeas < ActiveRecord::Migration
  def change
    change_table :ideas do |t|
      t.references :spend, index: true
    end
  end
end
