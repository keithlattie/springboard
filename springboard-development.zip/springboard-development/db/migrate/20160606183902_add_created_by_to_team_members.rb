class AddCreatedByToTeamMembers < ActiveRecord::Migration
  def change
    add_column :team_members, :created_by, :integer
  end
end
