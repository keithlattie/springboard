class CreateMetrics < ActiveRecord::Migration
  def change
    create_table :metrics do |t|
      t.string :name, null: false
      t.references :metric_category, index: true, foreign_key: true, null: false
      t.timestamps null: false
    end
  end
end
