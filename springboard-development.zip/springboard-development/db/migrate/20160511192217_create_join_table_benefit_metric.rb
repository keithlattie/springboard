class CreateJoinTableBenefitMetric < ActiveRecord::Migration
  def change
    create_table :benefits_metrics do |t|
      t.references :benefit, index: true, foreign_key: true, null: false
      t.references :metric, index: true, foreign_key: true, null: false
    end
    add_index :benefits_metrics, [:benefit_id, :metric_id], unique: true
  end
end
