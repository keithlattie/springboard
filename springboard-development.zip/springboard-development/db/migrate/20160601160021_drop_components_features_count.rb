class DropComponentsFeaturesCount < ActiveRecord::Migration
  def up
    remove_column :components, :features_count
  end

  def down
    add_column :components, :features_count, :integer, default: 0, null: false
     Component.find_each do |c|
      c.update(features_count: c.features.count)
    end
  end
end
