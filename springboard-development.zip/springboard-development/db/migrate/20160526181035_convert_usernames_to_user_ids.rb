class ConvertUsernamesToUserIds < ActiveRecord::Migration
  def change
    change_table :portfolios do |t|
      t.remove :created_by, :updated_by
      t.integer :created_by, unsigned: true
      t.integer :updated_by, unsigned: true
    end

    change_table :products do |t|
      t.remove :created_by, :updated_by
      t.integer :created_by, unsigned: true
      t.integer :updated_by, unsigned: true
    end

    change_table :components do |t|
      t.remove :created_by, :updated_by
      t.integer :created_by, unsigned: true
      t.integer :updated_by, unsigned: true
    end

    change_table :features do |t|
      t.remove :created_by, :updated_by
      t.integer :created_by, unsigned: true
      t.integer :updated_by, unsigned: true
    end

    change_table :benefits do |t|
      t.remove :created_by, :updated_by
      t.integer :created_by, unsigned: true
      t.integer :updated_by, unsigned: true
    end

    change_table :requests do |t|
      t.remove :created_by, :updated_by
      t.integer :created_by, unsigned: true
      t.integer :updated_by, unsigned: true
    end
  end
end
