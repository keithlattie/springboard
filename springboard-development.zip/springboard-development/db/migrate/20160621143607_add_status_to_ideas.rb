class AddStatusToIdeas < ActiveRecord::Migration
  def change
    change_table :ideas do |t|
      t.string :status
    end
  end
end
