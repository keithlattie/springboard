class RenameIdeaPointsToInvestmentPoints < ActiveRecord::Migration
  def change
    rename_column :ideas, :effort, :investment_points
  end
end
