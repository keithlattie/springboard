class CreateBenefits < ActiveRecord::Migration
  def change
    create_table :benefits do |t|
      t.string :name, null: false
      t.references :component, index: true, foreign_key: true, null: false
      t.timestamps null: false
    end
  end
end
