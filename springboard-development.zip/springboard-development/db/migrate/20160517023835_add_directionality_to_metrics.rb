class AddDirectionalityToMetrics < ActiveRecord::Migration
  def change
    add_column :metrics, :directionality, :string
  end
end
