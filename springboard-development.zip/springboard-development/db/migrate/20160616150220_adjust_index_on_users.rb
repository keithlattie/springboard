class AdjustIndexOnUsers < ActiveRecord::Migration
  def up
    remove_index :users, :email if index_exists?(:users, :email)
    add_index :users, :username, unique: true
  end

  def down
    remove_index :users, :username
  end
end
