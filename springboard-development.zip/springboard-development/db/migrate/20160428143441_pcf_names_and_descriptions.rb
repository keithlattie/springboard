class PcfNamesAndDescriptions < ActiveRecord::Migration
  def change
    change_table :portfolios do |t|
      t.remove :abbr
      t.rename :label, :name
    end

    change_table :products do |t|
      t.remove :abbr
      t.rename :label, :name
    end

    change_table :components do |t|
      t.text :description
    end

    change_table :features do |t|
      t.text :description
    end
  end
end
