class AddNullConstraintsToFavorites < ActiveRecord::Migration
  def change
  	change_column_null(:favorites, :user_id, false)
  	change_column_null(:favorites, :favorable_id, false)
  	change_column_null(:favorites, :favorable_type, false)
  end
end
