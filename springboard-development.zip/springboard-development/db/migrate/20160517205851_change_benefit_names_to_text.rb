class ChangeBenefitNamesToText < ActiveRecord::Migration
  def up
    change_column :benefits, :name, :text
  end

  def down
    change_column :benefits, :name, :string
  end
end
