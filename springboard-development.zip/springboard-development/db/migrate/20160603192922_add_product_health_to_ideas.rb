class AddProductHealthToIdeas < ActiveRecord::Migration
  def change
    add_column :ideas, :product_health, :integer
    rename_column :ideas, :biz_impact, :business_value
  end
end
