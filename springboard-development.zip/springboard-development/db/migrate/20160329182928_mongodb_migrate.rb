class MongodbMigrate < ActiveRecord::Migration
  def change
    create_table :users do |t|
      t.string :mongo_id
      t.string :username, null: false
      t.string :email, null: false
      t.string :first_name, null: false
      t.string :last_name, null: false
      t.datetime :last_signed_in_at

      t.timestamps null: false
    end

    create_table :portfolios do |t|
      t.string :mongo_id
      t.string :abbr, null: false
      t.string :label, null: false
      t.integer :position
      t.string :created_by
      t.string :updated_by

      t.timestamps null: false
    end

    create_table :products do |t|
      t.string :mongo_id
      t.belongs_to :portfolio, index: true
      t.string :abbr, null: false
      t.string :label, null: false
      t.text :description
      t.string :created_by
      t.string :updated_by

      t.timestamps null: false
    end

    create_table :components do |t|
      t.string :mongo_id
      t.belongs_to :product, index: true
      t.integer :position
      t.string :name, null: false
      t.string :created_by
      t.string :updated_by

      t.timestamps null: false
    end

    create_table :features do |t|
      t.string :mongo_id
      t.belongs_to :component, index: true
      t.integer :position
      t.string :name, null: false
      t.string :created_by
      t.string :updated_by

      t.timestamps null: false
    end
  end
end
