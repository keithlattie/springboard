class RenameRequestsToIdeas < ActiveRecord::Migration
  def change
    rename_table :requests, :ideas
    rename_column :ideas, :requester_id, :originator_id
    rename_column :pinnables, :request_id, :idea_id
  end
end
