class ConvertBenefitsToPolymorphic < ActiveRecord::Migration
  def up
    remove_columns :benefits, :component_id
    change_table :benefits do |t|
      t.references :beneficial, polymorphic: true, null: false, index: true
    end
  end

  def down
    remove_columns :benefits, :beneficial_id, :beneficial_type
    change_table :benefits do |t|
      t.references :component, null: false, index: true, foreign_key: true
    end
  end
end
