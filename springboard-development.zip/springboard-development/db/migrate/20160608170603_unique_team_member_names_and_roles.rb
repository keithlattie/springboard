class UniqueTeamMemberNamesAndRoles < ActiveRecord::Migration
  def change
    add_index :team_members, [:name, :role, :product_id], unique: true
  end
end
