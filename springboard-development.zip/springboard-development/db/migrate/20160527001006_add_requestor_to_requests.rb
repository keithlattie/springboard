class AddRequestorToRequests < ActiveRecord::Migration
  def change
    change_table :requests do |t|
      t.integer :requester_id, unsigned: true
    end
  end
end
