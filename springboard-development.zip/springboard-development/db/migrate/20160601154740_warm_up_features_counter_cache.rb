class WarmUpFeaturesCounterCache < ActiveRecord::Migration
  def up
    Rake::Task['counter_caches:warm'].invoke
  end

  def down
    Rake::Task['counter_caches:reset'].invoke
  end
end
