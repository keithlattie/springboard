class AddUpdatedByToSpends < ActiveRecord::Migration
  def change
    add_column :spends, :updated_by, :integer
  end
end
