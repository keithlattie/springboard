class AddCounterCachesToProductAndComponent < ActiveRecord::Migration
  def change
    add_column :products, :components_count, :integer, null: false, default: 0
    add_column :components, :features_count, :integer, null: false, default: 0
  end
end
