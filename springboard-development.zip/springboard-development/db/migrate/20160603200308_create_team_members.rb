class CreateTeamMembers < ActiveRecord::Migration
  def up
    create_table :team_members do |t|
      t.references :product, null: false, index: true, foreign_key: true
      t.string :role, null: false
      t.string :name, null: false

      t.timestamps null: false
    end
  end

  def down
    drop_table :team_members
  end
end
