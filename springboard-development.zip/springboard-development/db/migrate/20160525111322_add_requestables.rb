class AddRequestables < ActiveRecord::Migration
  def change
    drop_table :request_associations

    create_table :requestables do |t|
      t.references :request, index: true, null: false
      t.references :requestable, polymorphic: true, index: {name: 'index_request_associations_on_requestable'}, null: false
    end
    add_index :requestables, [:request_id, :requestable_type, :requestable_id], unique: true, name: 'index_request_associations_on_request_id_and_requestable'
  end
end
