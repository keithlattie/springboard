class RemoveDuplicateSignInColumnFromUsers < ActiveRecord::Migration
  def up
    remove_column :users, :last_sign_in_at if column_exists?(:users, :last_sign_in_at)
    rename_column :users, :last_signed_in_at, :last_sign_in_at
  end

  def down
    rename_column :users, :last_sign_in_at, :last_signed_in_at
    add_column :users, :last_sign_in_at, :datetime
  end
end
