class AddCreatedByToSpends < ActiveRecord::Migration
  def change
    add_column :spends, :created_by, :integer
  end
end
