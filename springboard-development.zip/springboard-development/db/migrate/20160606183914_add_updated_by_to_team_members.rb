class AddUpdatedByToTeamMembers < ActiveRecord::Migration
  def change
    add_column :team_members, :updated_by, :integer
  end
end
