class AddRequests < ActiveRecord::Migration
  def change
    create_table :requests do |t|
      t.string :mongo_id
      t.belongs_to :product, index: true, null: false
      t.references :owner, index: true
      t.text :title, null: false
      t.text :description
      t.integer :biz_impact
      t.integer :effort
      t.integer :priority
      t.integer :position
      t.string :created_by
      t.string :updated_by

      t.timestamps null: false
    end

    create_table :request_associations do |t|
      t.references :request, index: true, null: false
      t.references :associable, polymorphic: true, index: {name: 'index_request_associations_on_associable'}, null: false
    end
    add_index :request_associations, [:request_id, :associable_type, :associable_id], unique: true, name: 'index_request_associations_on_request_id_and_associable'
  end
end
