# encoding: UTF-8
# This file is auto-generated from the current state of the database. Instead
# of editing this file, please use the migrations feature of Active Record to
# incrementally modify your database, and then regenerate this schema definition.
#
# Note that this schema.rb definition is the authoritative source for your
# database schema. If you need to create the application database on another
# system, you should be using db:schema:load, not running all the migrations
# from scratch. The latter is a flawed and unsustainable approach (the more migrations
# you'll amass, the slower it'll run and the greater likelihood for issues).
#
# It's strongly recommended that you check this file into your version control system.

ActiveRecord::Schema.define(version: 20160707135123) do

  create_table "benefits", force: :cascade do |t|
    t.text     "name",            limit: 65535, null: false
    t.datetime "created_at",                    null: false
    t.datetime "updated_at",                    null: false
    t.integer  "beneficial_id",   limit: 4,     null: false
    t.string   "beneficial_type", limit: 255,   null: false
    t.integer  "created_by",      limit: 4
    t.integer  "updated_by",      limit: 4
  end

  add_index "benefits", ["beneficial_type", "beneficial_id"], name: "index_benefits_on_beneficial_type_and_beneficial_id", using: :btree

  create_table "benefits_metrics", force: :cascade do |t|
    t.integer "benefit_id", limit: 4, null: false
    t.integer "metric_id",  limit: 4, null: false
  end

  add_index "benefits_metrics", ["benefit_id", "metric_id"], name: "index_benefits_metrics_on_benefit_id_and_metric_id", unique: true, using: :btree
  add_index "benefits_metrics", ["benefit_id"], name: "index_benefits_metrics_on_benefit_id", using: :btree
  add_index "benefits_metrics", ["metric_id"], name: "index_benefits_metrics_on_metric_id", using: :btree

  create_table "components", force: :cascade do |t|
    t.string   "mongo_id",    limit: 255
    t.integer  "product_id",  limit: 4
    t.integer  "position",    limit: 4
    t.string   "name",        limit: 255,   null: false
    t.datetime "created_at",                null: false
    t.datetime "updated_at",                null: false
    t.text     "description", limit: 65535
    t.integer  "created_by",  limit: 4
    t.integer  "updated_by",  limit: 4
  end

  add_index "components", ["product_id"], name: "index_components_on_product_id", using: :btree

  create_table "favorites", force: :cascade do |t|
    t.integer  "user_id",        limit: 4,   null: false
    t.integer  "favorable_id",   limit: 4,   null: false
    t.string   "favorable_type", limit: 255, null: false
    t.datetime "created_at",                 null: false
    t.datetime "updated_at",                 null: false
  end

  add_index "favorites", ["favorable_type", "favorable_id"], name: "index_favorites_on_favorable_type_and_favorable_id", using: :btree
  add_index "favorites", ["user_id", "favorable_type", "favorable_id"], name: "index_favorites_on_user_id_and_favorable_type_and_favorable_id", unique: true, using: :btree
  add_index "favorites", ["user_id"], name: "index_favorites_on_user_id", using: :btree

  create_table "features", force: :cascade do |t|
    t.string   "mongo_id",     limit: 255
    t.integer  "component_id", limit: 4
    t.integer  "position",     limit: 4
    t.string   "name",         limit: 255,   null: false
    t.datetime "created_at",                 null: false
    t.datetime "updated_at",                 null: false
    t.text     "description",  limit: 65535
    t.integer  "created_by",   limit: 4
    t.integer  "updated_by",   limit: 4
  end

  add_index "features", ["component_id"], name: "index_features_on_component_id", using: :btree

  create_table "goals", force: :cascade do |t|
    t.integer  "idea_id",          limit: 4,   null: false
    t.integer  "metric_id",        limit: 4,   null: false
    t.integer  "amount_hundreths", limit: 4
    t.string   "amount_type",      limit: 255
    t.integer  "duration",         limit: 4
    t.string   "duration_type",    limit: 255
    t.integer  "created_by",       limit: 4
    t.datetime "created_at",                   null: false
    t.datetime "updated_at",                   null: false
  end

  add_index "goals", ["idea_id"], name: "fk_rails_dcc2f5f72b", using: :btree
  add_index "goals", ["metric_id"], name: "fk_rails_b3c161e771", using: :btree

  create_table "ideas", force: :cascade do |t|
    t.string   "mongo_id",          limit: 255
    t.integer  "product_id",        limit: 4,     null: false
    t.integer  "owner_id",          limit: 4
    t.text     "title",             limit: 65535, null: false
    t.text     "description",       limit: 65535
    t.integer  "business_value",    limit: 4
    t.integer  "investment_points", limit: 4
    t.integer  "priority",          limit: 4
    t.integer  "position",          limit: 4
    t.datetime "created_at",                      null: false
    t.datetime "updated_at",                      null: false
    t.integer  "created_by",        limit: 4
    t.integer  "updated_by",        limit: 4
    t.integer  "originator_id",     limit: 4
    t.integer  "product_health",    limit: 4
    t.integer  "spend_id",          limit: 4
    t.string   "status",            limit: 255
  end

  add_index "ideas", ["owner_id"], name: "index_ideas_on_owner_id", using: :btree
  add_index "ideas", ["product_id"], name: "index_ideas_on_product_id", using: :btree
  add_index "ideas", ["spend_id"], name: "index_ideas_on_spend_id", using: :btree

  create_table "metric_categories", force: :cascade do |t|
    t.string   "name",       limit: 255, null: false
    t.string   "icon",       limit: 255, null: false
    t.datetime "created_at",             null: false
    t.datetime "updated_at",             null: false
  end

  create_table "metrics", force: :cascade do |t|
    t.string   "name",               limit: 255, null: false
    t.integer  "metric_category_id", limit: 4,   null: false
    t.datetime "created_at",                     null: false
    t.datetime "updated_at",                     null: false
    t.string   "directionality",     limit: 255
  end

  add_index "metrics", ["metric_category_id"], name: "index_metrics_on_metric_category_id", using: :btree
  add_index "metrics", ["name"], name: "index_metrics_on_name", unique: true, using: :btree

  create_table "pinnables", force: :cascade do |t|
    t.integer "idea_id",       limit: 4,   null: false
    t.integer "pinnable_id",   limit: 4,   null: false
    t.string  "pinnable_type", limit: 255, null: false
  end

  add_index "pinnables", ["idea_id", "pinnable_type", "pinnable_id"], name: "index_pinnables_on_request_id_and_pinnable", unique: true, using: :btree
  add_index "pinnables", ["idea_id"], name: "index_pinnables_on_idea_id", using: :btree
  add_index "pinnables", ["pinnable_type", "pinnable_id"], name: "index_pinnables_on_pinnable", using: :btree

  create_table "portfolios", force: :cascade do |t|
    t.string   "mongo_id",   limit: 255
    t.string   "name",       limit: 255, null: false
    t.integer  "position",   limit: 4
    t.datetime "created_at",             null: false
    t.datetime "updated_at",             null: false
    t.integer  "created_by", limit: 4
    t.integer  "updated_by", limit: 4
  end

  create_table "products", force: :cascade do |t|
    t.string   "mongo_id",         limit: 255
    t.integer  "portfolio_id",     limit: 4
    t.string   "name",             limit: 255,               null: false
    t.text     "description",      limit: 65535
    t.datetime "created_at",                                 null: false
    t.datetime "updated_at",                                 null: false
    t.integer  "components_count", limit: 4,     default: 0, null: false
    t.integer  "created_by",       limit: 4
    t.integer  "updated_by",       limit: 4
    t.integer  "features_count",   limit: 4,     default: 0, null: false
    t.string   "image_url",        limit: 255
  end

  add_index "products", ["portfolio_id"], name: "index_products_on_portfolio_id", using: :btree

  create_table "spends", force: :cascade do |t|
    t.integer  "year",       limit: 4,   null: false
    t.string   "kind",       limit: 255, null: false
    t.integer  "capital",    limit: 4,   null: false
    t.integer  "expense",    limit: 4,   null: false
    t.integer  "product_id", limit: 4
    t.datetime "created_at",             null: false
    t.datetime "updated_at",             null: false
    t.integer  "created_by", limit: 4
    t.integer  "updated_by", limit: 4
  end

  add_index "spends", ["product_id"], name: "index_spends_on_product_id", using: :btree

  create_table "team_members", force: :cascade do |t|
    t.integer  "product_id", limit: 4,   null: false
    t.string   "role",       limit: 255, null: false
    t.string   "name",       limit: 255, null: false
    t.datetime "created_at",             null: false
    t.datetime "updated_at",             null: false
    t.integer  "created_by", limit: 4
    t.integer  "updated_by", limit: 4
  end

  add_index "team_members", ["name", "role", "product_id"], name: "index_team_members_on_name_and_role_and_product_id", unique: true, using: :btree
  add_index "team_members", ["product_id"], name: "index_team_members_on_product_id", using: :btree

  create_table "users", force: :cascade do |t|
    t.string   "mongo_id",            limit: 255
    t.string   "username",            limit: 255,             null: false
    t.string   "email",               limit: 255,             null: false
    t.string   "first_name",          limit: 255,             null: false
    t.string   "last_name",           limit: 255,             null: false
    t.datetime "last_sign_in_at"
    t.datetime "created_at",                                  null: false
    t.datetime "updated_at",                                  null: false
    t.datetime "remember_created_at"
    t.integer  "sign_in_count",       limit: 4,   default: 0, null: false
    t.datetime "current_sign_in_at"
    t.string   "current_sign_in_ip",  limit: 255
    t.string   "last_sign_in_ip",     limit: 255
  end

  add_index "users", ["username"], name: "index_users_on_username", unique: true, using: :btree

  create_table "versions", force: :cascade do |t|
    t.string   "item_type",      limit: 191,        null: false
    t.integer  "item_id",        limit: 4,          null: false
    t.string   "event",          limit: 255,        null: false
    t.string   "whodunnit",      limit: 255
    t.text     "object",         limit: 4294967295
    t.datetime "created_at"
    t.text     "object_changes", limit: 4294967295
  end

  add_index "versions", ["item_type", "item_id"], name: "index_versions_on_item_type_and_item_id", using: :btree

  add_foreign_key "benefits_metrics", "benefits"
  add_foreign_key "benefits_metrics", "metrics"
  add_foreign_key "favorites", "users"
  add_foreign_key "goals", "ideas"
  add_foreign_key "goals", "metrics"
  add_foreign_key "metrics", "metric_categories"
  add_foreign_key "spends", "products"
  add_foreign_key "team_members", "products"
end
